# AuroraGPT Database Backup
# mySQL backup (March 17, 2012 11:36 am)   Type = Complete

CREATE TABLE `clickpla_mrv`.`ad_alert_sessions` (
  `id` int(11) NULL auto_increment,
  `email` text NULL,
  `dsub` varchar(15) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`ad_block` (
  `id` int(11) NULL auto_increment,
  `ad` varchar(100) NULL,
  `blocked` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`admin_menu` (
  `id` int(11) NULL auto_increment,
  `title` varchar(50) NULL,
  `type` varchar(1) NULL,
  `icon` varchar(50) NULL,
  `parent` int(11) NULL,
  `url` text NULL,
  `order` int(11) NULL,
  `append` int(1) NULL,
  `module` int(11) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=143;

CREATE TABLE `clickpla_mrv`.`admin_modules` (
  `id` int(11) NULL auto_increment,
  `type` varchar(20) NULL,
  `active` int(11) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=7;

CREATE TABLE `clickpla_mrv`.`ads` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `dsub` text NULL,
  `username` text NULL,
  `class` char(1) NULL,
  `views` int(11) NULL default '0',
  `views_today` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `target` text NULL,
  `type` int(11) NULL default '0',
  `timed` int(11) NULL default '0',
  `pamount` double NULL default '0',
  `pref` varchar(25) NULL,
  `bgcolor` varchar(25) NULL,
  `forbid_retract` int(11) NULL default '0',
  `active` int(1) NULL default '1',
  `upgrade` int(11) NULL,
  `new` int(11) NULL default '1',
  `daily_limit` int(11) NULL,
  `country` varchar(100) NULL,
  `subtitle` varchar(50) NULL,
  `icon` text NULL,
  `subtitle_on` int(1) NULL default '0',
  `icon_on` int(1) NULL default '0',
  `oviews` int(11) NULL,
  `oviews_today` int(11) NULL,
  `targetban` text NULL,
  `decline` text NULL,
  PRIMARY KEY (`id`),
  KEY `class` (`class`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=27;

CREATE TABLE `clickpla_mrv`.`auctions` (
  `id` int(11) NULL auto_increment,
  `seller` varchar(55) NULL default '',
  `item` varchar(255) NULL default '',
  `item_id` int(11) NULL default '0',
  `min` decimal(12,5) NULL default '0.00000',
  `quick_sale` int(255) NULL default '0',
  `win` decimal(12,5) NULL default '0.00000',
  `bidder` varchar(40) NULL default '',
  `db_table` varchar(20) NULL,
  `ptra_credits` int(11) NULL default '0',
  `link_credits` int(11) NULL default '0',
  `ending` varchar(225) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`backups` (
  `id` int(11) NULL auto_increment,
  `db_file` varchar(50) NULL,
  `db_size` varchar(15) NULL,
  `dsub` varchar(15) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`banners` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `size` int(11) NULL default '0',
  `target` text NULL,
  `banner` text NULL,
  `views` int(11) NULL default '0',
  `clicks` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `dsub` text NULL,
  `username` varchar(25) NULL,
  `pref` varchar(30) NULL,
  `forbid_retract` int(11) NULL default '0',
  `daily_limit` int(11) NULL,
  `views_today` int(11) NULL,
  `active` int(1) NULL,
  `decline` text NULL,
  PRIMARY KEY (`id`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=11;

CREATE TABLE `clickpla_mrv`.`blocklist` (
  `domain` varchar(50) NULL,
  KEY `domain` (`domain`)
) TYPE=;

CREATE TABLE `clickpla_mrv`.`browsevalgame` (
  `id` int(11) NULL auto_increment,
  `dsub` varchar(15) NULL,
  `username` text NULL,
  `val` tinyint(1) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`cheat_answers` (
  `id` int(11) NULL auto_increment,
  `qid` int(11) NULL default '0',
  `answer` varchar(90) NULL,
  PRIMARY KEY (`id`),
  KEY `answer` (`answer`)
) TYPE= AUTO_INCREMENT=4;

CREATE TABLE `clickpla_mrv`.`cheat_failed` (
  `id` int(11) NULL auto_increment,
  `username` varchar(90) NULL,
  `failed` int(11) NULL default '0',
  `last_failed` varchar(15) NULL,
  `failed_today` int(11) NULL default '0',
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) TYPE= AUTO_INCREMENT=2;

CREATE TABLE `clickpla_mrv`.`cheat_questions` (
  `id` int(11) NULL auto_increment,
  `question` varchar(90) NULL,
  `aid` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=2;

CREATE TABLE `clickpla_mrv`.`cheat_session` (
  `id` int(11) NULL auto_increment,
  `username` text NULL,
  `trivia` int(11) NULL default '0',
  `loads` int(11) NULL default '1',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=6;

CREATE TABLE `clickpla_mrv`.`click_history` (
  `id` int(11) NULL auto_increment,
  `username` varchar(25) NULL,
  `clicks` text NULL,
  `type` varchar(4) NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `type` (`type`)
) TYPE= AUTO_INCREMENT=85;

CREATE TABLE `clickpla_mrv`.`click_sessions` (
  `id` int(11) NULL auto_increment,
  `dsub` varchar(15) NULL,
  `username` varchar(25) NULL,
  `val` tinyint(1) NULL default '0',
  `type` varchar(4) NULL,
  `buttons` varchar(15) NULL,
  PRIMARY KEY (`id`),
  KEY `dsub` (`dsub`),
  KEY `username` (`username`),
  KEY `type` (`type`)
) TYPE= AUTO_INCREMENT=294;

CREATE TABLE `clickpla_mrv`.`code_rotator` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `code` text NULL,
  `weight` int(11) NULL default '1',
  `wcount` int(11) NULL default '0',
  `limit` int(11) NULL default '0',
  `tcount` int(11) NULL default '0',
  `dsub` varchar(15) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`comments` (
  `id` int(11) NULL auto_increment,
  `message` text NULL,
  `dsub` varchar(15) NULL,
  `username` varchar(25) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`contest` (
  `id` int(11) NULL auto_increment,
  `dsub` text NULL,
  `username` text NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`country_blacklist` (
  `id` int(11) NULL auto_increment,
  `country` varchar(90) NULL,
  PRIMARY KEY (`id`),
  KEY `country` (`country`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`dailyhits` (
  `ip` varchar(15) NULL,
  `paid` int(11) NULL default '0',
  `ref` varchar(25) NULL,
  `last_time` varchar(15) NULL,
  `mcount` int(11) NULL default '0',
  KEY `ip` (`ip`),
  KEY `paid` (`paid`),
  KEY `ref` (`ref`)
) TYPE=;

CREATE TABLE `clickpla_mrv`.`dbl_cat` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `description` text NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`downline_builder` (
  `id` int(11) NULL auto_increment,
  `title` varchar(75) NULL,
  `url` varchar(75) NULL,
  `type` int(11) NULL default '0',
  `defaultid` varchar(35) NULL,
  `order` int(11) NULL default '0',
  `dsub` varchar(15) NULL,
  `category` text NULL,
  `description` text NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`eg_payment` (
  `id` text NULL,
  `user` text NULL,
  `amount` text NULL,
  `dsub` text NULL,
  `hash` text NULL,
  `item_id` text NULL
) TYPE=;

CREATE TABLE `clickpla_mrv`.`email_block` (
  `id` int(11) NULL auto_increment,
  `account` varchar(100) NULL,
  `blocked` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`emails` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `target` text NULL,
  `description` text NULL,
  `views` int(11) NULL default '0',
  `views_today` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `dsub` text NULL,
  `username` varchar(25) NULL,
  `pref` varchar(30) NULL,
  `forbid_retract` int(11) NULL default '0',
  `new` int(11) NULL default '1',
  `daily_limit` int(11) NULL,
  `upgrade` int(11) NULL,
  `country` varchar(100) NULL,
  `oviews` int(11) NULL,
  `oviews_today` int(11) NULL,
  `active` int(1) NULL default '1',
  `decline` text NULL,
  PRIMARY KEY (`id`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=2;

CREATE TABLE `clickpla_mrv`.`error_log` (
  `id` int(11) NULL auto_increment,
  `error` text NULL,
  `dsub` varchar(15) NULL,
  `username` varchar(50) NULL,
  `ip` varchar(15) NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`fads` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `target` text NULL,
  `description` text NULL,
  `views` int(11) NULL default '0',
  `clicks` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `dsub` text NULL,
  `username` varchar(25) NULL,
  `pref` varchar(30) NULL,
  `forbid_retract` int(11) NULL default '0',
  `daily_limit` int(11) NULL,
  `upgrade` int(11) NULL,
  `views_today` int(11) NULL,
  `active` int(1) NULL,
  `decline` text NULL,
  PRIMARY KEY (`id`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=14;

CREATE TABLE `clickpla_mrv`.`fbanners` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `size` int(11) NULL default '0',
  `target` text NULL,
  `banner` text NULL,
  `views` int(11) NULL default '0',
  `clicks` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `dsub` text NULL,
  `username` varchar(25) NULL,
  `pref` varchar(30) NULL,
  `forbid_retract` int(11) NULL default '0',
  `daily_limit` int(11) NULL,
  `upgrade` int(11) NULL,
  `views_today` int(11) NULL,
  `active` int(1) NULL,
  `decline` text NULL,
  PRIMARY KEY (`id`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=11;

CREATE TABLE `clickpla_mrv`.`flinks` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `target` text NULL,
  `dsub` text NULL,
  `dend` varchar(20) NULL,
  `username` text NULL,
  `clicks` int(11) NULL default '0',
  `views` int(11) NULL default '0',
  `pref` varchar(30) NULL,
  `marquee` int(11) NULL default '0',
  `bgcolor` varchar(25) NULL,
  `active` int(11) NULL default '0',
  `daily_limit` int(11) NULL,
  `upgrade` int(11) NULL,
  PRIMARY KEY (`id`),
  KEY `dend` (`dend`),
  KEY `clicks` (`clicks`),
  KEY `views` (`views`)
) TYPE= AUTO_INCREMENT=15;

CREATE TABLE `clickpla_mrv`.`footprints` (
  `id` int(11) NULL auto_increment,
  `username` varchar(35) NULL,
  `dsub` varchar(15) NULL,
  `url` text NULL,
  `ip` varchar(15) NULL,
  `uri` text NULL,
  `title` text NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1472;

CREATE TABLE `clickpla_mrv`.`forum_forums` (
  `id` int(11) NULL auto_increment,
  `name` varchar(225) NULL,
  `descip` varchar(350) NULL,
  `lastpost` datetime NULL default '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=3;

CREATE TABLE `clickpla_mrv`.`forum_replys` (
  `id` int(11) NULL auto_increment,
  `username` varchar(225) NULL,
  `made` datetime NULL default '0000-00-00 00:00:00',
  `topic` varchar(300) NULL,
  `desc` varchar(1750) NULL,
  `idto` varchar(25) NULL,
  `forum` varchar(225) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`forum_topics` (
  `id` int(11) NULL auto_increment,
  `username` varchar(100) NULL,
  `subject` varchar(125) NULL,
  `descrip` varchar(225) NULL,
  `lastpost` datetime NULL default '0000-00-00 00:00:00',
  `forum` varchar(225) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`help_cats` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `faqs` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`help_faqs` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `cat` int(11) NULL default '0',
  `answer` text NULL,
  `views` int(11) NULL default '0',
  `br` int(11) NULL default '0',
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`ipn` (
  `id` int(11) NULL auto_increment,
  `txn_id` text NULL,
  `ip` text NULL,
  `receiver_email` text NULL,
  `item_name` text NULL,
  `item_number` text NULL,
  `invoice` text NULL,
  `option_selection1` text NULL,
  `payment_status` text NULL,
  `pending_reason` text NULL,
  `payment_date` text NULL,
  `payment_gross` text NULL,
  `payment_fee` text NULL,
  `txn_type` text NULL,
  `first_name` text NULL,
  `last_name` text NULL,
  `address_street` text NULL,
  `address_city` text NULL,
  `address_state` text NULL,
  `address_zip` text NULL,
  `address_country` text NULL,
  `address_status` text NULL,
  `payer_email` text NULL,
  `payer_id` text NULL,
  `payer_status` text NULL,
  `payment_type` text NULL,
  `payment_sign` text NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`jackpot` (
  `ticket_num` varchar(100) NULL,
  `username` varchar(100) NULL,
  UNIQUE KEY `ticket_num` (`ticket_num`)
) TYPE=;

CREATE TABLE `clickpla_mrv`.`ledger` (
  `id` int(11) NULL auto_increment,
  `payment_id` varchar(30) NULL,
  `transaction_id` varchar(30) NULL,
  `account` varchar(75) NULL,
  `name` varchar(50) NULL,
  `product` text NULL,
  `amount` double NULL default '0',
  `proc` varchar(30) NULL,
  `dsub` varchar(15) NULL,
  `username` varchar(35) NULL,
  `cost` double NULL default '0',
  `status` int(11) NULL default '0',
  `email_verify` int(11) NULL default '0',
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`)
) TYPE= AUTO_INCREMENT=3;

CREATE TABLE `clickpla_mrv`.`logs` (
  `id` int(11) NULL auto_increment,
  `log` text NULL,
  `dsub` text NULL,
  `username` varchar(25) NULL,
  `order_id` text NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=80;

CREATE TABLE `clickpla_mrv`.`lottowinners` (
  `id` int(11) NULL auto_increment,
  `username1` varchar(100) NULL,
  `ticket_num1` varchar(100) NULL,
  `username2` varchar(100) NULL,
  `ticket_num2` varchar(100) NULL,
  `username3` varchar(100) NULL,
  `ticket_num3` varchar(100) NULL,
  `username4` varchar(100) NULL,
  `ticket_num4` varchar(100) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`mailer_lists` (
  `id` int(11) NULL auto_increment,
  `mail_id` int(11) NULL default '0',
  `username` varchar(90) NULL,
  PRIMARY KEY (`id`),
  KEY `mail_id` (`mail_id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`mailer_sessions` (
  `id` int(11) NULL auto_increment,
  `subject` text NULL,
  `from` text NULL,
  `message` text NULL,
  `status` int(11) NULL default '0',
  `dsub` varchar(15) NULL,
  `total` int(11) NULL default '0',
  `sent` int(11) NULL default '0',
  `failed` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=2;

CREATE TABLE `clickpla_mrv`.`member_groups` (
  `id` int(11) NULL auto_increment,
  `title` varchar(90) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`member_groups_defined` (
  `id` int(11) NULL auto_increment,
  `perm` varchar(50) NULL,
  `desc` text NULL,
  PRIMARY KEY (`id`),
  KEY `perm` (`perm`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`member_groups_perms` (
  `id` int(11) NULL auto_increment,
  `group` int(11) NULL,
  `perm` varchar(90) NULL,
  `value` text NULL,
  PRIMARY KEY (`id`),
  KEY `perm` (`perm`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`membership_benefits` (
  `id` int(11) NULL auto_increment,
  `membership` int(11) NULL default '0',
  `title` text NULL,
  `type` varchar(50) NULL,
  `amount` double NULL default '0',
  `time_type` char(1) NULL,
  `time` int(11) NULL default '0',
  PRIMARY KEY (`id`),
  KEY `membership` (`membership`),
  KEY `type` (`type`),
  KEY `amount` (`amount`),
  KEY `time_type` (`time_type`),
  KEY `time` (`time`)
) TYPE= AUTO_INCREMENT=35;

CREATE TABLE `clickpla_mrv`.`memberships` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `time_type` char(1) NULL,
  `time_amount` int(11) NULL default '0',
  `downline_earns` decimal(4,2) NULL default '0.00',
  `price` decimal(12,2) NULL default '0.00',
  `active` int(11) NULL default '0',
  `packages` text NULL,
  `order` int(11) NULL default '0',
  `dsub` varchar(25) NULL,
  `purchase_bonus` varchar(12) NULL,
  `upgrade_bonus` varchar(12) NULL,
  `ptp` double NULL default '0',
  PRIMARY KEY (`id`),
  KEY `ptp` (`ptp`)
) TYPE= AUTO_INCREMENT=4;

CREATE TABLE `clickpla_mrv`.`messages` (
  `id` int(11) NULL auto_increment,
  `title` varchar(100) NULL,
  `message` text NULL,
  `read` int(1) NULL,
  `dsub` varchar(15) NULL,
  `from` varchar(100) NULL,
  `username` varchar(100) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`news` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `news` text NULL,
  `dsub` text NULL,
  `subm` text NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=5;

CREATE TABLE `clickpla_mrv`.`online` (
  `id` int(11) NULL auto_increment,
  `userid` varchar(10) NULL,
  `dsub` text NULL,
  `ip` text NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) TYPE= AUTO_INCREMENT=16949;

CREATE TABLE `clickpla_mrv`.`orders` (
  `id` int(11) NULL auto_increment,
  `order_id` text NULL,
  `proc` int(11) NULL default '0',
  `payment_id` text NULL,
  `amount` text NULL,
  `dsub` text NULL,
  `username` varchar(25) NULL,
  `paid` int(11) NULL default '0',
  `ad_type` text NULL,
  `cost` double NULL default '0',
  `ad_id` int(11) NULL default '0',
  `points` int(11) NULL default '0',
  `reseller` varchar(25) NULL,
  `class` char(1) NULL,
  `timed` char(2) NULL,
  `pamount` varchar(12) NULL,
  `premium_id` int(11) NULL default '0',
  `bgcolor` varchar(25) NULL,
  `marquee` int(11) NULL default '0',
  `special_id` int(11) NULL default '0',
  `status` int(11) NULL default '0',
  `subtitle` int(1) NULL,
  `icon` int(1) NULL,
  PRIMARY KEY (`id`),
  KEY `class` (`class`),
  KEY `timed` (`timed`),
  KEY `pamount` (`pamount`)
) TYPE= AUTO_INCREMENT=25;

CREATE TABLE `clickpla_mrv`.`payment_approve` (
  `id` int(11) NULL auto_increment,
  `account` varchar(100) NULL,
  `blocked` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=3;

CREATE TABLE `clickpla_mrv`.`payment_block` (
  `id` int(11) NULL auto_increment,
  `account` varchar(100) NULL,
  `blocked` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`payment_history` (
  `id` int(11) NULL auto_increment,
  `payout_id` text NULL,
  `rdsub` text NULL,
  `dsub` text NULL,
  `username` text NULL,
  `account` text NULL,
  `accounttype` text NULL,
  `amount` decimal(12,2) NULL default '0.00',
  `status` int(11) NULL default '0',
  `paid` text NULL,
  `fee` decimal(12,2) NULL default '0.00',
  `ignore_filter` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`payouts` (
  `id` int(11) NULL auto_increment,
  `dsub` text NULL,
  `amount` double NULL default '0',
  `mass` text NULL,
  `paid` int(11) NULL default '0',
  `payments` int(11) NULL default '0',
  `payout_id` text NULL,
  `accounttype` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`pending_emails` (
  `id` int(11) NULL auto_increment,
  `subject` text NULL,
  `body` text NULL,
  `tolist` text NULL,
  `mailid` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`poll_history` (
  `ip` varchar(25) NULL,
  KEY `ip` (`ip`)
) TYPE=;

CREATE TABLE `clickpla_mrv`.`polls_history` (
  `id` int(11) NULL auto_increment,
  `username` varchar(100) NULL,
  `poll` int(11) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`polls_options` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `poll` int(11) NULL,
  `votes` int(11) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`polls_polls` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `status` int(11) NULL,
  `dsub` varchar(15) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`popups` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `dsub` text NULL,
  `username` text NULL,
  `views` int(11) NULL default '0',
  `views_today` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `target` text NULL,
  `type` int(11) NULL default '0',
  `pref` varchar(25) NULL,
  `forbid_retract` int(11) NULL default '0',
  `daily_limit` int(11) NULL,
  `upgrade` int(11) NULL,
  `active` int(1) NULL,
  `decline` text NULL,
  PRIMARY KEY (`id`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`ptp_allow` (
  `domain` varchar(95) NULL,
  KEY `domain` (`domain`)
) TYPE=;

CREATE TABLE `clickpla_mrv`.`ptrads` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `dsub` text NULL,
  `username` text NULL,
  `class` char(1) NULL,
  `views` int(11) NULL default '0',
  `views_today` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `target` text NULL,
  `type` int(11) NULL default '0',
  `timed` int(11) NULL default '0',
  `pamount` double NULL default '0',
  `pref` varchar(25) NULL,
  `bgcolor` varchar(25) NULL,
  `forbid_retract` int(11) NULL default '0',
  `ad` text NULL,
  `active` int(11) NULL default '1',
  `new` int(11) NULL default '1',
  `daily_limit` int(11) NULL,
  `upgrade` int(11) NULL,
  `country` varchar(100) NULL,
  `icon_on` int(1) NULL default '0',
  `icon` text NULL,
  `subtitle_on` int(1) NULL default '0',
  `subtitle` varchar(50) NULL,
  `decline` text NULL,
  PRIMARY KEY (`id`),
  KEY `class` (`class`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=2;

CREATE TABLE `clickpla_mrv`.`ptsu_history` (
  `id` int(11) NULL auto_increment,
  `username` varchar(25) NULL,
  `clicks` text NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`ptsu_log` (
  `id` int(11) NULL auto_increment,
  `username` varchar(90) NULL,
  `ptsu_id` int(11) NULL default '0',
  `status` int(11) NULL default '0',
  `dsub` varchar(15) NULL,
  `pamount` double NULL default '0',
  `class` char(1) NULL,
  `welcome_email` text NULL,
  `userid` varchar(90) NULL,
  `domain` varchar(90) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`ptsuads` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `dsub` text NULL,
  `username` text NULL,
  `signups` int(11) NULL default '0',
  `signups_today` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `pending` int(11) NULL default '0',
  `target` text NULL,
  `pamount` double NULL default '0',
  `pref` varchar(25) NULL,
  `ad` text NULL,
  `active` int(11) NULL default '1',
  `class` char(1) NULL,
  `forbid_retract` int(11) NULL default '0',
  `tagged` int(11) NULL default '0',
  `type` varchar(1) NULL,
  `domain` text NULL,
  `new` int(11) NULL default '1',
  `featured` int(11) NULL,
  `upgrade` int(11) NULL,
  `country` varchar(100) NULL,
  `icon_on` int(1) NULL default '0',
  `icon` text NULL,
  `subtitle_on` int(1) NULL default '0',
  `subtitle` varchar(50) NULL,
  `decline` text NULL,
  PRIMARY KEY (`id`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`refdomains` (
  `domain` varchar(50) NULL,
  `hits` int(11) NULL default '0',
  KEY `domain` (`domain`)
) TYPE=;

CREATE TABLE `clickpla_mrv`.`reports` (
  `id` int(11) NULL auto_increment,
  `adid` int(11) NULL default '0',
  `username` text NULL,
  `reason` text NULL,
  `other` text NULL,
  `reports` int(11) NULL default '0',
  `title` text NULL,
  `target` text NULL,
  `placed_by` varchar(25) NULL,
  `type` varchar(5) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`requests` (
  `id` int(11) NULL auto_increment,
  `dsub` text NULL,
  `username` text NULL,
  `status` int(11) NULL default '0',
  `paid` text NULL,
  `account` text NULL,
  `amount` decimal(12,2) NULL default '0.00',
  `accounttype` text NULL,
  `fee` double(12,2) NULL default '0.00',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`route_codes` (
  `id` int(11) NULL auto_increment,
  `code` varchar(4) NULL,
  `dsub` varchar(15) NULL,
  PRIMARY KEY (`id`),
  KEY `dsub` (`dsub`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`sessions` (
  `id` int(11) NULL auto_increment,
  `sess_id` text NULL,
  `sess_id2` text NULL,
  `user_id` int(11) NULL default '0',
  `start_time` text NULL,
  `remote_ip` text NULL,
  `ipvoid` varchar(1) NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) TYPE= AUTO_INCREMENT=121;

CREATE TABLE `clickpla_mrv`.`special_benefits` (
  `id` int(11) NULL auto_increment,
  `special` int(11) NULL default '0',
  `title` text NULL,
  `type` varchar(50) NULL,
  `amount` double NULL default '0',
  PRIMARY KEY (`id`),
  KEY `special` (`special`),
  KEY `type` (`type`),
  KEY `amount` (`amount`)
) TYPE= AUTO_INCREMENT=14;

CREATE TABLE `clickpla_mrv`.`specials` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `price` decimal(12,2) NULL default '0.00',
  `active` int(11) NULL default '0',
  `packages` text NULL,
  `order` int(11) NULL default '0',
  `dsub` varchar(25) NULL,
  `buys` int(11) NULL default '0',
  `show` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=3;

CREATE TABLE `clickpla_mrv`.`stats` (
  `id` int(11) NULL auto_increment,
  `date` text NULL,
  `hits` int(11) NULL default '0',
  `new_members` int(11) NULL default '0',
  `cash` decimal(12,5) NULL default '0.00000',
  `clicked` int(11) NULL default '0',
  `income` decimal(12,2) NULL default '0.00',
  `points` double(12,5) NULL default '0.00000',
  `ptphits` int(11) NULL default '0',
  `unhits` int(11) NULL default '0',
  `emails` int(11) NULL default '0',
  `floodguard` int(11) NULL default '0',
  `surfed` int(11) NULL default '0',
  `surf_credits` decimal(12,5) NULL default '0.00000',
  `ptrads` int(11) NULL default '0',
  `xclicked` int(11) NULL default '0',
  `xcredits` decimal(12,5) NULL default '0.00000',
  `signups` int(11) NULL default '0',
  `paid` decimal(12,2) NULL default '0.00',
  `survey` decimal(12,2) NULL default '0.00',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=12;

CREATE TABLE `clickpla_mrv`.`store_items` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `description` text NULL,
  `points` int(11) NULL default '0',
  `cash` decimal(12,2) NULL default '0.00',
  `qty` int(11) NULL default '0',
  `dsub` varchar(15) NULL,
  `email` varchar(55) NULL,
  `active` int(11) NULL default '0',
  `sold` int(11) NULL default '0',
  KEY `id` (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`surf_sites` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `dsub` text NULL,
  `username` text NULL,
  `views` int(11) NULL default '0',
  `views_today` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `target` text NULL,
  `pref` varchar(25) NULL,
  `forbid_retract` int(11) NULL default '0',
  `active` int(11) NULL default '0',
  PRIMARY KEY (`id`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`target_co` (
  `id` int(11) NULL auto_increment,
  `country` varchar(100) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=18;

CREATE TABLE `clickpla_mrv`.`templates` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `template` text NULL,
  `login` int(11) NULL default '0',
  `br` int(11) NULL default '0',
  `hits` int(11) NULL default '0',
  `hits_today` int(11) NULL default '0',
  `page` int(11) NULL default '0',
  `php` int(11) NULL default '0',
  `premium` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`terms` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `terms` text NULL,
  `dsub` text NULL,
  `subm` text NULL,
  `imglink` varchar(200) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=11;

CREATE TABLE `clickpla_mrv`.`tracker` (
  `id` int(11) NULL auto_increment,
  `track_id` text NULL,
  `ip` text NULL,
  `dsub` text NULL,
  `visits` int(11) NULL default '1',
  `register` int(11) NULL default '0',
  PRIMARY KEY (`id`),
  KEY `register` (`register`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`tracker_archive` (
  `id` int(11) NULL auto_increment,
  `track_id` varchar(50) NULL,
  `start` varchar(15) NULL,
  `end` varchar(15) NULL,
  `visits` int(11) NULL,
  `uniques` int(11) NULL,
  `register` int(11) NULL,
  `purchased` double(12,2) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`user` (
  `userid` int(11) NULL auto_increment,
  `name` text NULL,
  `username` varchar(25) NULL,
  `password` varchar(100) NULL,
  `email` text NULL,
  `permission` int(11) NULL default '0',
  `mod_permission` varchar(11) NULL,
  `balance` decimal(12,5) NULL default '0.00000',
  `joined` text NULL,
  `last_ip` text NULL,
  `refered` varchar(25) NULL,
  `referrals1` int(11) NULL default '0',
  `referrals2` int(11) NULL default '0',
  `referrals3` int(11) NULL default '0',
  `referrals4` int(11) NULL default '0',
  `referrals5` int(11) NULL default '0',
  `referral_earns` decimal(12,5) NULL default '0.00000',
  `clicks` int(11) NULL default '0',
  `type` int(11) NULL default '0',
  `points` decimal(12,5) NULL default '0.00000',
  `last_click` text NULL,
  `last_act` text NULL,
  `w_min` decimal(12,2) NULL default '0.00',
  `w_method` text NULL,
  `w_account` text NULL,
  `link_credits` decimal(12,5) NULL default '0.00000',
  `banner_credits` decimal(12,5) NULL default '0.00000',
  `fad_credits` decimal(12,5) NULL default '0.00000',
  `flink_credits` decimal(12,5) NULL default '0.00000',
  `clicked_today` int(11) NULL default '0',
  `tickets` int(11) NULL default '0',
  `pend` varchar(25) NULL,
  `conclicks` int(11) NULL default '0',
  `week_refs` int(11) NULL default '0',
  `suspended` int(11) NULL default '0',
  `ptphits` int(11) NULL default '0',
  `ptphits_today` int(11) NULL default '0',
  `ptpearns` decimal(12,5) NULL default '0.00000',
  `popup_credits` decimal(12,5) NULL default '0.00000',
  `ptr_credits` decimal(12,5) NULL default '0.00000',
  `optin` int(11) NULL default '0',
  `conemails` int(11) NULL default '0',
  `emails` int(11) NULL default '0',
  `emails_today` int(11) NULL default '0',
  `fbanner_credits` decimal(12,5) NULL default '0.00000',
  `membership` int(11) NULL default '0',
  `game_points` decimal(12,5) NULL default '0.00000',
  `notes` text NULL,
  `verified` int(11) NULL default '0',
  `verify_id` varchar(25) NULL,
  `ref_hits_raw` int(11) NULL default '0',
  `ref_hits_unique` int(11) NULL default '0',
  `game_site_credits` decimal(12,5) NULL default '0.00000',
  `surf_credits` decimal(12,5) NULL default '0.00000',
  `surf_clicks` int(11) NULL default '0',
  `surf_clicks_today` int(11) NULL default '0',
  `floodguard` int(11) NULL default '0',
  `floodguard_today` int(11) NULL default '0',
  `referrals` int(11) NULL default '0',
  `updated` int(11) NULL default '0',
  `ptra_clicks` int(11) NULL default '0',
  `ptra_clicks_today` int(11) NULL default '0',
  `ptra_credits` decimal(12,5) NULL default '0.00000',
  `last_ptra` varchar(15) NULL,
  `xcredits` decimal(12,5) NULL default '0.00000',
  `xclicks` int(11) NULL default '0',
  `xclicked_today` int(11) NULL default '0',
  `failed_logins` int(11) NULL default '0',
  `country` varchar(50) NULL,
  `db` text NULL,
  `cheat_check` int(11) NULL default '0',
  `cheat_failed` int(11) NULL default '0',
  `lockout` varchar(15) NULL,
  `last_cheat` varchar(15) NULL,
  `cheat_checks` int(11) NULL default '0',
  `ptsu_credits` int(11) NULL default '0',
  `ad_alert` varchar(1) NULL,
  `ad_tag` varchar(1) NULL,
  `sex` varchar(1) NULL,
  `birth` int(11) NULL,
  `ad_alert_login` int(1) NULL default '0',
  `ptsu_approved` int(11) NULL,
  `ptsu_denied` int(11) NULL,
  `ptsu_earnings` double(12,2) NULL,
  `group` int(11) NULL,
  `join_ip` varchar(15) NULL,
  `auto_pay` int(11) NULL,
  `auto_account` varchar(90) NULL,
  `auto_method` int(11) NULL,
  `verifyCo` int(1) NULL,
  `hidePopup` int(11) NULL,
  `suspendTime` varchar(15) NULL,
  `suspendMsg` text NULL,
  `upline_earnings` double(12,5) NULL,
  `earned_today` double(7,5) NULL,
  `reftotcli` int(11) NULL,
  `clicksref` int(11) NULL,
  `purchcon_tic` int(11) NULL,
  `clickcon_clic` int(11) NULL,
  `refstat` int(11) NULL,
  `moptin` int(11) NULL default '1',
  `confirm` int(11) NULL default '0',
  `pin` varchar(100) NULL,
  `coclicks` int(11) NULL default '0',
  `bonusclaims` int(11) NULL default '0',
  `tagged` tinyint(4) NULL default '0',
  `warnings` int(11) NULL default '0',
  `surv_comp` int(11) NULL default '0',
  `ref_notifier` int(11) NULL default '1',
  `lbref` int(11) NULL,
  PRIMARY KEY (`userid`),
  KEY `username` (`username`),
  KEY `password` (`password`),
  KEY `pin` (`pin`)
) TYPE= AUTO_INCREMENT=51;

CREATE TABLE `clickpla_mrv`.`user_deleted` (
  `userid` int(11) NULL auto_increment,
  `name` text NULL,
  `username` varchar(25) NULL,
  `password` varchar(100) NULL,
  `email` text NULL,
  `permission` int(11) NULL default '0',
  `mod_permission` varchar(11) NULL,
  `balance` decimal(12,5) NULL default '0.00000',
  `joined` text NULL,
  `last_ip` text NULL,
  `refered` varchar(25) NULL,
  `referrals1` int(11) NULL default '0',
  `referrals2` int(11) NULL default '0',
  `referrals3` int(11) NULL default '0',
  `referrals4` int(11) NULL default '0',
  `referrals5` int(11) NULL default '0',
  `referral_earns` decimal(12,5) NULL default '0.00000',
  `clicks` int(11) NULL default '0',
  `type` int(11) NULL default '0',
  `points` decimal(12,5) NULL default '0.00000',
  `last_click` text NULL,
  `last_act` text NULL,
  `w_min` decimal(12,2) NULL default '0.00',
  `w_method` text NULL,
  `w_account` text NULL,
  `link_credits` decimal(12,5) NULL default '0.00000',
  `banner_credits` decimal(12,5) NULL default '0.00000',
  `fad_credits` decimal(12,5) NULL default '0.00000',
  `flink_credits` decimal(12,5) NULL default '0.00000',
  `clicked_today` int(11) NULL default '0',
  `tickets` int(11) NULL default '0',
  `pend` varchar(25) NULL,
  `conclicks` int(11) NULL default '0',
  `week_refs` int(11) NULL default '0',
  `suspended` int(11) NULL default '0',
  `ptphits` int(11) NULL default '0',
  `ptphits_today` int(11) NULL default '0',
  `ptpearns` decimal(12,5) NULL default '0.00000',
  `popup_credits` decimal(12,5) NULL default '0.00000',
  `ptr_credits` decimal(12,5) NULL default '0.00000',
  `optin` int(11) NULL default '0',
  `conemails` int(11) NULL default '0',
  `emails` int(11) NULL default '0',
  `emails_today` int(11) NULL default '0',
  `fbanner_credits` decimal(12,5) NULL default '0.00000',
  `membership` int(11) NULL default '0',
  `game_points` decimal(12,5) NULL default '0.00000',
  `notes` text NULL,
  `verified` int(11) NULL default '0',
  `verify_id` varchar(25) NULL,
  `ref_hits_raw` int(11) NULL default '0',
  `ref_hits_unique` int(11) NULL default '0',
  `game_site_credits` decimal(12,5) NULL default '0.00000',
  `surf_credits` decimal(12,5) NULL default '0.00000',
  `surf_clicks` int(11) NULL default '0',
  `surf_clicks_today` int(11) NULL default '0',
  `floodguard` int(11) NULL default '0',
  `floodguard_today` int(11) NULL default '0',
  `referrals` int(11) NULL default '0',
  `updated` int(11) NULL default '0',
  `ptra_clicks` int(11) NULL default '0',
  `ptra_clicks_today` int(11) NULL default '0',
  `ptra_credits` decimal(12,5) NULL default '0.00000',
  `last_ptra` varchar(15) NULL,
  `xcredits` decimal(12,5) NULL default '0.00000',
  `xclicks` int(11) NULL default '0',
  `xclicked_today` int(11) NULL default '0',
  `failed_logins` int(11) NULL default '0',
  `country` varchar(50) NULL,
  `db` text NULL,
  `cheat_check` int(11) NULL default '0',
  `cheat_failed` int(11) NULL default '0',
  `lockout` varchar(15) NULL,
  `last_cheat` varchar(15) NULL,
  `cheat_checks` int(11) NULL default '0',
  `ptsu_credits` int(11) NULL default '0',
  `ad_alert` varchar(1) NULL,
  `ad_tag` varchar(1) NULL,
  `sex` varchar(1) NULL,
  `birth` int(11) NULL,
  `ad_alert_login` int(1) NULL default '0',
  `ptsu_approved` int(11) NULL,
  `ptsu_denied` int(11) NULL,
  `ptsu_earnings` double(12,2) NULL,
  `group` int(11) NULL,
  `join_ip` varchar(15) NULL,
  `auto_pay` int(11) NULL,
  `auto_account` varchar(90) NULL,
  `auto_method` int(11) NULL,
  `verifyCo` int(1) NULL,
  `hidePopup` int(11) NULL,
  `suspendTime` varchar(15) NULL,
  `suspendMsg` text NULL,
  `upline_earnings` double(12,5) NULL,
  `earned_today` double(7,5) NULL,
  `reftotcli` int(11) NULL,
  `clicksref` int(11) NULL,
  `purchcon_tic` int(11) NULL,
  `clickcon_clic` int(11) NULL,
  `refstat` int(11) NULL,
  `moptin` int(11) NULL default '1',
  `confirm` int(11) NULL default '0',
  `pin` varchar(100) NULL,
  `coclicks` int(11) NULL default '0',
  `bonusclaims` int(11) NULL default '0',
  `tagged` tinyint(4) NULL default '0',
  `warnings` int(11) NULL,
  `surv_comp` int(11) NULL default '0',
  `ref_notifier` int(11) NULL default '1',
  `lbref` int(11) NULL,
  PRIMARY KEY (`userid`),
  KEY `username` (`username`),
  KEY `password` (`password`),
  KEY `pin` (`pin`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`warnings` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `terms` text NULL,
  `dsub` text NULL,
  `subm` text NULL,
  `username` varchar(100) NULL,
  `nomfw` varchar(100) NULL,
  `warning` text NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`withdraw_options` (
  `id` int(11) NULL auto_increment,
  `title` varchar(25) NULL,
  `mps` text NULL,
  `delim` varchar(10) NULL,
  `minimum` double NULL default '0',
  `active` int(11) NULL default '0',
  `fee` int(11) NULL default '0',
  `verif` varchar(15) NULL,
  `fee_premium` int(2) NULL,
  `fee_min` double(3,2) NULL,
  `minimum_premium` double(5,2) NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `delim` (`delim`)
) TYPE= AUTO_INCREMENT=7;

CREATE TABLE `clickpla_mrv`.`wizard_posts` (
  `id` int(11) NULL auto_increment,
  `username` varchar(100) NULL,
  `posted` text NULL,
  `dsub` varchar(15) NULL,
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;

CREATE TABLE `clickpla_mrv`.`xsites` (
  `id` int(11) NULL auto_increment,
  `title` text NULL,
  `dsub` text NULL,
  `username` text NULL,
  `views` int(11) NULL default '0',
  `views_today` int(11) NULL default '0',
  `credits` int(11) NULL default '0',
  `target` text NULL,
  `pref` varchar(25) NULL,
  `forbid_retract` int(11) NULL default '0',
  `active` int(11) NULL default '0',
  `daily_limit` int(11) NULL,
  `upgrade` int(11) NULL,
  `country` varchar(100) NULL,
  `decline` text NULL,
  PRIMARY KEY (`id`),
  KEY `pref` (`pref`)
) TYPE= AUTO_INCREMENT=2;

CREATE TABLE `clickpla_mrv`.`xstage` (
  `id` int(11) NULL auto_increment,
  `title` varchar(55) NULL,
  `type` varchar(55) NULL,
  `stage` int(11) NULL default '0',
  `amount` int(10) NULL default '0',
  `dsub` varchar(15) NULL,
  `daily` int(11) NULL default '0',
  PRIMARY KEY (`id`)
) TYPE= AUTO_INCREMENT=1;






# dumping data for clickpla_mrv.admin_menu
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('1', 'Stats', '0', 'app_chart.gif', '0', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('2', 'Orders', '0', 'shop_card_full.gif', '0', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('3', 'Payouts', '0', 'dollar.gif', '0', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('4', 'Manage Ads', '0', 'data.gif', '0', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('5', 'Members', '0', 'users.gif', '0', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('6', 'Communication', '0', 'mail.gif', '0', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('7', 'Tools', '0', 'applications.gif', '0', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('8', 'Settings', '0', 'app_options.gif', '0', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('9', 'Resources', '0', 'folder.gif', '0', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('10', 'Order Ledger', '1', '', '2', 'admin.php?ac=ledger', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('11', 'Pending Orders', '1', '', '2', 'admin.php?ac=pending_orders', '1', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('12', 'Approved Accounts', '1', '', '2', 'admin.php?ac=payment_approved', '3', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('13', 'Denied Accounts', '1', '', '2', 'admin.php?ac=payment_blocker', '4', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('14', 'Make Payouts', '1', '', '3', 'admin.php?ac=payouts', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('15', 'Options', '1', '', '3', 'admin.php?ac=withdraw_options', '1', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('16', 'Tools', '1', '', '3', '', '3', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('17', 'Paid To Click', '1', '', '4', '', '0', '0', '1');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('18', 'Paid To Promote', '1', '', '4', '', '0', '0', '3');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('19', 'Paid Emails', '1', '', '4', '', '0', '0', '4');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('20', 'Paid To Read', '1', '', '4', '', '0', '0', '5');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('21', 'Paid To Signup', '1', '', '4', '', '0', '0', '2');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('22', 'Click Exchange', '1', '', '4', '', '0', '0', '6');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('23', 'Manager', '1', '', '17', 'admin.php?ac=links', '0', '1', '1');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('24', 'Settings', '1', '', '17', 'admin.php?ac=settings&type=ptc', '0', '1', '1');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('25', 'Manager', '1', '', '18', 'admin.php?ac=popups', '0', '1', '3');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('26', 'Settings', '1', '', '18', 'admin.php?ac=settings&type=ptp', '0', '1', '3');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('27', 'Manager', '1', '', '19', 'admin.php?ac=emails', '0', '1', '4');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('28', 'Settings', '1', '', '19', 'admin.php?ac=settings&type=ptr', '0', '1', '4');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('29', 'Manager', '1', '', '20', 'admin.php?ac=ptrads', '0', '1', '5');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('30', 'Settings', '1', '', '20', 'admin.php?ac=settings&type=ptra', '0', '1', '5');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('31', 'Manager', '1', '', '21', 'admin.php?ac=manage_ptsu', '0', '1', '2');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('32', 'Settings', '1', '', '21', 'admin.php?ac=settings&type=ptsu', '0', '1', '2');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('33', 'Pending Signups', '1', '', '21', 'admin.php?ac=pending_signups', '0', '1', '2');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('34', 'Cheater Tools', '1', '', '21', 'admin.php?ac=ptsu_find_cheaters', '0', '1', '2');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('35', 'Manager', '1', '', '22', 'admin.php?ac=xsites', '0', '1', '6');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('36', 'Settings', '1', '', '22', 'admin.php?ac=settings&type=clickx', '0', '1', '6');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('37', 'Activate Sites', '1', '', '22', 'admin.php?ac=actxsurf', '0', '1', '6');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('38', 'Manage X-Stages', '1', '', '22', 'admin.php?ac=xstage', '0', '1', '6');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('39', 'eMailer', '1', '', '6', 'admin.php?ac=mailer', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('40', 'Manage News', '1', '', '6', 'admin.php?ac=news', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('41', 'Manage FAQs', '1', '', '6', 'admin.php?ac=help', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('42', 'Logging', '1', '', '7', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('43', 'Database', '1', '', '7', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('44', 'Blocking', '1', '', '7', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('45', 'Referral Builder', '1', '', '7', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('46', 'Specials', '1', '', '7', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('47', 'Site Content', '1', '', '7', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('48', 'Point Store', '1', '', '7', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('49', 'Selling', '1', '', '8', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('50', 'Site Settings', '1', '', '8', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('51', 'Member Settings', '1', '', '8', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('52', 'Admin Panel', '1', '', '8', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('53', 'Tracker', '1', '', '42', 'admin.php?ac=tracker', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('54', 'Top Domains', '1', '', '42', 'admin.php?ac=refdomains', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('55', 'Footprints', '1', '', '42', 'admin.php?ac=footprints', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('56', 'Site Logs', '1', '', '42', 'admin.php?ac=logs', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('57', 'Reported Sites', '1', '', '42', 'admin.php?ac=reports', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('58', 'Backup Database', '1', '', '43', 'admin.php?ac=backup', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('59', 'Fix User Tables', '1', '', '43', 'admin.php?ac=fix_delete_table', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('60', 'Clean Daily Stats', '1', '', '43', 'admin.php?ac=delete_duplicate_stats', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('61', 'Database Cleaner', '1', '', '43', 'admin.php?ac=db_clean', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('62', 'Domain Blocker', '1', '', '44', 'admin.php?ac=domainblocker', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('63', 'Email Blocker', '1', '', '44', 'admin.php?ac=email_blocker', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('64', 'Ad Blocker', '1', '', '44', 'admin.php?ac=ad_blocker', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('65', 'PTP Allowed', '1', '', '44', 'admin.php?ac=ptp_allow', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('66', 'Categories', '1', '', '45', 'admin.php?ac=dlcat', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('67', 'Programs', '1', '', '45', 'admin.php?ac=dlbuilder', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('68', 'Manage', '1', '', '46', 'admin.php?ac=specials', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('69', 'Assign Special', '1', '', '46', 'admin.php?ac=assign_special', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('70', 'Anti Cheating', '1', '', '7', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('71', 'Cheat Settings', '1', '', '70', 'admin.php?ac=settings&type=cheat', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('72', 'Failed Log', '1', '', '70', 'admin.php?ac=cheat_check_failed', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('73', 'Manage Trivia', '1', '', '70', 'admin.php?ac=manage_cheat_check', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('74', 'Code Rotator', '1', '', '47', 'admin.php?ac=code_rotator', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('75', 'My Pages', '1', '', '47', 'admin.php?ac=templates', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('76', 'Manage Store', '1', '', '48', 'admin.php?ac=point_store', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('77', 'Payment Options', '1', '', '49', 'admin.php?ac=settings&type=payments', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('78', 'Products', '1', '', '49', 'admin.php?ac=settings&type=product', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('79', 'Site Settings', '1', '', '50', 'admin.php?ac=settings&type=site', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('80', 'eMail Settings', '1', '', '50', 'admin.php?ac=settings&type=email', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('81', 'Poll Settings', '1', '', '50', 'admin.php?ac=polls', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('82', 'Top Clicker', '1', '', '50', 'admin.php?ac=settings&type=topc', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('83', 'Member Settings', '1', '', '51', 'admin.php?ac=settings&type=member', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('85', 'Contest Settings', '1', '', '51', 'admin.php?ac=settings&type=contest', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('86', 'Cheat Settings', '1', '', '51', 'admin.php?ac=settings&type=cheat', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('87', 'Withdraw Settings', '1', '', '51', 'admin.php?ac=settings&type=withdraw', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('88', 'Converter Settings', '1', '', '51', 'admin.php?ac=settings&type=converter', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('89', 'Admin Panel', '1', '', '52', 'admin.php?ac=edit_admin_menu', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('90', 'Account Requests', '1', '', '16', 'admin.php?ac=account_requests', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('91', 'Member Requests', '1', '', '16', 'admin.php?ac=requests', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('92', 'Pending Requests', '1', '', '16', 'admin.php?ac=pendingrequests', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('93', 'Account Filter', '1', '', '16', 'admin.php?ac=accountfilter', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('94', 'Filter Voider', '1', '', '16', 'admin.php?ac=ignore_filter', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('95', 'Cancel All', '1', '', '16', 'admin.php?ac=cancelall', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('96', 'Tools', '1', '', '9', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('97', 'Whois IP Lookup', '1', '', '96', 'admin.php?ac=whois', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('98', 'eGold Masspay', '1', '', '96', 'admin.php?ac=egoldmass', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('99', 'Manage', '1', '', '5', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('100', 'Manage Members', '1', '', '99', 'admin.php?ac=members', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('101', 'Deleted Members', '1', '', '99', 'admin.php?ac=deleted_members', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('102', 'Memberships', '1', '', '99', 'admin.php?ac=memberships', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('103', 'Referrals', '1', '', '5', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('104', 'Assign Referrals', '1', '', '103', 'admin.php?ac=assignreferrals', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('105', 'Upline Cleaner', '1', '', '103', 'admin.php?ac=cleanrefs', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('106', 'Tools', '1', '', '5', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('107', 'IP Filter', '1', '', '106', 'admin.php?ac=findmultips', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('108', 'Ban IP Accounts', '1', '', '106', 'admin.php?ac=ban_ip', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('109', 'Password Filter', '1', '', '106', 'admin.php?ac=passwordfilter', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('110', 'Restructure Downlines', '1', '', '106', 'admin.php?ac=fix', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('111', 'Delete Inactives', '1', '', '106', 'admin.php?ac=deleteinactive', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('112', 'Banners', '1', '', '4', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('113', 'Text Ads', '1', '', '4', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('114', 'Banners', '1', '', '112', 'admin.php?ac=banners', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('115', 'Featured Banners', '1', '', '112', 'admin.php?ac=fbanners', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('116', 'Featured Ads', '1', '', '113', 'admin.php?ac=fads', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('117', 'Featured Links', '1', '', '113', 'admin.php?ac=flinks', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('118', 'Groups', '1', '', '5', '', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('119', 'Edit Groups', '1', '', '118', 'admin.php?ac=member_groups_edit_group', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('120', 'Settings', '1', '', '3', 'admin.php?ac=settings&type=payouts', '2', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('121', 'Targeting', '1', '', '49', 'admin.php?ac=settings&type=targeting', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('122', 'Instant Messaging', '1', '', '51', 'admin.php?ac=settings&type=im', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('123', 'Addon Settings', '1', '', '49', 'admin.php?ac=settings&type=addons', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('124', 'Error Log', '1', '', '42', 'admin.php?ac=errorLog', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('125', 'Country Blacklist', '1', '', '44', 'admin.php?ac=countryBlacklist', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('126', 'Unprocessed Orders', '1', '', '2', 'admin.php?ac=unpaidOrders&', '2', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('127', 'Overall Stats', '1', '', '1', 'admin.php?ac=stats', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('128', 'Daily Breakdown', '1', '', '1', 'admin.php?ac=statsDaily', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('137', 'Game 911', '1', '', '5', 'admin.php?ac=settings&type=911', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('138', 'Country Fix', '1', '', '99', 'admin.php?ac=countryfix', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('139', 'Lottery', '0', 'lottery.png', '0', 'admin.php?ac=settings&type=lottery', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('140', 'Forum Settings', '0', 'forum.png', '0', 'admin.php?ac=settings&type=forumsett', '0', '0', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('141', 'Edit Terms', '1', '', '50', 'admin.php?ac=terms', '0', '1', '0');
INSERT INTO `admin_menu` (`id`, `title`, `type`, `icon`, `parent`, `url`, `order`, `append`, `module`) VALUES ('142', 'Admin Message', '1', '', '6', 'admin.php?ac=adminmsg', '0', '1', '0');


# dumping data for clickpla_mrv.admin_modules
INSERT INTO `admin_modules` (`id`, `type`, `active`) VALUES ('1', 'Paid To Click', '1');
INSERT INTO `admin_modules` (`id`, `type`, `active`) VALUES ('2', 'Paid To Signup', '1');
INSERT INTO `admin_modules` (`id`, `type`, `active`) VALUES ('3', 'Paid To Promote', '1');
INSERT INTO `admin_modules` (`id`, `type`, `active`) VALUES ('4', 'Paid To Read Emails', '1');
INSERT INTO `admin_modules` (`id`, `type`, `active`) VALUES ('5', 'Paid To Read Ads', '1');
INSERT INTO `admin_modules` (`id`, `type`, `active`) VALUES ('6', 'Click Exchange', '1');


# dumping data for clickpla_mrv.ads
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('5', '1k+ People Paid Everyweek!', '1331848876', 'tokpogs', 'D', '15', '8', '1010', 'www.neobux.com/?r=tokpogs', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '0', '', '', '', '0', '0', '0', '0', 'http://images.neobux.com/imagens/banner5.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('6', 'Upto $ .10 per click! Lets Go!', '1331849093', 'tokpogs', 'D', '16', '9', '984', 'http://www.ptcbox.com/?p=gc&gci=2252', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '0', '', '', '', '0', '0', '0', '0', 'http://www.ptcbox.com/images/Paid_to_Click_Box/PTC_BOX_468a.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('7', 'Get Paid $ up to 8 Levels!', '1331849267', 'tokpogs', 'D', '15', '8', '985', 'http://www.clixsense.com/?3677788', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '0', '', '', '', '0', '0', '0', '0', 'http://csstatic.com/banners/clixsense468x60a.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('9', 'Clixsense', '1331853912', 'Babyemmy22', 'D', '15', '8', '485', 'http://www.clixsense.com/?3974834', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '1000', '', '', '', '0', '0', '0', '0', 'http://csstatic.com/banners/clixsense468x60a.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('10', 'Ptcbox', '1331854161', 'Babyemmy22', 'D', '14', '7', '411', 'http://www.ptcbox.com/?rid=60350', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '1000', '', '', '', '0', '0', '0', '0', 'http://www.ptcbox.com/images/Paid_to_Click_Box/PTC_BOX_468a.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('11', 'Just one bux', '1331854576', 'Babyemmy22', 'D', '14', '7', '186', 'http://www.just-one-bux.com/?ref=babyemmy22', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '1000', '', '', '', '0', '0', '0', '0', 'http://www.just-one-bux.com/images/banners1.pn9', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('12', 'Wish on a star', '1331854919', 'Babyemmy22', 'D', '14', '7', '186', 'http://www.wishonastar.info/index.php?', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '1000', '', '', '', '0', '0', '0', '0', 'http://www.wishonastar.info/index.php?ref=babyemmy22', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('13', 'EasyHits4U', '1331855652', 'babyemmy22', 'D', '13', '6', '187', 'http://www.easyhits4u.com/?ref=babyemmy', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '1000', '', '', '', '0', '0', '0', '0', 'http://www.easyhits4u.com/banner.php', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('14', 'Hit2Hit', '1331867983', 'babyemmy22', 'D', '14', '7', '186', 'http://hit2hit.com/?rid105546', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '1000', '', '', '', '0', '0', '0', '0', '', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('15', 'Neobux', '1331868213', 'babyemmy22', 'D', '15', '7', '185', 'http://www.neobux.com/?r=ImeldaRamos', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '1000', '', '', '', '0', '0', '0', '0', 'Http://images.neobux.com/images/banner9.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('16', 'Varolo', '1331868501', 'babyemmy22', 'D', '14', '7', '186', 'http://varolo.com/village/imeldar20163', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '1000', '', '', '', '0', '0', '0', '0', '', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('17', 'click-planet', '1331908986', 'admin', 'D', '2', '1', '1098', 'http://click-planet.info/index.php?view=prices&sid=29TkM0M056SXhPRE01T0&sid2=29TkM&siduid=29&', '0', '10', '0.0003', '', 'green', '0', '1', '1', '0', '0', '', '', '', '0', '0', '0', '0', 'http://www.click-planet.info/banners/banner1.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('18', 'click-planet', '1331909653', 'admin', 'D', '2', '1', '998', 'http://click-planet.info/index.php?view=terms&sid=29TkM0M056SXhPRE01T0&sid2=29TkM&siduid=29&', '0', '10', '0.0003', '', 'blue', '0', '1', '1', '0', '0', '', '', '', '0', '0', '0', '0', 'http://www.click-planet.info/banners/banner1.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('19', 'My Money Maker', '1331923798', 'admin', 'A', '2', '1', '998', 'http://ajramos23.blogspot.com', '0', '25', '0.002', '', 'red', '0', '1', '1', '0', '0', '', '', '', '0', '0', '0', '0', 'http://static.easyhits4u.com/banners/543570.png?time=1331794841', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('20', 'Meet More Ref!', '1331929872', 'tokpogs', 'D', '15', '8', '985', 'http://www.ref4bux.com/?ref=tokpogs', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '0', '', '', '', '0', '0', '0', '0', 'http://i.imgur.com/QRv8D.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('22', 'Get Paid CASH, E-mail, Survey, Games &amp; More!', '1331931513', 'tokpogs', 'D', '3', '1', '997', 'http://www.inboxdollars.com/?r=ref8929890', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '0', 'United States', '', '', '0', '0', '0', '0', 'http://www.inboxdollars.com/graphics/creative/banners/468x60/468x60_1.gif', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('23', 'Get PAID up to 6 Levels', '1331931876', 'tokpogs', 'D', '3', '1', '997', 'http://www.varolo.com/village/tokpogsville', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '0', 'United States', '', '', '0', '0', '0', '0', '', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('24', 'Click for Bux $', '1331932201', 'tokpogs', 'D', '15', '8', '985', 'http://www.just-one-bux.com/?ref=tokpogs', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '0', '', '', '', '0', '0', '0', '0', 'http://www.just-one-bux.com/images/banner1.png', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('25', 'Home Biz Community', '1331932393', 'tokpogs', 'D', '15', '8', '985', 'http://tokpogs.blogspot.com/', '0', '10', '0.0003', '', '', '0', '1', '0', '0', '0', '', '', '', '0', '0', '0', '0', '', '');
INSERT INTO `ads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `active`, `upgrade`, `new`, `daily_limit`, `country`, `subtitle`, `icon`, `subtitle_on`, `icon_on`, `oviews`, `oviews_today`, `targetban`, `decline`) VALUES ('26', '     ', '1331994908', '', 'D', '0', '0', '10000', 'http://www.click-planet.info/gptnet.php', '0', '10', '0.0003', '', 'red', '0', '1', '0', '0', '0', '', '', '', '0', '0', '0', '0', '', '');






# dumping data for clickpla_mrv.banners
INSERT INTO `banners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `views_today`, `active`, `decline`) VALUES ('1', 'admin', '0', 'http://www.click-planet.info', 'http://www.click-planet.info/banners/banner1.gif', '204', '11', '89685', '1331337884', 'admin', '', '0', '0', '1165', '1', '');
INSERT INTO `banners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `views_today`, `active`, `decline`) VALUES ('4', 'My Money Maker', '0', 'http://ajramos23.blogspot.com', 'http://static.easyhits4u.com/banners/543570.png?time=1331535643', '8602', '13', '206837', '1331827603', '', '', '0', '0', '1256', '0', '');
INSERT INTO `banners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `views_today`, `active`, `decline`) VALUES ('5', 'Get Paid $ up to 8 Levels!', '0', 'http://www.clixsense.com/?3677788', 'http://csstatic.com/banners/clixsense468x60a.gif', '610', '6', '3390', '1331928280', 'tokpogs', '', '0', '0', '1254', '0', '');
INSERT INTO `banners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `views_today`, `active`, `decline`) VALUES ('6', '1k+ People Paid Everyweek!', '0', 'http://www.neobux.com/?r=tokpogs', 'http://images.neobux.com/imagens/banner5.gif', '722', '2', '3278', '1331928315', 'tokpogs', '', '0', '0', '1262', '0', '');
INSERT INTO `banners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `views_today`, `active`, `decline`) VALUES ('7', 'Upto $ .10 per click! Lets Go!', '0', 'http://www.ptcbox.com/?p=gc&gci=2265', 'http://www.ptcbox.com/images/Paid_to_Click_Box/PTC_BOX_468.gif', '740', '7', '3260', '1331928436', 'tokpogs', '', '0', '0', '1327', '0', '');
INSERT INTO `banners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `views_today`, `active`, `decline`) VALUES ('8', 'Meet More Ref!', '0', 'http://www.ref4bux.com/?ref=tokpogs', 'http://i.imgur.com/QRv8D.gif', '746', '7', '3254', '1331933082', 'tokpogs', '', '0', '0', '1269', '0', '');
INSERT INTO `banners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `views_today`, `active`, `decline`) VALUES ('9', 'Ju$t One Bux', '0', 'http://www.just-one-bux.com/?ref=tokpogs', 'http://www.just-one-bux.com/images/banner1.png', '761', '5', '3239', '1331933216', 'tokpogs', '', '0', '0', '1318', '0', '');
INSERT INTO `banners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `views_today`, `active`, `decline`) VALUES ('10', 'Get Paid CASH, E-mail, Survey, Games &amp; More!', '0', 'http://www.inboxdollars.com/?r=ref8929890', 'http://www.inboxdollars.com/graphics/creative/banners/468x60/468x60_2.gif', '805', '7', '3195', '1331933376', 'tokpogs', '', '0', '0', '1282', '0', '');






# dumping data for clickpla_mrv.cheat_answers
INSERT INTO `cheat_answers` (`id`, `qid`, `answer`) VALUES ('1', '1', 'Mars');
INSERT INTO `cheat_answers` (`id`, `qid`, `answer`) VALUES ('2', '1', 'Taco Bell ');
INSERT INTO `cheat_answers` (`id`, `qid`, `answer`) VALUES ('3', '1', 'Click-Planet');


# dumping data for clickpla_mrv.cheat_failed
INSERT INTO `cheat_failed` (`id`, `username`, `failed`, `last_failed`, `failed_today`) VALUES ('1', 'admin', '1', '1331975082', '1');


# dumping data for clickpla_mrv.cheat_questions
INSERT INTO `cheat_questions` (`id`, `question`, `aid`) VALUES ('1', 'What is the name of this site?', '3');


# dumping data for clickpla_mrv.cheat_session
INSERT INTO `cheat_session` (`id`, `username`, `trivia`, `loads`) VALUES ('5', '', '1', '1');


# dumping data for clickpla_mrv.click_history
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('51', 'tagore', ':5:6:7:9:10:11:12:13:14:15:20:24:16:25:', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('52', '', '', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('53', 'exell', '', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('54', 'exell', '', 'ce');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('55', 'exell', '', 'ptra');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('56', 'exell', '', 'ptre');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('57', 'gxch001', ':5:6:7:9:', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('58', 'gxch001', '', 'ce');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('59', 'gxch001', '', 'ptra');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('60', 'fales', ':5:6:7:9:10:11:12:13:14:15:16:20:24:25:', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('61', 'fales', ':1:', 'ce');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('62', 'fales', ':1:', 'ptra');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('63', 'admin', ':5:6:7:9:10:11:12:13:14:15:16:20:24:25:', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('64', 'berich', ':5:6:7:9:10:11:12:15:14:16:20:24:25:', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('65', 'berich', '', 'ce');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('66', 'berich', '', 'ptra');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('67', 'admin', ':1:', 'ce');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('68', 'admin', ':1:', 'ptra');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('69', 'yunghsin', ':5:6:7:9:10:11:12:13:14:15:16:20:24:25:', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('70', 'yunghsin', '', 'ce');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('71', 'yunghsin', ':1:', 'ptra');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('72', 'simmer', ':6:9:10:11:12:13:14:15:16:20:24:25:', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('73', 'simmer', '', 'ce');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('74', 'simmer', ':1:', 'ptra');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('75', 'l76303955', ':1:', 'ptre');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('76', 'l76303955', ':5:6:7:9:10:11:12:14:15:16:20:24:25:13:', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('77', 'l76303955', '', 'ce');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('78', 'l76303955', ':1:', 'ptra');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('79', 'cptc', ':1:', 'ptre');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('80', 'babyemmy22', ':19:17:18:5:6:7:20:22:23:24:25:', 'ptc');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('81', 'babyemmy22', ':1:', 'ce');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('82', 'babyemmy22', ':1:', 'ptra');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('83', 'babyemmy22', ':1:', 'ptre');
INSERT INTO `click_history` (`id`, `username`, `clicks`, `type`) VALUES ('84', 'calypso35', '', 'ptc');


# dumping data for clickpla_mrv.click_sessions
INSERT INTO `click_sessions` (`id`, `dsub`, `username`, `val`, `type`, `buttons`) VALUES ('30', '1331900056', '', '0', 'ptra', '');
INSERT INTO `click_sessions` (`id`, `dsub`, `username`, `val`, `type`, `buttons`) VALUES ('155', '1331949570', 'ADELAIDA264', '3', 'ptc', '');
INSERT INTO `click_sessions` (`id`, `dsub`, `username`, `val`, `type`, `buttons`) VALUES ('199', '1331958874', 'exell', '0', 'ptre', '');
INSERT INTO `click_sessions` (`id`, `dsub`, `username`, `val`, `type`, `buttons`) VALUES ('205', '1331959198', 'gxch001', '1', 'ptc', '');
INSERT INTO `click_sessions` (`id`, `dsub`, `username`, `val`, `type`, `buttons`) VALUES ('293', '1331972807', 'simmer', '1', 'ce', '');










# dumping data for clickpla_mrv.dailyhits
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.140.57.226', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.229.33.38', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.249.197.141', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('96.255.191.185', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.204.160.14', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.21.108.149', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.127.1.103', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.4.25.189', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.81.142.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.161.246.46', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.193.231.119', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.37.89.88', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.75.15.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.68.233.215', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.145.64.116', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.43.36.69', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.190.136.212', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('196.221.50.214', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.167.89.163', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('211.20.147.193', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('39.48.37.42', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('1.38.22.100', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.157.57.172', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.206.200.59', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.99.106.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.234.29.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('108.58.124.250', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.219.84.78', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.178.205.194', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.45.123.2', '0', 'tokpogs?rid=1421', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.203.82.86', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.147.142.249', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.92.151', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.249.86.17', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.121.206.231', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.204.85.91', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('81.22.141.110', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.119.39.170', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.210.118.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.34.90.208', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.198.143.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.177.247.123', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.154.40.139', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.122.188.109', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.49.123.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.156.232.142', '0', 'tokpogs?rid=7657', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.248.229.123', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.71.185.106', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('65.49.68.164', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.90.203.160', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.47.117', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.56.146.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.254.253.249', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.193.182.33', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.110.246.230', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.2.231', '0', 'tokpogs?rid=4299', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.108.88.17', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.160.122.96', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.85.100.21', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.200.252.165', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.45.84.79', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.56.196.170', '0', 'tokpogs?rid=3033', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('96.57.170.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.129.172.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.38.108.133', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.137.12.95', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.233.101.185', '0', 'tokpogs?gci=1595', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.130.69.27', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.203.35.68', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.234.49.234', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.139.202.226', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.198.246.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.52.50.227', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.54.122', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.88.40.195', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.178.106.129', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('96.18.4.216', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.50.153.147', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.180.247.207', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.109.152.180', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.123.123.63', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.215.248.154', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.251.180.149', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.201.9.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.192.85.142', '0', 'tokpogs?rid=72086', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.213.62.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.254.217.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.140.199.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.125.97.174', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.93.198.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.60.240.199', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.9.209.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('39.52.53.116', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.0.94', '0', 'tokpogs?rid=1078', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.200.170.103', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.39.65', '0', 'tokpogs?rid=61725', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.202.7.229', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.195.148.108', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.32.144', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.71.69.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.28.222.170', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.112.64.149', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.201.243.229', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('210.212.212.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.191.191.202', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.55.242.249', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.167.105.133', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.154.21.61', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.251.223.150', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('96.54.135.110', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('197.226.212.139', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.50.82.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.248.70.181', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('194.187.134.93', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.207.202.173', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.183.2.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.211.44.175', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.225.82.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.141.194.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.137.128.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.179.20.183', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.162.230.10', '0', 'tokpogs?rid=28276', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.249.2.178', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.133.199.188', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.128.161.132', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.229.10.3', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.196.124.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.46.68.197', '0', 'tokpogs?rid=19958', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('65.49.68.155', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('39.52.254.219', '0', 'tokpogs?rid=39365', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.178.24.158', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.113.44.190', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.230.112.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.72.107.134', '0', 'tokpogs?rid=19958', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.80.218.207', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.41.49.69', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.133.32.119', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.221.65.72', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.100.149.20', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.203.41.112', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.11.19.128', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.38.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.101.6.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('63.135.12.210', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.79.218.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.68.120.52', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.247.180.59', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.4.158.131', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.93.70.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.245.194.178', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.36.13.205', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.114.61.165', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.245.203.18', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('174.119.151.20', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.226.184.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.52.131.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.253.97.250', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.68.178.128', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('37.110.97.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.33.245.137', '0', 'tokpogs?rid=2115', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.245.219.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.38.215.138', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('37.16.170.117', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.200.130.228', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.166.204.144', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('103.3.223.44', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.109.168.250', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.116.95.177', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.152.194.117', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.18.231.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.214.233.90', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.213.161.132', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.229.26.111', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.78.60.28', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.107.192.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.36.118.36', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.178.167.207', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('62.157.50.68', '0', 'tokpogs?rid=36864', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('195.22.36.21', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.88.44.170', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.167.62.194', '0', 'tokpogs?rid=4299', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.242.202.243', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.180.64.234', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.85.42.111', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('223.29.229.142', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.111.151.69', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.3.171.20', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.204.114.160', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.24.243.150', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.153.69.211', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('223.255.227.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.7.18.236', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.164.238.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.110.197.117', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.169.133.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.165.91.243', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.101.62.38', '0', 'tokpogs?rid=6235', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('171.39.202.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.97.120.207', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.40.22.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.116.167.6', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.182.122.197', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('130.185.211.204', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.11.216.206', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.43.52.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.107.117.106', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.2.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.96.65.130', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('195.191.230.15', '0', 'tokpogs?gci=2218', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.106.118.236', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('61.131.13.165', '0', 'tokpogs?rid=6161', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.209.117.7', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.225.236.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.175.86.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.133.58.16', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.155.72.124', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('128.73.92.201', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.43.121.129', '0', 'tokpogs?rid=22599', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.130.18.240', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.177.251.103', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.202.115.150', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('97.120.70.46', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.254.13.210', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.21.152.78', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.3.35.74', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.190.200.77', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.54.44', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.177.171.27', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.51.183.104', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.242.69.180', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.6.181.221', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.204.136.235', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.47.239.61', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.84.249.39', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.227.36.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.102.253.86', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('74.67.222.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.238.51', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.64.140.92', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.12.200.188', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.144.246.28', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.200.18.203', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.68.242.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.100.63.27', '0', 'tokpogs?rid=15424', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.212.196', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('67.189.112.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.0.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.119.67.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('223.176.48.162', '0', 'tokpogs?gci=2217', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.31.86.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.214.152.112', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.168.13.129', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.11.108.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.27.48.151', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.185.145.249', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.177.142.46', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('141.101.14.191', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.162.243.108', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('64.134.225.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.249.228.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.212.39.99', '0', 'tokpogs?gci=562', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.71.161.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.227.78.143', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.189.222.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.112.27.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.121.238.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.200.13.229', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.130.13.217', '0', 'tokpogs?rid=29607', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.107.48.210', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.202.107.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.198.82.123', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.249.44.252', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.135.25.46', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.59.143.198', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.202.194.60', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.157.236.75', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.27.217.19', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.242.98.137', '0', 'tokpogs?rid=7657', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.77.93', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.54.244.196', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.33.141', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.250.22.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.35.245.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('141.0.8.155', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.9.213.92', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.34.16.172', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.97.8.215', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.248.26.104', '0', 'tokpogs?gci=2189', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.2.85', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.78.232.28', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.206.124.244', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('37.107.37.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.121.132.97', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.1.236.186', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.88.50.128', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.220.38.77', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.242.203.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.9.211.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.15.93', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.61.95.39', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.226.162.212', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.56.98.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.137.16.196', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.138.158.3', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.46.204.88', '0', 'tokpogs?gci=83', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.65.42.109', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.179.99.53', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.236.232.52', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.153.43.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('183.83.210.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.156.2.11', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.240.38.158', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.97.158.168', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('103.3.223.19', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.164.226.80', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.148.124.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.72.27.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.39.84', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.136.18.89', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.173.142.75', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.204.51.46', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.191.80.32', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.134.15.14', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.87.16.44', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.219.192.16', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.18.130.232', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.95.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('62.135.97.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.6.48.169', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.46.227.5', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.203.12.112', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.200.65.236', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.42.59.11', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.81.228.193', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.137.164.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.104.91.191', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.194.247.206', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.175.144.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('207.253.172.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('64.71.114.29', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.161.58.78', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.50.45.188', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.189.186.175', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.50.113.11', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('150.165.153.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.22.154.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.176.82.214', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('174.102.132.214', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.43.146.79', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.236.136.51', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.237.167.51', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.124.233.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.192.178.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.51.126.136', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.171.37.248', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.246.107.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.58.128', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.185.24.231', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.144.232.222', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.121.162.63', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.87.235.122', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.95.30', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.6.181.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.178.209.250', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.36.190.75', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.134.128.11', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('75.93.65.188', '0', 'tokpogs?gci=149', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.100.227.5', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.104.165.208', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.220.226.22', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.212.88.167', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.42.35.176', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.215.55.113', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.198.159.148', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.73.146.26', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.253.161.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.90.5.114', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.32.220.59', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('81.23.201.224', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.173.245.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('42.2.220.124', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.82.42.235', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.255.146.23', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('177.42.153.249', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.187.37.80', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.131.119.218', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('183.88.249.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.198.121.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.135.86.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.29.92.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('223.237.2.157', '0', 'tokpogs?rid=40858', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.252.168.130', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.234.68.49', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.223.94.118', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.255.118.74', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.141.248.233', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.119.230.232', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.234.130.151', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('171.97.142.44', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('219.91.238.42', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.246.181.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.255.152.114', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.187.201.77', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.97.159.243', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('42.119.218.204', '0', 'tokpogs?rid=3186', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.185.192.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.115.171.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.25.12.68', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('218.164.75.211', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('72.189.218.230', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('216.104.32.43', '0', 'tokpogs?rid=4359', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.126.108.235', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.127.131.76', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.198.82.233', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.63.138', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.29.232.235', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.2.248', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.246.206.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.179.10.150', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('67.185.244.192', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('221.120.216.234', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('222.127.223.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.235.94.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('184.9.192.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.200.246.203', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('173.237.120.164', '0', 'tokpogs?rid=466', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.194.250.85', '0', 'tokpogs?rid=51865', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.78.132.141', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.48.113.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.245.149.140', '0', 'tokpogs?rid=6235', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.123.179.200', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.133.196.204', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.67.58.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.207.14.228', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.167.228.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.183.60.117', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.247.180.153', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.74.46.3', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.199.141.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.62.223.251', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.215.140.231', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('193.106.201.222', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.104.50.199', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('223.224.4.16', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.255.90.18', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.198.90.60', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.71.183.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.197.1.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.206.10.189', '0', 'tokpogs?rid=6715', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('177.97.32.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.253.109.145', '0', 'tokpogs?rid=1129', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.82.59.15', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.90.119.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.206.237.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.18.113.223', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.206.42.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('218.213.193.133', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.89.211.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.237.212.5', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.14.28.167', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.53.119.171', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.210.102.223', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('90.233.128.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.82.80.87', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.18.231.12', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.76.183.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.118.214.60', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.108.20.108', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.226.63.160', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.134.77.163', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.88.24.136', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('66.189.107.189', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.77.86.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.213.93.15', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.189.226.233', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.236.152.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('223.205.118.181', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.96.203.61', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.9.167.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.78.54.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.40.58.246', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('174.1.16.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.73.36.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.61.39.216', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.128.7.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('61.245.168.39', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.71.37.92', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.52.7.9', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.121.158.136', '0', 'tokpogs?gci=2217', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.114.213.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.8.103.211', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.90.108.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.198.82.80', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.194.241.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.146.191.14', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.160.240.137', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.1.20.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.146.150.179', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.49.251.119', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.253.63.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.178.144.198', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.7.156.126', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.184.24.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.141.137.101', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.140.232.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('223.19.182.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.136.155.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.209.78.18', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.173.121.55', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.125.237.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.191.72.239', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('221.5.67.214', '0', 'tokpogs?rid=523', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.142.208.171', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.222.184.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('149.3.11.12', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('171.97.33.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.44.42.116', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.170.203.55', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('106.204.197.244', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.244.87', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.197.169.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.42.214.165', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.55.16.117', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.2.171', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.63.148.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.234.29.33', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.246.80.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.169.135.15', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.202.213.24', '0', 'tokpogs?rid=9631', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('193.107.130.225', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.214.166.32', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.227.142', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.216.93.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.112.130.181', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.212.167.223', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.203.23.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.24.162.141', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.28.246.117', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.24.246.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.201.99.59', '0', 'tokpogs?rid=16115', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.182.8.122', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.96.201.189', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.128.107.39', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.73.220.60', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.95.225', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.96.43.52', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.211.171.144', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.149.3.132', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.200.199.205', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.101.219.28', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.249.209.254', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.1.76.84', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.164.240.234', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('75.167.30.167', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.197.239.20', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.52.254.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.184.232.126', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.35.111.85', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.5.57.38', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('96.250.94.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.42.24.234', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.247.248.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.78.227.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.28.70.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.2.110', '0', 'tokpogs?rid=6161', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.206.220.106', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.51.115.140', '0', 'tokpogs?rid=1252', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.79.243.154', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.253.206.238', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.98.202', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.33.255.188', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.174.119.146', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.249.45.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.123.47.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.178.228.240', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.169.87.94', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('219.95.19.89', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.112.0.229', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.216.217.180', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.159.81.179', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('61.239.151.189', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.208.88.96', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.194.0', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.186.221.49', '0', 'tokpogs?rid=6235', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.54.244.20', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.15.242.189', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.92.107.246', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.79.4.239', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.197.219.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.209.250', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('72.2.81.16', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.31.11.216', '0', 'tokpogs?gci=1182', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.81.4.189', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.166.222.121', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.249.241.86', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.241.33.137', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.74.12.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.131.180.225', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.143.198.80', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.165.14.114', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.21.92.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.31.22.138', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.194.240.237', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.226.217.148', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.154.155.15', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.64.47.41', '0', 'tokpogs?gci=1371', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.32.16.144', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.243.217.89', '0', 'tokpogs?gci=2170', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.253.147.116', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.55.17.170', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.248.111.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.162.211.205', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.3.185.13', '0', 'tokpogs?gci=1182', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.82.95.86', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.210.20.23', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.200.250.226', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.206.97.95', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.87.174.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.116.123.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.247.122.80', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.75.118', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.175.51.119', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.199.152.24', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.122.193.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.137.112.11', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.71.98.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.200.73.103', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.198.117.121', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.88.36.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.107.201.110', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.94.22.204', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.152.202.96', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.146.237.82', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.119.217.28', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.90.164.58', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.183.222.173', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('195.191.201.3', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.161.222.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('75.168.104.211', '0', 'tokpogs?rid=2747', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.178.172.86', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.47.116.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('139.195.79.75', '0', 'tokpogs?rid=40614', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('75.201.223.179', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.174.216.146', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.233.151.14', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.247.172.234', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('173.32.48.36', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.160.49.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('64.212.73.53', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.82.234.93', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.168.213.43', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.2.167', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.189.186.111', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.245.20.144', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.203.15.131', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.251.253.212', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.149.168.23', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.4.26', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.129.248.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.166.7.0', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.207.200.198', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.194.29.18', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('177.43.220.146', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('173.245.79.68', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.164.63.128', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.38.68', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.147.142.233', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.8.124.143', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.81.82.146', '0', 'tokpogs?gci=2091', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.121.194.15', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.59.27.213', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.136.95.174', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('106.204.198.166', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('184.95.45.232', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.67.45.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.101.224.205', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.42.232.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('74.125.112.80', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('74.4.94.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.194.154.142', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.226.63.154', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.185.83.179', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('205.164.34.243', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.27.122.31', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.137.72.36', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.213.94.215', '0', 'tokpogs?rid=23505', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('219.71.129.90', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.213.128.5', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.73.1.119', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.157.1.97', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.18.231.20', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('61.183.197.12', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('64.32.82.31', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.226.154.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.254.61.93', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.165.139.94', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.107.31.20', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('103.3.223.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.21.220.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.222.53.186', '0', 'tokpogs?rid=6335', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.68.202.218', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.39.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.80.28.201', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.58.212.43', '0', 'tokpogs?gci=1182', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.204.84.149', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.16.234.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.79.36.75', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.88.58.56', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.10.14.14', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.93.133.58', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('64.237.186.193', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.230.146.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.11.157.109', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.92.58', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.215.253.246', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('75.83.17.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.204.154.248', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('108.11.7.246', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('106.200.236.57', '0', 'tokpogs?rid=2280', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('66.249.71.21', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.50.6.190', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.49.105.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.242.52.59', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.252.110.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('67.234.68.244', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.227.220.85', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('195.69.169.104', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.99.118', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.130.161.148', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.206.93.224', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.3.198.94', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.235.162.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.38.76', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.248.9.180', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.104.20.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.107.213.95', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.248.61.251', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.74.171.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.106.47.202', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.204.160.166', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.134.89.126', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.242.22.169', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.133.214.144', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.55.41.128', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('68.63.152.111', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.231.82.175', '0', 'tokpogs?rid=81876', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('218.189.250.58', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.98.244.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.104.168.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.43.100.7', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.134.63.210', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.203.6.87', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.162.118.166', '0', 'tokpogs?rid=2553', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.185.253.214', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.171.245.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.219.95.141', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.118.131.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('207.255.137.194', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.196.250.134', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.177.206.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('171.37.19.47', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('216.172.138.96', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.223.94.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.191.123.79', '0', 'tokpogs?rid=4927', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.173.60.142', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.132.96.45', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.22.179.15', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.179.118.105', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.230.228.40', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.210.75.222', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.107.74.110', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.193.98.184', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.206.97.82', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.192.237.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.191.183.122', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.63.35.75', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.95.20.19', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.139.22.244', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.110.181.130', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.185.233.91', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.122.241.68', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.80.140.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.202.116.117', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.254.53.128', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.164.187.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.47.109', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.87.231.123', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.251.141.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.134.70.239', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.194.30.227', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.13.73.153', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.180.33.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.246.147.226', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.236.224.36', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.209.68.131', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('90.181.173.251', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.53.241.23', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.111.172.143', '0', 'tokpogs?rid=5187', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.152.194.130', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.208.118.49', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.211.219.12', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.144.126.206', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.60.150.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.178.194.33', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.73.34.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.86.44.23', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.27.166.50', '0', 'tokpogs?rid=8374', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('1.20.0.163', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.18.58.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.137.245.8', '0', 'tokpogs?gci=2158', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.112.77.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.189.215.128', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.53.33.154', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('108.200.61.110', '0', 'tokpogs?rid=77370', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.242.44.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.176.43.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('39.45.106.216', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.106.12.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.6.226.196', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.195.185.71', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('139.194.214.158', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.198.77.183', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.59.115.192', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.244.23.29', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.139.56.232', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.201.143.147', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('150.70.75.33', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.249.94.181', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.9.160.187', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.8.77', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.249.83.192', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('218.102.84.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.216.19.24', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.211.184.67', '0', 'tokpogs?rid=46907', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.154.106.22', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.6.15.137', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.146.204.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.196.142.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.112.122.43', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.222.114.60', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.47.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.37.206.12', '0', 'tokpogs?rid=9539', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.147.61.249', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.6.181.207', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('217.8.92.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.247.108.183', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.226.6.82', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.236.212.52', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.103.178.148', '0', 'tokpogs?gci=2271', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.123.81.111', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('39.209.84.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('177.21.18.146', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('130.43.79.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.152.139', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.52.169', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.38.24.158', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.133.58.114', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.39.19.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.37', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.0.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('61.245.168.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.180.117.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.88.43.12', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.86', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.253.0.229', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.28.171.69', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.107.175.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.198.122.17', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.246.202.134', '0', 'tokpogs?rid=1924', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.254.233.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.180.17.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.8.40.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('62.213.32.186', '0', 'tokpogs?rid=54134', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('61.167.176.54', '0', 'tokpogs?rid=193351', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.135.85.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.172.234.7', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.236.104.150', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.210.231.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('177.35.244.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.24.186.183', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.185.5.129', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('211.140.172.186', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.180.218.254', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.68.98.15', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.1.189.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('96.55.29.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.62', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('74.205.218.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.147.67.213', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.31.254.77', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.195.105.3', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.55.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.132.94.93', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.212.140.0', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.92.29.127', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('184.82.146.124', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.108.250.38', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.1.66.138', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.6.181.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.51.211.161', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.203.59.115', '0', 'tokpogs?rid=7657', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.85.27.17', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.149.136.76', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.141.243.120', '0', 'tokpogs?rid=9631', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('212.86.239.86', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('183.82.33.0', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.158.205.204', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.168.94.143', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.97.51.34', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.152.202.66', '0', 'tokpogs?rid=6335', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.160.18.44', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.6.206.151', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.110.153.200', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.236.42.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.28.123.116', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.123.130.199', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.234.127.28', '0', 'tokpogs?rid=62827', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.72.158.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.97.148.18', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.226.0.142', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('142.179.73.163', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.151.208.225', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.184.34.224', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('172.129.151.243', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.249.179.69', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.36.86.190', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.142.91.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.136.8.93', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.137.179.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.100.156.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.178.223.85', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.228.150.173', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.113.170.85', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.72.123.22', '0', 'tokpogs?gci=2217', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.140.45.119', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.135.134.43', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.51.224.76', '0', 'tokpogs?rid=9631', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.159.100.153', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.51.96.224', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.52.9.131', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.120.204.133', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.105.237.239', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.196.129.32', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.136.94.251', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('177.39.248.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.25.105.80', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('1.53.18.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.84.198.138', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.24.144.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.197.129.77', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.142.210', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('207.245.236.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.204.138.90', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.101.93.228', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.164.57.210', '0', 'tokpogs?rid=8859', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.112.94.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.196.130.238', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.99.197.87', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.166.7.45', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.212.43.77', '0', 'tokpogs?rid=64721', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('96.3.31.29', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('66.176.153.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('184.34.0.167', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.229.13.59', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.95.47.174', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.21.139.148', '0', 'tokpogs?rid=2747', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.212.255.188', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.223.43.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.87.174.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.238.151', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.192.1.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.141.39.193', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.135.192.5', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.253.54.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.17.214', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.82.56.252', '0', 'tokpogs?gci=1859', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.85.186.23', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.183.110.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('141.138.113.136', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.204.120.239', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.235.155.97', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('65.49.36.228', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('196.206.92.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.55.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.43.140.202', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.191.131.176', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.90.208.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.175.38.148', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.44.23.149', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.241.247.231', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.50.71.191', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.82.87.56', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.141.234.220', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.97.192.56', '0', 'tokpogs?rid=1078', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.58.242.186', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.90.33.51', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.76.110.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.249.66.105', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('67.173.219.189', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('211.76.35.26', '0', 'tokpogs?rid=1129', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.62.186', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.169.167.47', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.167.18.123', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.212.200.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.35.101.124', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.1.29.214', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.206.83.77', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.186.145.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.80.127.56', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.9.206.196', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.42.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.69.35.221', '0', 'tokpogs?gci=782', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.109.161.100', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.164.176.232', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.242.222.197', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.20.255.0', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.120.232.73', '0', 'tokpogs?rid=21405', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.141.197.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.201.178.173', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.206.232.95', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.146.238.62', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.112.246.137', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('207.112.124.86', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.113.114.228', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.247.220.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.201.112.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('150.70.172.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.1.11.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.42.76.133', '0', 'tokpogs?gci=1182', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.82.14.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.152.201.178', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.33.236.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.73.213', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.223.129.34', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.247.250.251', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('68.35.23.189', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.198.239.113', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.241.105.218', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.225.20.126', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.38.88', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('223.205.116.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.238.161.197', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.2.144.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.165.237.94', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('65.183.216.118', '0', 'tokpogs?rid=2557', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.164.225.60', '0', 'tokpogs?rid=16405', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.104.57.144', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.67.194.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.202.181.190', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.87.176.18', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.162.192.91', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.64.108.8', '0', 'tokpogs?gci=562', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('212.117.5.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.97.197.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.32.31.166', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.84.16.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.33.216.31', '0', 'tokpogs?rid=59592', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.111.132.170', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.226.243.113', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.80.135.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.7.131', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('200.108.107.103', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.144.4.90', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.237.228.143', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.134.228.178', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.7.222.254', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.193.16.124', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.85.142.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.161.77.191', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.33.226.85', '0', 'tokpogs?rid=5327', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.167.32.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.206.226.104', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.124.70.187', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.80.82.218', '0', 'tokpogs?rid=2747', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.19.234', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('132.68.62.6', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.185.36.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.167.248.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.16.116', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.198.228.109', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.113.208.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.250.80.87', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('81.196.77.19', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.241.144.114', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.83.34.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('218.24.179.199', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('75.12.44.210', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.26.175.130', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.130.27.0', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.109.190.235', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.216.173.26', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.110.229.156', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.169', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.194.202.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.108.93.84', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.218.86.41', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.162.168.206', '0', 'tokpogs?rid=1300', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.79.104.8', '0', 'tokpogs?rid=3485', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.58.229.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.19.8.124', '0', 'tokpogs?rid=2354', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.211.148.240', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.151.41.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.131.141.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.167.26.238', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.140.230.193', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.124.65.114', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.177.166.89', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.141.237.175', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.174.3.255', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.52.43.191', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.249.125.29', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.252.103.245', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.84.188.188', '0', 'tokpogs?rid=21885', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.14.126.17', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('222.127.15.130', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.45.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('103.3.220.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.81.212.122', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.97.48.189', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.50.195.253', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.132.249.171', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.58.155', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('194.145.163.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.163.29.8', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.184.179.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.21.38.49', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.240.48.195', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.175.26.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.190.6.5', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('1.22.81.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.130.120.43', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.90.19.24', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.202.105.7', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.206.63.126', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.213.223.56', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.137.113.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.236.149.195', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.98.15.231', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('207.224.120.232', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.152.12.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.51.1.100', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('90.191.151.177', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.143.127.27', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.164.228.192', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.133.124.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.50.176.185', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.195.160.28', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.162.144.204', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.151.74.76', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.38.98.199', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('72.70.143.118', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.68.253.215', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.251.12.49', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.164.60.251', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.198.176.153', '0', 'tokpogs?rid=18587', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.226.222.114', '0', 'tokpogs?rid=6209', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('183.83.251.112', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.198.90.149', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.74.106.11', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.205.233.36', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('108.93.127.32', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.92.134.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('217.118.78.108', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('1.36.4.166', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.231.118.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.28.209.245', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.68.210.79', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('197.15.37.157', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.31.240.220', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.105.156.154', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.16.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('166.147.71.140', '0', 'tokpogs?rid=52035', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.135.137.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.21.181.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.161.71.101', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.238.146.148', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.215.138.46', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.108.64.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('1.52.85.210', '0', 'tokpogs?rid=17634', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.20.107.138', '0', 'tokpogs?rid=6161', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.95.209.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.246.52.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.34.103', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.3.248', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.212.71.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.132.196.24', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.100.135.161', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.130.1.164', '0', 'tokpogs?rid=20180', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.109.218.3', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.48.55.20', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.30.133.248', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.97.93.110', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.192.147.44', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.154.54.255', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.26.32.169', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('108.8.51.24', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.28.72.72', '0', 'tokpogs?rid=20497', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.62.71.190', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.210.253.28', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.36.161.191', '0', 'tokpogs?rid=5187', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('170.51.251.169', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.194.170.253', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.210.196.126', '0', 'tokpogs?rid=6209', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('74.14.90.69', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.174.52.34', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.142.170.71', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.197.192.211', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.242.21.16', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('81.82.109.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.29.200.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.253.230.64', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.167.104.210', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.202.64.96', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.199.85.199', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.165.48.230', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.112.80.72', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.48.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.71.13.61', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.108.29.110', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.202.138.61', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.233.95.235', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.137.34.250', '0', 'tokpogs?rid=9008', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.237.82.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('198.82.91.132', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.222.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.233.92.7', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.81.250.139', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('212.39.103.178', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.193.111.244', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.94.223.78', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.26.38.179', '0', 'tokpogs?gci=285', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.204.96', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.60.205.114', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.94.134.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('72.218.74.186', '0', 'tokpogs?rid=10380', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.254.228.188', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.241.241.156', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.3.39.12', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.45.17.213', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.177.61.153', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.100.14.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.189.152.75', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('66.143.45.14', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('212.37.159.212', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.82.202.112', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.48.106.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.94.229.101', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.100.17.64', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.120.33.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('216.245.251.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.62.49.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.92.107.227', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.57.158.135', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.143.89.201', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.228.216.105', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.212.151.172', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.115.193.249', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.20.47.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.52.76.176', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.148.118.229', '0', 'tokpogs?rid=475', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('141.0.10.200', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.10.156.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.47.118', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.98.254.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.18.231.17', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.81.6.153', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.74.49.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.32.154', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.119.33.203', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.81.173.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.250.67.158', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.144.83.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.14.234.183', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.109.154.8', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('198.228.234.60', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.206.13.221', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.52.249.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.55.7.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.139.135.56', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.214.182.135', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.116.18.215', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.129.192.40', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.51.162.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.149.241.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.253.166.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.1.167.26', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.223.47.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.228.139.199', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.59.199.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.43.12.215', '0', 'tokpogs?rid=35355', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.111.157.210', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.68.129.58', '0', 'tokpogs?rid=19958', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.135.104.71', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.164.101.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.120.172.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('222.97.146.235', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.218.90.187', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.239.85.46', '0', 'tokpogs?rid=1129', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.49.224.213', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.147.88.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.52.150', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.43.81.104', '0', 'tokpogs?rid=3186', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.161.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.130.39.94', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.120.230.221', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.134.185.250', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.104.153.69', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.185.21.95', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('108.27.20.120', '0', 'tokpogs?rid=6235', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.186.233.204', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.197.27.179', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('184.75.217.193', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.103.154.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.224.76.253', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.213.6.5', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.45.5.186', '0', 'tokpogs?rid=76412', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.43.58.144', '0', 'tokpogs?rid=13656', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.44.172.154', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.28.207.96', '0', 'tokpogs?gci=2217', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.105.137.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.150.222.89', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.160.29.237', '0', 'tokpogs?rid=6235', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.169.169.249', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.137.10.44', '0', 'tokpogs?rid=35965', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.56.134.63', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.112.91.158', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.31.221', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('217.118.66.63', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('81.182.62.74', '0', 'tokpogs?rid=25368', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.14.196.78', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('196.206.206.122', '0', 'tokpogs?gci=2170', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.1.218.137', '0', 'tokpogs?rid=92323', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.53.166.174', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.225.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.135.214.27', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.2.185.100', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.92.123.193', '0', 'tokpogs?rid=343', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.4.211.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.2.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.175.173.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.69.247.82', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.139.246.60', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('173.254.207.53', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.164.159.222', '0', 'tokpogs?gci=1152', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('212.66.50.96', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('61.245.165.43', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.228.148.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.17.233.194', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.234.101.185', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.143.159.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.145.112.203', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('106.200.253.43', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.19.228.163', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.233.39.160', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.211.141', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.55.22.131', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.168.241.176', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.134.94.136', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.97.186.217', '0', 'tokpogs?gci=374', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.118.42.53', '0', 'tokpogs?gci=1451', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.227.212.190', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.52.155.130', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.180.101.188', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.76.150.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.235.6.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.125.29.46', '0', 'tokpogs?gci=83', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.103.141.111', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.3.25.225', '0', 'tokpogs?rid=37373', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.225.233', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('196.38.253.226', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.226.244.192', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.140.89.230', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.31.224.113', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.99.58.210', '0', 'tokpogs?rid=50547', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.108.213.132', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.54.127.199', '0', 'tokpogs?rid=74745', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('196.25.255.195', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.66.56.47', '0', 'tokpogs?rid=343', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.117.107.131', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.228.86.17', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('61.93.76.46', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.225.108.88', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.69.160.251', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.87.133.228', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.102.47.133', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.0.165.106', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.72.72.232', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.3.188.254', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.254.80.40', '0', 'tokpogs?rid=1129', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.164.25.4', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.238.106.167', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.218.121.63', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.60.163.112', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.126.3.133', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.222.184.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.77.160.73', '0', 'tokpogs?rid=28278', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.18.231.30', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.54.3.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.1.25.202', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('174.88.253.104', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.179.166.34', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('207.81.35.185', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.73.130.181', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.186.62.212', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.37.19.195', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.246.112.88', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.156.8.15', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.125.215.148', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.101.63.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.202.0.204', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.38.214.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.59.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('159.205.101.68', '0', 'tokpogs?rid=87337', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.242.236.91', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.239.23.163', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.253.44.192', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.42.18.17', '0', 'tokpogs?gci=2217', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.47.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.205.194.121', '0', 'tokpogs?gci=2170', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.26.44.199', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.190.37.20', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('219.84.146.59', '0', 'tokpogs?rid=4407', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.63.29', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('195.54.40.32', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.64.235.245', '0', 'tokpogs?rid=6335', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.158.85', '0', 'tokpogs?rid=6335', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.12.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.194.49.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.78.95.81', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.186.188.73', '0', 'tokpogs?rid=3254', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.84.48.177', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.170.90.116', '0', 'tokpogs?rid=2852', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('108.49.1.123', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.163.94.230', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.6.231.86', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.162.217', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.85.185.197', '0', 'tokpogs?rid=16545', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.176.165.55', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.35.185.83', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('67.181.188.189', '0', 'tokpogs?rid=2747', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.40.215.162', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.194.249.192', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.121.13.173', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('72.29.44.100', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('172.163.158.225', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.207.42.83', '0', 'tokpogs?rid=40162', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.15.220.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.32.109.225', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('74.51.82.88', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('24.186.123.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.68.26.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.154.128.130', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.74.130.147', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.224.139.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.89.56.198', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.92.152', '0', 'tokpogs?rid=2747', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('217.118.95.161', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.42.55.191', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('150.70.172.207', '0', 'tokpogs?rid=2747', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.221.219.45', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('194.63.239.233', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.156.8.11', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.154.157', '0', 'tokpogs?rid=6335', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.212.198', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('39.45.68.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.197.223.233', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.252.45.50', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.244.157.254', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.100.53.251', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.135.230.53', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.53.119', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.163.76.104', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.193.185.39', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.102.15.206', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.93.20.187', '0', 'tokpogs?rid=66083', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.95.22', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.97.24.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.167.83.156', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.186.3.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('81.198.52.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('183.82.249.8', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.36.247.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.70.28.224', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('183.82.68.36', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.16.227.254', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.132.241.232', '0', 'tokpogs?rid=14589', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.41.153.163', '0', 'tokpogs?gci=1182', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('108.48.115.124', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('67.81.175.213', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.70.81.96', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.191.138.42', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('198.228.225.23', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.224.50.120', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.203.54.123', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.61.12.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.172.15.29', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.74.241.134', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('192.248.43.10', '0', 'tokpogs?rid=51610', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.115.56.158', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.83.39.18', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.94.195.197', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.172.153.111', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.32.137', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.30.225.197', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.0.109.31', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.244.140.184', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.146.39.213', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('217.164.223.166', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.199.29.237', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.79.198', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.38.64.110', '0', 'tokpogs?rid=39084', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.19.23.45', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.138.242.26', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.55.72.14', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.81.13.236', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.168.220.156', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.142.51.175', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.213.99.24', '0', 'tokpogs?rid=4569', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.39.72', '0', 'tokpogs?rid=3186', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.133.178.235', '0', 'tokpogs?rid=366', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.28.161.254', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.123.95.165', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.153.163.208', '0', 'tokpogs?rid=226', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.95.28', '0', 'tokpogs?rid=47808', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.64.126.223', '0', 'tokpogs?gci=1684', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.210.105.30', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.22.218.7', '0', 'tokpogs?rid=26443', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('65.49.68.163', '0', 'tokpogs?rid=16628', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('140.113.138.225', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('212.115.235.152', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.149.37.42', '0', 'tokpogs?gci=83', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.35.206.234', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.79.3.64', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.179.79.139', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.31.21', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('128.73.179.105', '0', 'tokpogs?gci=83', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.103.26.15', '0', 'tokpogs?rid=4340', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.141.229.60', '0', 'tokpogs?gci=1202', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('204.152.219.18', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.200.179.193', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.189.204.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.116.126.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.179.156.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.182.41.122', '0', 'tokpogs?rid=3403', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.194.29.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('217.64.141.3', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.21.178.91', '0', 'tokpogs?rid=14581', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.242.72.114', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.48.107.6', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('212.93.104.71', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.138.2.245', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.48.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.20.51.142', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.39.21.75', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('173.79.64.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.113.115.60', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('90.142.167.38', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('183.39.140.49', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.76.13.22', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.102.75.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.147.145.135', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.202.91.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.68.201.31', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.95', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.129.108.165', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.49', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.68.162.170', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.5.145.212', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.97.195.162', '0', 'tokpogs?rid=33472', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.101.156.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.93', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('183.81.66.157', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.53', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.163.203.87', '0', 'tokpogs?rid=18226', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.97.95.227', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.55.17.55', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.193.162.192', '0', 'tokpogs?rid=7657', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.38', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.92', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.195.166.112', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.58', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.72', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.73.125.135', '0', 'tokpogs?rid=6806', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.127.138.35', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.42', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.27.40.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('65.92.140.120', '0', 'tokpogs?rid=4299', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.186.3.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.212.132.227', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.209.206.134', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.66', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('144.118.210.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('206.205.54.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.154.130.229', '0', 'tokpogs?gci=1182', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.22', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.55.236.0', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.211.233.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.63', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.119.116.245', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.248.145.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.52', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.20', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.225.120.111', '0', 'tokpogs?rid=3867', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.27.29.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.210.243.91', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.27', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.190.193.49', '0', 'tokpogs?rid=1086', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.202.134.187', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.148.63.237', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.21', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.93.229.26', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.85', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.61.224.53', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.249.25.252', '0', 'tokpogs?rid=7657', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.67', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.28.44.186', '0', 'tokpogs?rid=1129', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.249.85.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.47', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.89', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.152.63.144', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.92.152.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.99.20.229', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.108.64', '0', 'tokpogs?rid=21312', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('205.250.69.224', '0', 'tokpogs?gci=138', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.50', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.44', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.127.139.184', '0', 'tokpogs?rid=6161', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.239.243.110', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.131.67.161', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.211.129.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.200.20.7', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.33', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('145.236.28.111', '0', 'tokpogs?rid=7346', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('217.118.66.11', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.54', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.84', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.90', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.104.146.220', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.53.228.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.163.72.208', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.179.54.128', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.253.104.255', '0', 'tokpogs?rid=6335', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.61', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.75.37.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.64.55.175', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.26', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.139.212.226', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.74', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.122.39', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.153.47.234', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.239.223.177', '0', 'tokpogs?rid=152', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.18.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('222.47.124.100', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.97.121.157', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('171.226.21.59', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('1.38.24.144', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('75.130.185.93', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.127.91.219', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.81', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.233.92.160', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.59', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.218.45.104', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.177.253.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.193.120.143', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('221.1.60.105', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.119.52.104', '0', 'tokpogs?rid=1198', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.192.181.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.88', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.79', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('222.37.157.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.87.241.89', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('108.64.205.216', '0', 'tokpogs?rid=6235', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('50.66.56.109', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.146.196.44', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.35', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.92.26.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.255.11.236', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.91', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.83.46.186', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.166.32.252', '0', 'tokpogs?rid=2747', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.97.231.171', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('158.181.6.33', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.51', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.87.235.148', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.146.20.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('76.117.184.255', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.108.168', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.88.50.98', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.82.155.109', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.26.235.47', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.72.211.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.91.131.120', '0', 'tokpogs?gci=149', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('106.203.43.204', '0', 'tokpogs?gci=2217', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.222.68.61', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.149.3.136', '0', 'tokpogs?rid=26356', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('149.200.70.122', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.134.14.132', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.27.223.160', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.216.122.225', '0', 'tokpogs?rid=51', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.187.174.45', '0', 'tokpogs?rid=5187', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.144.102.29', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('201.141.71.166', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.107.32.153', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.186.167.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('81.180.29.103', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.138.83.237', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.82.166.230', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('141.0.9.59', '0', 'tokpogs?gci=1202', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.217.207', '0', 'tokpogs?rid=6335', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.114.248.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.246.111.211', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.43.122.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.192.104.17', '0', 'tokpogs?gci=1182', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.46.76.84', '0', 'tokpogs?rid=6715', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.165.79.154', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.175.151.42', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('212.93.105.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('190.20.54.165', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.24.207.221', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('37.115.250.233', '0', 'tokpogs?rid=13947', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('72.35.127.220', '0', 'tokpogs?rid=55793', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.193.74.24', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.122.198.62', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('128.74.0.10', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.173.178.12', '0', 'tokpogs?rid=1895', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.208.231.237', '0', 'tokpogs?gci=1182', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.112.89.7', '0', 'tokpogs?rid=5211', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.246.66.97', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('103.3.220.30', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.244.203.28', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('216.67.52.69', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.19.105.55', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.28.96.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.24.123.178', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.223.164.205', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.87.19.248', '0', 'tokpogs?rid=60731', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.49.113.163', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.63.252.30', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.133.150.166', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('37.55.191.201', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.113.254.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.179.114.148', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.116.208.59', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('37.55.6.190', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.163.52.208', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.49.22.230', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.198.52.182', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.53.153.224', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.139.63.101', '0', 'tokpogs?rid=49467', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.70', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.26.40.173', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.115.248.47', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.130.44.231', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.165.15.180', '0', 'tokpogs?rid=97', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('61.18.170.85', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.161.115.49', '0', 'tokpogs?gci=1182', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.186.232.238', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.49.139.4', '0', 'tokpogs?rid=1129', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.109.201.198', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('192.55.157.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('187.137.81.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.138.48.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('210.212.144.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.156.122.30', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.93.200.63', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.108.192.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.25.83.64', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.118.217.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('151.40.181.52', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.130.16.32', '0', 'tokpogs?rid=1129', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.177.83.93', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.154.99.36', '0', 'tokpogs?gci=1792', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.45.192.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.113.207.248', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('176.92.106.135', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.144.17.31', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.205.25.19', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('70.75.196.135', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.193.115.245', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('113.193.114.129', '0', 'tokpogs?rid=3186', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.93.130.252', '0', 'tokpogs?rid=16628', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.22.130.94', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.253.212.8', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('197.2.143.45', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.49.25.163', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('195.60.175.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.49.26.239', '0', 'tokpogs?gci=539', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.123.173.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.180.2.93', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.21.242.18', '0', 'tokpogs?rid=118', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('194.143.151.193', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.153.32.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.156.8.12', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.200.159.239', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.253.240.173', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.127.15.90', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.26.12.97', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.18.197.9', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.39.37.11', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.29', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('66.249.71.232', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.41', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.40.161.32', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.24', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.136.106.68', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.241.27.129', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.73', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.31', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.206.175.18', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.154.55.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.97.218.207', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.191.121.99', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.36', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.211.153.158', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.34', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.56', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.57', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.30', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.171.247.136', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.88.37.202', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.80', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.28', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.78', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.255.1.60', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.200.14.245', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.97.59.227', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.243.82.171', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.122.211.145', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('174.118.214.8', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.138.34.64', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.96.11.214', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.41.169.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.89.153.193', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.118.161.145', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('217.68.80.55', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.251.8.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.64.91.212', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.199.238.113', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('222.124.94.13', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.98.216.77', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.214.163.6', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.82.94.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.214.169.6', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.153.214.188', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.153.163.209', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.83.32.94', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.64.235.91', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.179.215.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.64.235.249', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.153.214.182', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.36.152.153', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.226.66.178', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.153.163.186', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('115.184.42.78', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.99.111.147', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('106.201.250.38', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.168.98.186', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.192.36.139', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.33.184.183', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.226.33.220', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('90.154.140.190', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.193.123.229', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.204.211.23', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.153.205.254', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.153.214.199', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.227.221.14', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('222.252.219.183', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.179.7.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('173.117.143.0', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.107.33.250', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.234.99.62', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.62.24.33', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('111.240.149.156', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.46.182.149', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.71.44.194', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.137.117.2', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.128.199.150', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.253.124.34', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.236.111.200', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('183.81.33.253', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.215.152.199', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.175.141.51', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.125.71.114', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.114.33.153', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('210.64.164.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('210.5.140.130', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.239.243.94', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.81.55.213', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.48.76.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.247.46.166', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('222.127.42.209', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.226.33.227', '0', 'tokpogs?rid=39084', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.215.217.90', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.126.196.173', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.183.30.234', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.238.43.59', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.89.75.100', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.132.183.55', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.136.42.202', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.203.105.82', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.218.181.159', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('217.217.183.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.212.153.238', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.187.240.200', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.101.152.214', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.81.59.29', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.77.209.46', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.255.168.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.68.240.255', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.251.72.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.96.137.250', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.155.125.129', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.29.38.206', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.210.111.149', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.192.93.103', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.119.29.36', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('90.150.214.250', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.31.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.12.64.131', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.254.175.133', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.134.227.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.254.59.67', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.242.136.141', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.81.130.138', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.33.31.241', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.166.10.157', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.92.178.161', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('83.238.229.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.54.42.178', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.43.229.117', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.89.78.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.65.69.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.169.201.249', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('31.7.168.226', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.99.70.138', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.135.86.220', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.90.254.112', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.119.102.18', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.206.132.115', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.131.127.204', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.0.15.151', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('93.128.10.122', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('209.118.181.20', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.193.131.153', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('194.38.144.140', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('151.37.167.133', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.237.21.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.92.57.104', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('81.224.46.110', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.120.221.7', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('74.3.163.93', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.46.67.143', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.248.176.129', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.245.147.189', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.218.68.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.116.170.73', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('213.233.92.59', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('68.68.107.37', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.39.213.75', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('158.75.8.26', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.135.96.242', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('106.51.81.218', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.26.36.48', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.23.109.53', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.177.149.148', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.5.167.171', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('2.82.192.106', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.126.115.252', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.54.87.122', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.119.122.113', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.38.206.178', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.128.190.254', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.60.164.2', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('184.82.226.195', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('64.151.92.236', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.204.37.213', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.169.154.25', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('122.52.40.49', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('86.63.135.148', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.55.126.146', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.21.106.233', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.178.119.49', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.127.110.187', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.145.188.11', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.180.76.182', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.79.130.101', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.237.97.130', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.141.47.159', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.250.122.217', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.148.73.74', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.26.170.118', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.254.189.164', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.115.9.66', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.172.96.149', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.160.117.15', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('220.134.2.8', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.112.41.8', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('145.236.15.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('184.22.237.114', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('69.65.43.167', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.124.233.73', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('92.249.131.24', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.224.13.228', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.254.174.191', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('98.14.120.212', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('14.198.255.229', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.76.6.29', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('112.203.47.145', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('218.187.241.82', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.26.234.205', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.232.213.186', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.90.9.64', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.150.125.203', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('64.25.184.102', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.254.26.254', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('216.172.152.5', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('46.149.119.61', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.246.119.51', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.51.137.6', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('77.85.231.211', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('125.232.43.24', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('120.59.26.141', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('204.12.238.62', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.242.0.107', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.249.253.61', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('88.230.182.76', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.160.178.247', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.138.33.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('175.141.19.17', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.40.134.120', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('58.8.205.44', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('96.35.112.89', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('116.202.205.167', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('203.223.95.105', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('79.115.67.87', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('110.39.143.227', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.98.168.69', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.3.70', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('173.252.192.210', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.169.51.140', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('202.152.194.118', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('96.24.159.33', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('180.149.7.224', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.195.98.106', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.155.38.119', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.72.168.54', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.125.223.116', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('60.251.167.2', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('71.59.223.104', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.173.215.183', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.218.49.61', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('39.45.97.165', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('80.28.51.141', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.189.139.77', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('59.98.80.65', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('188.254.164.103', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('173.20.120.203', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('27.114.167.37', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('42.2.159.21', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('109.73.105.163', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.244.17.138', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.158.71.195', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('84.32.46.204', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.18.173', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('87.116.87.126', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('101.108.100.136', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('89.47.126.146', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('124.6.181.57', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.203.218.84', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('189.31.31.183', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('118.96.21.41', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.219.17.210', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('99.88.126.13', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('151.64.131.234', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.123.52.24', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.201.173.0', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('78.61.241.92', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.178.172.48', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('85.67.187.184', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('123.27.234.58', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('178.126.132.138', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.135.133.1', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('49.203.240.74', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('182.186.120.123', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('184.22.252.53', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('117.194.225.220', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('94.236.137.12', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('186.186.224.169', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('82.193.98.65', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('219.92.105.146', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('41.230.249.244', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('218.102.126.203', '0', 'admin', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('91.83.200.135', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('181.28.182.21', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('121.203.193.131', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('114.79.0.146', '0', '', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('119.30.47.125', '0', 'tokpogs', '', '0');
INSERT INTO `dailyhits` (`ip`, `paid`, `ref`, `last_time`, `mcount`) VALUES ('95.215.119.233', '0', 'tokpogs', '', '0');










# dumping data for clickpla_mrv.emails
INSERT INTO `emails` (`id`, `title`, `target`, `description`, `views`, `views_today`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `new`, `daily_limit`, `upgrade`, `country`, `oviews`, `oviews_today`, `active`, `decline`) VALUES ('1', 'My Money Maker', 'http://ajramos23.blogspot.com', 'Make it yours too...', '6', '3', '9994', '', '', '', '0', '1', '0', '0', '', '0', '0', '1', '');




# dumping data for clickpla_mrv.fads
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('1', 'GRAND OPENING', 'http://click-planet.info', 'COMING VERY SOON', '19245', '6', '80755', '', 'admin', '', '0', '0', '0', '906', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('2', 'GRAND OPENING ', 'http://click-planet.info', 'COMING VERY SOON', '19169', '6', '80831', '', 'admin', '', '0', '0', '0', '873', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('3', 'My Money Maker', 'http://ajramos23.blogspot.com', 'Make it yours too...', '19154', '6', '2147464493', '', '', '', '0', '0', '0', '964', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('4', 'Clix$en$e', 'http://www.clixsense.com/?3677788', 'Pay$ up to 8 LEVEL$!', '377', '0', '623', '1331934221', 'tokpogs', '', '0', '0', '0', '48', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('5', 'NeoBux', 'http://www.neobux.com/?r=tokpogs', '1k+ Pax PAID/Week!', '365', '0', '635', '1331934409', 'tokpogs', '', '0', '0', '0', '40', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('6', 'PTC-Box', 'http://www.ptcbox.com/?p=gc&gci=2269', 'Up to .10 per Click!', '356', '0', '644', '1331934628', 'tokpogs', '', '0', '0', '0', '24', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('7', 'Ref$Bux', 'http://www.ref4bux.com/?ref=tokpogs', 'Meet A Ref!', '355', '0', '645', '1331934690', 'tokpogs', '', '0', '0', '0', '30', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('8', 'Ju$t One Bux', 'http://www.just-one-bux.com/?ref=tokpogs', 'Fast Growing PTC', '359', '0', '641', '1331934800', 'tokpogs', '', '0', '0', '0', '39', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('9', 'Varolo', 'http://www.varolo.com/village/tokpogsville', 'Watch Ads & Earn!', '339', '0', '661', '1331934872', 'tokpogs', '', '0', '0', '0', '35', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('10', 'InboxDollars', 'http://www.inboxdollars.com/?r=ref8929890', 'Get Paid Ca$h!', '349', '0', '651', '1331934996', 'tokpogs', '', '0', '0', '0', '33', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('11', 'Home Biz Community', 'http://tokpogs.blogspot.com/', 'Best PTCs List! Go!', '333', '0', '667', '1331935104', 'tokpogs', '', '0', '0', '0', '40', '1', '');
INSERT INTO `fads` (`id`, `title`, `target`, `description`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('13', 'Honest PTC!!!', 'http://www.neobux.com/?r=ajramos23', 'honest', '10', '0', '0', '1331976642', 'admin', '', '0', '0', '0', '0', '1', '');


# dumping data for clickpla_mrv.fbanners
INSERT INTO `fbanners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('1', 'admin', '0', 'http://www.click-planet.info', 'http://www.click-planet.info/banners/banner3.gif', '14394', '7', '85606', '1331337920', 'admin', '', '0', '0', '0', '2293', '1', '');
INSERT INTO `fbanners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('2', 'My Money Maker', '0', 'http://ajramos23.blogspot.com', 'http://static.easyhits4u.com/banners/543570.png?time=1331535643', '12649', '3', '99987351', '1331827691', '', '', '0', '0', '0', '2513', '1', '');
INSERT INTO `fbanners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('3', 'Get Paid $ up to 8 Levels!', '0', 'http://www.clixsense.com/?3677788', 'http://csstatic.com/banners/clixsense468x60a.gif', '629', '7', '371', '1331849378', 'tokpogs', '', '0', '0', '0', '1812', '1', '');
INSERT INTO `fbanners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('4', '1k+ People Paid Everyweek!', '0', 'http://www.neobux.com/?r=tokpogs', 'http://images.neobux.com/imagens/banner5.gif', '311', '0', '689', '1331849500', 'tokpogs', '', '0', '0', '0', '1257', '1', '');
INSERT INTO `fbanners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('5', 'Upto $ .10 per click! Lets Go!', '0', 'http://www.ptcbox.com/?p=gc&gci=2253', 'http://www.ptcbox.com/images/Paid_to_Click_Box/PTC_BOX_468.gif', '309', '0', '691', '1331849694', 'tokpogs', '', '0', '0', '0', '1268', '1', '');
INSERT INTO `fbanners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('7', 'Click for Bux $', '0', 'http://www.just-one-bux.com/?ref=tokpogs', 'http://www.just-one-bux.com/images/banner1.png', '260', '0', '240', '1331933537', 'tokpogs', '', '0', '0', '0', '1747', '1', '');
INSERT INTO `fbanners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('8', 'Meet More Ref!', '0', 'http://www.ref4bux.com/?ref=tokpogs', 'http://i.imgur.com/QRv8D.gif', '313', '0', '687', '1331933602', 'tokpogs', '', '0', '0', '0', '1828', '1', '');
INSERT INTO `fbanners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('9', 'Get Paid CASH, E-mail, Survey, Games &amp; More!', '0', 'http://www.inboxdollars.com/?r=ref8929890', 'http://www.inboxdollars.com/graphics/creative/banners/468x60/468x60_2.gif', '306', '0', '694', '1331933665', 'tokpogs', '', '0', '0', '0', '1779', '1', '');
INSERT INTO `fbanners` (`id`, `title`, `size`, `target`, `banner`, `views`, `clicks`, `credits`, `dsub`, `username`, `pref`, `forbid_retract`, `daily_limit`, `upgrade`, `views_today`, `active`, `decline`) VALUES ('10', 'My Money Maker', '0', 'http://ajramos23.blogspot.com', 'http://static.easyhits4u.com/banners/543570.png?time=1331535643', '0', '0', '0', '1331971205', 'admin', '', '0', '0', '0', '0', '0', '');


# dumping data for clickpla_mrv.flinks
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('1', 'CHECK OUT OUR LOW PRICES', 'http://click-planet.info/index.php?view=prices&', '', '1352610000', 'admin', '5', '18552', '', '1', '', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('2', 'CHECK OUT OUR LOW PRICES', 'http://click-planet.info/index.php?view=prices&', '', '1344657600', 'admin', '11', '18559', '', '0', '', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('3', 'GRAND OPENING SOON', 'http://click-planet.info', '', '1349928000', 'admin', '15', '18549', '', '0', '', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('4', 'My Money Maker', 'http://ajramos23.blogspot.com', '', '1366084800', '', '8', '17595', '', '0', '', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('5', 'Get Paid $ up to 8 Levels!', 'http://www.clixsense.com/?3677788', '1331935172', '1334635200', 'tokpogs', '1', '88', '', '1', 'yellow', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('6', '1k+ People Paid Everyweek!', 'http://www.neobux.com/?r=tokpogs', '1331935357', '1334635200', 'tokpogs', '1', '122', '', '1', 'pink', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('7', 'Upto $ .10 per click! Lets Go!', 'http://www.ptcbox.com/?p=gc&gci=2270', '1331935404', '1334635200', 'tokpogs', '1', '83', '', '1', 'yellow', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('9', 'Meet More Referrals!! ALL IN ONE! Join us NOW!', 'http://www.ref4bux.com/?ref=tokpogs', '1331935585', '1334635200', 'tokpogs', '1', '77', '', '0', '', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('10', 'Fast Growing PTC! Join NOW!', 'http://www.just-one-bux.com/?ref=tokpogs', '1331935648', '1334635200', 'tokpogs', '1', '103', '', '0', '', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('11', 'Get Paid CASH, E-mail, Survey, Games &amp; More!', 'http://www.inboxdollars.com/?r=ref8929890', '1331935682', '1334635200', 'tokpogs', '1', '93', '', '1', '', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('12', 'Get PAID CASH up to 6 Levels! Watch  15 sec. Ads! FREE Coupons! Join Now!', 'http://www.varolo.com/village/tokpogsville', '1331935832', '1334635200', 'tokpogs', '1', '105', '', '0', 'blue', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('13', 'Join The BEST PTC Sites! BEST Traffic Exchanges! Unlimited Income! Let$ GO!', 'http://tokpogs.blogspot.com/', '1331935961', '1334635200', 'tokpogs', '1', '66', '', '0', '', '0', '0', '0');
INSERT INTO `flinks` (`id`, `title`, `target`, `dsub`, `dend`, `username`, `clicks`, `views`, `pref`, `marquee`, `bgcolor`, `active`, `daily_limit`, `upgrade`) VALUES ('14', 'Honest PTC!!!', 'http://ajramos23.blogspot.com', '1331977466', '1332216000', 'admin', '1', '83', '', '0', 'red', '0', '0', '0');


# dumping data for clickpla_mrv.footprints
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1182', 'tagore', '1331957594', '/index.php?view=click&ac=mrpanel&', '115.249.44.252', '/index.php?view=click&sid=43TkM0eU9UUTVNakV5T0&sid2=43TkM&siduid=43&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1183', 'tagore', '1331957617', '/index.php?view=click&ac=mrpanel&', '115.249.44.252', '/index.php?view=click&sid=43TkM0eU9UUTVNakV5T0&sid2=43TkM&siduid=43&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1184', 'tagore', '1331957626', '/index.php?view=account&ac=profile&', '115.249.44.252', '/index.php?view=account&ac=profile&sid=43TkM0eU9UUTVNakV5T0&sid2=43TkM&siduid=43&', 'My Account Panel - Sampangula Ravindranath tagore');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1185', 'tagore', '1331957682', '/index.php?view=account&ac=messages&', '115.249.44.252', '/index.php?view=account&ac=messages&sid=43TkM0eU9UUTVNakV5T0&sid2=43TkM&siduid=43&', 'Message Center');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1186', 'exell', '1331958392', '/index.php?view=account&ac=profile&', '94.251.253.212', '/index.php?view=account&ac=profile&sid=44T1M0NU5EUTNNakV3TU&sid2=44T1M&siduid=44', 'My Account Panel - Bartek');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1187', 'exell', '1331958414', '/index.php?view=account&ac=earn&', '94.251.253.212', '/index.php?view=account&ac=earn&sid=44T1M0NU5EUTNNakV3TU&sid2=44T1M&siduid=44&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1188', 'exell', '1331958419', '/index.php?view=account&ac=click&', '94.251.253.212', '/index.php?view=account&ac=click&sid=44T1M0NU5EUTNNakV3TU&sid2=44T1M&siduid=44&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1189', 'exell', '1331958425', '/index.php?view=account&ac=profile&', '94.251.253.212', '/index.php?view=account&ac=profile&sid=44T1M0NU5EUTNNakV3TU&sid2=44T1M&siduid=44&', 'My Account Panel - Bartek');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1190', 'exell', '1331958432', '/index.php?view=account&ac=profile&action=ptr&', '94.251.253.212', '/index.php?view=account&ac=profile&action=ptr&to=0&sid=44T1M0NU5EUTNNakV3TU&sid2=44T1M&siduid=44&', 'My Account Panel - Bartek');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1191', 'exell', '1331958432', '/index.php?view=account&ac=profile&', '94.251.253.212', '/index.php?view=account&hold=Pref&ac=profile&sid=44T1M0NU5EUTNNakV3TU&sid2=44T1M&siduid=44&', 'My Account Panel - Bartek');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1192', 'gxch001', '1331958876', '/index.php?view=account&ac=profile&', '171.37.19.47', '/index.php?view=account&ac=profile&sid=46TVM0ek1URXlNakF5Tn&sid2=46TVM&siduid=46', 'My Account Panel - mixbules');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1193', 'exell', '1331958881', '/?view=home&ac=mrpanel&', '94.251.253.212', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1194', 'exell', '1331958890', '/index.php?view=account&ac=profile&', '94.251.253.212', '/index.php?view=account&ac=profile&sid=44T1M0NU5EUTNNakV3TU&sid2=44T1M&siduid=44&', 'My Account Panel - Bartek');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1195', 'exell', '1331958905', '/index.php?view=account&ac=membership&', '94.251.253.212', '/index.php?view=account&ac=membership&sid=44T1M0NU5EUTNNakV3TU&sid2=44T1M&siduid=44&', 'Premium Memberships');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1196', 'gxch001', '1331958915', '/index.php?view=account&ac=downline&', '171.37.19.47', '/index.php?view=account&ac=downline&sid=46TVM0ek1URXlNakF5Tn&sid2=46TVM&siduid=46&', 'Downline');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1197', 'gxch001', '1331958945', '/index.php?view=click&ac=mrpanel&', '171.37.19.47', '/index.php?view=click&sid=46TVM0ek1URXlNakF5Tn&sid2=46TVM&siduid=46&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1198', 'gxch001', '1331958978', '/index.php?view=account&ac=profile&', '171.37.19.47', '/index.php?view=account&ac=profile&sid=46TVM0ME5UYzROVFUzTX&sid2=46TVM&siduid=46', 'My Account Panel - mixbules');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1199', 'gxch001', '1331958983', '/index.php?view=account&ac=profile&', '171.37.19.47', '/index.php?view=account&ac=profile&sid=46TVM0ME5UYzROVFUzTX&sid2=46TVM&siduid=46&', 'My Account Panel - mixbules');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1200', 'gxch001', '1331958985', '/index.php?view=account&ac=earn&', '171.37.19.47', '/index.php?view=account&ac=earn&sid=46TVM0ME5UYzROVFUzTX&sid2=46TVM&siduid=46&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1201', 'gxch001', '1331958997', '/index.php?view=account&ac=click&', '171.37.19.47', '/index.php?view=account&ac=click&sid=46TVM0ME5UYzROVFUzTX&sid2=46TVM&siduid=46&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1202', 'admin', '1331961599', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1203', 'admin', '1331961633', '/?view=home&ac=mrpanel&', '180.193.120.143', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1204', 'admin', '1331961671', '/index.php?view=home&ac=mrpanel&', '180.193.120.143', '/index.php?sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1205', 'fales', '1331961855', '/index.php?view=account&ac=profile&', '220.255.1.91', '/index.php?view=account&ac=profile&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35', 'My Account Panel - Muhamad Fauzi Bin Jamaludin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1206', 'fales', '1331961962', '/index.php?view=account&ac=profile&action=ad_alert&', '220.255.1.70', '/index.php?view=account&ac=profile&action=ad_alert&to=1&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'My Account Panel - Muhamad Fauzi Bin Jamaludin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1207', 'fales', '1331961963', '/index.php?view=account&ac=profile&', '220.255.1.89', '/index.php?view=account&hold=Pref&ac=profile&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'My Account Panel - Muhamad Fauzi Bin Jamaludin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1208', 'fales', '1331961975', '/index.php?view=account&ac=messages&', '220.255.1.85', '/index.php?view=account&ac=messages&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Message Center');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1209', 'fales', '1331961990', '/index.php?view=account&ac=earn&', '220.255.1.47', '/index.php?view=account&ac=earn&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1210', 'fales', '1331962000', '/index.php?view=account&ac=ptra&', '220.255.1.27', '/index.php?view=account&ac=ptra&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1211', 'admin', '1331962295', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1212', 'admin', '1331962404', '/index.php?view=click&ac=mrpanel&', '180.193.120.143', '/index.php?view=click&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1213', 'fales', '1331962588', '/index.php?view=account&ac=ptra&', '220.255.1.33', '/index.php?view=account&ac=ptra&orderby=views&type=ASC&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1214', 'fales', '1331962599', '/index.php?view=account&ac=profile&', '220.255.1.29', '/index.php?view=account&ac=profile&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'My Account Panel - Muhamad Fauzi Bin Jamaludin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1215', 'fales', '1331962618', '/index.php?view=account&ac=contest&', '220.255.1.84', '/index.php?view=account&ac=contest&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Contests');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1216', 'fales', '1331962709', '/index.php?view=account&ac=profile&', '220.255.1.41', '/index.php?view=account&ac=profile&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'My Account Panel - Muhamad Fauzi Bin Jamaludin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1217', 'fales', '1331962741', '/index.php?view=account&ac=converter&', '220.255.1.35', '/index.php?view=account&ac=converter&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Converter');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1218', 'fales', '1331962855', '/index.php?view=click&ac=mrpanel&', '220.255.1.24', '/index.php?view=click&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1219', 'berich', '1331962995', '/index.php?view=account&ac=profile&', '58.19.23.45', '/index.php?view=account&ac=profile&sid=48TVM0eU9UTTVPVFF3Tl&sid2=48TVM&siduid=48', 'My Account Panel - MAHMOUD MOUSTAFA IMAM DESOUKY ELHABBAQ');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1220', 'berich', '1331963021', '/index.php?view=account&ac=earn&', '58.19.23.45', '/index.php?view=account&ac=earn&sid=48TVM0eU9UTTVPVFF3Tl&sid2=48TVM&siduid=48&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1221', 'fales', '1331963037', '/index.php?view=home&ac=mrpanel&', '220.255.1.73', '/index.php', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1222', 'berich', '1331963057', '/index.php?view=account&ac=click&', '58.19.23.45', '/index.php?view=account&ac=click&sid=48TVM0eU9UTTVPVFF3Tl&sid2=48TVM&siduid=48&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1223', 'fales', '1331963070', '/index.php?view=click&ac=mrpanel&', '220.255.1.31', '/index.php?view=click&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1224', 'berich', '1331963083', '/?view=home&ac=mrpanel&', '58.19.23.45', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1225', 'fales', '1331963207', '/index.php?view=account&ac=earn&', '220.255.1.36', '/index.php?view=account&ac=earn&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&s=1&type=ptc&siduid=35&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1226', 'fales', '1331963217', '/index.php?view=account&ac=profile&', '220.255.1.49', '/index.php?view=account&ac=profile&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'My Account Panel - Muhamad Fauzi Bin Jamaludin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1227', 'fales', '1331963487', '/index.php?view=click&ac=mrpanel&', '220.255.1.34', '/index.php?view=click&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1228', 'fales', '1331963494', '/index.php?view=click&ac=mrpanel&', '220.255.1.36', '/index.php?view=click&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1229', 'fales', '1331963498', '/index.php?view=account&ac=earn&', '220.255.1.33', '/index.php?view=account&ac=earn&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1230', 'fales', '1331963543', '/index.php?view=account&ac=earn&', '220.255.1.56', '/index.php?view=account&ac=earn&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&s=1&type=ce&siduid=35&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1231', 'admin', '1331963553', '/index.php?view=home&ac=mrpanel&', '180.193.120.143', '/index.php?sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1232', 'admin', '1331963569', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1233', 'admin', '1331963573', '/index.php?view=account&ac=click&', '180.193.120.143', '/index.php?view=account&ac=click&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1234', 'fales', '1331963577', '/index.php?view=account&ac=earn&', '220.255.1.57', '/index.php?view=account&ac=earn&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1235', 'fales', '1331963591', '/index.php?view=account&ac=profile&', '220.255.1.30', '/index.php?view=account&ac=profile&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'My Account Panel - Muhamad Fauzi Bin Jamaludin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1236', 'fales', '1331963619', '/index.php?view=account&ac=leaderboard&', '220.255.1.66', '/index.php?view=account&ac=leaderboard&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Leader Board');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1237', 'fales', '1331963685', '/index.php?view=account&ac=profile&', '220.255.1.80', '/index.php?view=account&ac=profile&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'My Account Panel - Muhamad Fauzi Bin Jamaludin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1238', 'fales', '1331963698', '/index.php?view=account&ac=mywarnings&', '220.255.1.88', '/index.php?view=account&ac=mywarnings&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Account');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1239', 'admin', '1331963701', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1240', 'admin', '1331963706', '/index.php?view=account&ac=click&', '180.193.120.143', '/index.php?view=account&ac=click&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1241', 'fales', '1331963707', '/index.php?view=click&ac=mrpanel&', '220.255.1.28', '/index.php?view=click&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1242', 'fales', '1331963714', '/index.php?view=click&ac=mrpanel&', '220.255.1.78', '/index.php?view=click&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1243', 'fales', '1331963728', '/index.php?view=prices&ac=mrpanel&', '220.255.1.67', '/index.php?view=prices', 'Purchase Advertising');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1244', 'admin', '1331963772', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1245', 'admin', '1331963776', '/index.php?view=account&ac=ptra&', '180.193.120.143', '/index.php?view=account&ac=ptra&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1246', 'fales', '1331963783', '/index.php?view=account&ac=profile&', '220.255.1.60', '/index.php?view=account&ac=profile&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'My Account Panel - Muhamad Fauzi Bin Jamaludin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1247', 'admin', '1331963786', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1248', 'fales', '1331963792', '/index.php?view=account&ac=messages&', '220.255.1.35', '/index.php?view=account&ac=messages&sid=35TXpVeU9UZ3pNakV4TV&sid2=35TXp&siduid=35&', 'Message Center');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1249', 'admin', '1331963813', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&s=1&type=ce&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1250', 'admin', '1331963853', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1251', 'berich', '1331963865', '/?view=home&ac=mrpanel&', '58.19.23.45', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1252', 'berich', '1331964002', '/?view=home&ac=mrpanel&', '58.19.23.45', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1253', 'admin', '1331964133', '/index.php?view=terms&ac=mrpanel&', '180.193.120.143', '/index.php?view=terms&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Terms');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1254', 'admin', '1331964347', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1255', 'admin', '1331964648', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Link Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1256', 'admin', '1331964675', '/index.php?view=account&ac=add_credits_link&id=17&', '180.193.120.143', '/index.php?view=account&ac=add_credits_link&id=17&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Link Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1257', 'admin', '1331964678', '/index.php?view=account&ac=add_credits_link&id=17&', '180.193.120.143', '/index.php?view=account&ac=add_credits_link&step=2&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Link Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1258', 'admin', '1331964723', '/index.php?view=account&ac=add_credits_link&id=17&', '180.193.120.143', '/index.php?view=account&ac=add_credits_link&step=2&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Link Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1259', 'admin', '1331964726', '/index.php?view=account&ac=add_credits_link&id=17&action=add&', '180.193.120.143', '/index.php?view=account&ac=add_credits_link&id=17&step=2&addoption=account&action=add&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Link Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1260', 'admin', '1331964741', '/index.php?view=account&ac=add_credits_link&id=17&action=add&', '180.193.120.143', '/index.php?view=account&ac=add_credits_link&id=17&step=2&addoption=account&action=add&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Link Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1261', 'yunghsin', '1331964741', '/index.php?view=account&ac=profile&', '116.118.161.145', '/index.php?view=account&ac=profile&sid=38Tnpjek9ERTRNak0xTX&sid2=38Tnp&siduid=38', 'My Account Panel - yunghsin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1262', 'admin', '1331964742', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=link&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Link Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1263', 'yunghsin', '1331964742', '/index.php?view=account&ac=profile&', '116.118.161.145', '/index.php?view=account&ac=profile&sid=38Tnpjek9ERTRNak0xTX&sid2=38Tnp&siduid=38&', 'My Account Panel - yunghsin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1264', 'yunghsin', '1331964744', '/index.php?view=account&ac=earn&', '116.118.161.145', '/index.php?view=account&ac=earn&sid=38Tnpjek9ERTRNak0xTX&sid2=38Tnp&siduid=38&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1265', 'admin', '1331964752', '/index.php?view=account&ac=add_credits_link&id=17&', '180.193.120.143', '/index.php?view=account&ac=add_credits_link&id=17&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Link Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1266', 'yunghsin', '1331964753', '/index.php?view=account&ac=click&', '116.118.161.145', '/index.php?view=account&ac=click&sid=38Tnpjek9ERTRNak0xTX&sid2=38Tnp&siduid=38&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1267', 'admin', '1331964756', '/index.php?view=account&ac=add_credits_link&id=17&', '180.193.120.143', '/index.php?view=account&ac=add_credits_link&step=2&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Link Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1268', 'admin', '1331964767', '/index.php?view=account&ac=add_credits_link&id=17&action=add&', '180.193.120.143', '/index.php?view=account&ac=add_credits_link&id=17&step=2&addoption=account&action=add&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Link Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1269', 'admin', '1331964768', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=link&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Link Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1270', 'admin', '1331964802', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1271', 'berich', '1331964805', '/?view=home&ac=mrpanel&', '58.19.23.45', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1272', 'berich', '1331965009', '/?view=home&ac=mrpanel&', '58.19.23.45', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1273', 'berich', '1331965054', '/index.php?view=account&ac=profile&', '58.19.23.45', '/index.php?view=account&ac=profile&sid=48TVM0eU9UTTVPVFF3Tl&sid2=48TVM&siduid=48', 'My Account Panel - MAHMOUD MOUSTAFA IMAM DESOUKY ELHABBAQ');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1274', 'admin', '1331965193', '/index.php?view=prices&ac=mrpanel&', '180.193.120.143', '/index.php?view=prices', 'Purchase Advertising');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1275', 'yunghsin', '1331965242', '/index.php?view=account&ac=ptra&', '116.118.161.145', '/index.php?view=account&ac=ptra&sid=38Tnpjek9ERTRNak0xTX&sid2=38Tnp&siduid=38&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1276', 'yunghsin', '1331965308', '/index.php?view=account&ac=profile&', '116.118.161.145', '/index.php?view=account&ac=profile&sid=38Tnpjek9ERTRNak0xTX&sid2=38Tnp&siduid=38&', 'My Account Panel - yunghsin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1277', 'admin', '1331965309', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1278', 'admin', '1331965793', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1279', 'admin', '1331966124', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Link Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1280', 'admin', '1331966146', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1281', 'admin', '1331966212', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1282', 'admin', '1331966733', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1283', 'admin', '1331968463', '/index.php?view=account&ac=view_banner&id=2&', '180.193.120.143', '/index.php?view=account&ac=view_banner&id=2&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'View Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1284', 'admin', '1331968670', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1285', 'admin', '1331968713', '/index.php?view=account&ac=view_banner&id=3&', '180.193.120.143', '/index.php?view=account&ac=view_banner&id=3&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'View Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1286', 'admin', '1331968735', '/index.php?view=account&ac=delete_banner&id=3&', '180.193.120.143', '/index.php?view=account&ac=delete_banner&id=3&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Delete Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1287', 'admin', '1331968752', '/index.php?view=account&ac=delete_banner&id=3&', '180.193.120.143', '/index.php?view=account&ac=delete_banner&&step=2&id=3&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Delete Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1288', 'admin', '1331968753', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1289', 'admin', '1331968762', '/index.php?view=account&ac=view_banner&id=2&', '180.193.120.143', '/index.php?view=account&ac=view_banner&id=2&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'View Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1290', 'admin', '1331968767', '/index.php?view=account&ac=delete_banner&id=2&', '180.193.120.143', '/index.php?view=account&ac=delete_banner&id=2&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Delete Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1291', 'admin', '1331968771', '/index.php?view=account&ac=delete_banner&id=2&', '180.193.120.143', '/index.php?view=account&ac=delete_banner&&step=2&id=2&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Delete Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1292', 'admin', '1331968771', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1293', 'admin', '1331968811', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1294', 'admin', '1331969529', '/index.php?view=account&ac=view_fad&id=1&', '180.193.120.143', '/index.php?view=account&ac=view_fad&id=1&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'View Featured Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1295', 'admin', '1331969585', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1296', 'admin', '1331969593', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1297', 'admin', '1331969652', '/index.php?view=account&ac=view_banner&id=1&', '180.193.120.143', '/index.php?view=account&ac=view_banner&id=1&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'View Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1298', 'admin', '1331969920', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1299', 'admin', '1331969930', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Link Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1300', 'admin', '1331969944', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1301', 'admin', '1331969982', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1302', 'admin', '1331970044', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1303', 'admin', '1331970064', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1304', 'admin', '1331970117', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1305', 'admin', '1331970463', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1306', 'admin', '1331970499', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1307', 'admin', '1331970717', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1308', 'admin', '1331971171', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1309', 'admin', '1331971205', '/index.php?view=account&ac=myads&action=add&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&action=add&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1310', 'admin', '1331971206', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1311', 'admin', '1331971310', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1312', 'admin', '1331971325', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1313', 'admin', '1331971333', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1314', 'admin', '1331971341', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1315', 'admin', '1331971352', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1316', 'admin', '1331971359', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1317', 'admin', '1331971436', '/index.php?view=account&ac=myads&action=add&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&action=add&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1318', 'admin', '1331971437', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1319', 'admin', '1331971450', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1320', 'admin', '1331971459', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1321', 'simmer', '1331971902', '/index.php?view=account&ac=profile&', '60.183.30.234', '/index.php?view=account&ac=profile&sid=42T0M0ek9UVTVNVEUzTV&sid2=42T0M&siduid=42', 'My Account Panel - qinoliver');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1322', 'simmer', '1331971983', '/index.php?view=account&ac=profile&', '60.183.30.234', '/index.php?view=account&ac=profile&sid=42T1RVeU16QTJOamczTl&sid2=42T1R&siduid=42', 'My Account Panel - qinoliver');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1323', 'simmer', '1331971984', '/index.php?view=account&ac=profile&', '60.183.30.234', '/index.php?view=account&ac=profile&sid=42T1RVeU16QTJOamczTl&sid2=42T1R&siduid=42&', 'My Account Panel - qinoliver');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1324', 'simmer', '1331971986', '/index.php?view=account&ac=earn&', '60.183.30.234', '/index.php?view=account&ac=earn&sid=42T1RVeU16QTJOamczTl&sid2=42T1R&siduid=42&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1325', 'simmer', '1331971994', '/index.php?view=account&ac=click&', '60.183.30.234', '/index.php?view=account&ac=click&sid=42T1RVeU16QTJOamczTl&sid2=42T1R&siduid=42&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1326', 'admin', '1331972217', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1327', 'admin', '1331972224', '/index.php?view=account&ac=add_credits_banner&id=11&', '180.193.120.143', '/index.php?view=account&ac=add_credits_banner&id=11&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Banner Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1328', 'admin', '1331972537', '/index.php?view=account&ac=view_banner&id=11&', '180.193.120.143', '/index.php?view=account&ac=view_banner&id=11&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'View Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1329', 'admin', '1331972540', '/index.php?view=account&ac=delete_banner&id=11&', '180.193.120.143', '/index.php?view=account&ac=delete_banner&id=11&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Delete Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1330', 'admin', '1331972544', '/index.php?view=account&ac=delete_banner&id=11&', '180.193.120.143', '/index.php?view=account&ac=delete_banner&&step=2&id=11&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Delete Banner');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1331', 'admin', '1331972544', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1332', 'admin', '1331972552', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1333', 'simmer', '1331972578', '/index.php?view=account&ac=profile&', '60.183.30.234', '/index.php?view=account&ac=profile&sid=42T0M0ME9ERTVORGd3Tn&sid2=42T0M&siduid=42', 'My Account Panel - qinoliver');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1334', 'simmer', '1331972591', '/?view=home&ac=mrpanel&', '60.183.30.234', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1335', 'simmer', '1331972715', '/index.php?view=account&ac=profile&', '60.183.30.234', '/index.php?view=account&ac=profile&sid=42T0M0eU1URTVOVGd3T0&sid2=42T0M&siduid=42', 'My Account Panel - qinoliver');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1336', 'simmer', '1331972716', '/index.php?view=account&ac=profile&', '60.183.30.234', '/index.php?view=account&ac=profile&sid=42T0M0eU1URTVOVGd3T0&sid2=42T0M&siduid=42&', 'My Account Panel - qinoliver');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1337', 'simmer', '1331972719', '/index.php?view=account&ac=earn&', '60.183.30.234', '/index.php?view=account&ac=earn&sid=42T0M0eU1URTVOVGd3T0&sid2=42T0M&siduid=42&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1338', 'simmer', '1331972726', '/index.php?view=account&ac=click&', '60.183.30.234', '/index.php?view=account&ac=click&sid=42T0M0eU1URTVOVGd3T0&sid2=42T0M&siduid=42&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1339', 'simmer', '1331972739', '/index.php?view=account&ac=ptra&', '60.183.30.234', '/index.php?view=account&ac=ptra&sid=42T0M0eU1URTVOVGd3T0&sid2=42T0M&siduid=42&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1340', 'admin', '1331972748', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1341', 'admin', '1331972839', '/index.php?view=account&ac=add_credits_fbanner&id=10&', '180.193.120.143', '/index.php?view=account&ac=add_credits_fbanner&id=10&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Featured Banner Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1342', 'l76303955', '1331973005', '/index.php?view=account&ac=profile&', '58.212.153.238', '/index.php?view=account&ac=profile&sid=41T0M0NU16TTNOamt6Tl&sid2=41T0M&siduid=41', 'My Account Panel - Desheng Lin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1343', 'l76303955', '1331973008', '/index.php?view=account&ac=profile&', '58.212.153.238', '/index.php?view=account&ac=profile&sid=41T0M0NU16TTNOamt6Tl&sid2=41T0M&siduid=41&', 'My Account Panel - Desheng Lin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1344', 'l76303955', '1331973013', '/index.php?view=account&ac=earn&', '58.212.153.238', '/index.php?view=account&ac=earn&sid=41T0M0NU16TTNOamt6Tl&sid2=41T0M&siduid=41&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1345', 'l76303955', '1331973028', '/index.php?view=account&ac=click&', '58.212.153.238', '/index.php?view=account&ac=click&sid=41T0M0NU16TTNOamt6Tl&sid2=41T0M&siduid=41&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1346', 'admin', '1331973214', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1347', 'admin', '1331973308', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=banner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1348', 'admin', '1331973432', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fbanner&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Banner Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1349', 'admin', '1331974107', '/index.php?view=click&ac=mrpanel&', '180.193.120.143', '/index.php?view=click&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1350', 'l76303955', '1331974335', '/index.php?view=account&ac=profile&', '58.212.153.238', '/index.php?view=account&ac=profile&sid=41TXk0ME5qZzRNakEzT1&sid2=41TXk&siduid=41', 'My Account Panel - Desheng Lin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1351', 'l76303955', '1331974360', '/?view=home&ac=mrpanel&', '58.212.153.238', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1352', 'admin', '1331975283', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1353', 'admin', '1331975287', '/index.php?view=account&ac=ptra&', '180.193.120.143', '/index.php?view=account&ac=ptra&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1354', 'admin', '1331975408', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1355', 'admin', '1331975443', '/index.php?view=account&ac=contest&', '180.193.120.143', '/index.php?view=account&ac=contest&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Contests');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1356', 'admin', '1331975520', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1357', 'admin', '1331975633', '/index.php?view=account&ac=banners&', '180.193.120.143', '/index.php?view=account&ac=banners&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Promotion');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1358', 'l76303955', '1331976412', '/index.php?view=account&ac=profile&', '58.212.153.238', '/index.php?view=account&ac=profile&sid=41TlM0Mk16a3pPRGd6TW&sid2=41TlM&siduid=41', 'My Account Panel - Desheng Lin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1359', 'l76303955', '1331976414', '/index.php?view=account&ac=profile&', '58.212.153.238', '/index.php?view=account&ac=profile&sid=41TlM0Mk16a3pPRGd6TW&sid2=41TlM&siduid=41&', 'My Account Panel - Desheng Lin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1360', 'l76303955', '1331976416', '/index.php?view=account&ac=earn&', '58.212.153.238', '/index.php?view=account&ac=earn&sid=41TlM0Mk16a3pPRGd6TW&sid2=41TlM&siduid=41&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1361', 'l76303955', '1331976426', '/index.php?view=account&ac=click&', '58.212.153.238', '/index.php?view=account&ac=click&sid=41TlM0Mk16a3pPRGd6TW&sid2=41TlM&siduid=41&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1362', 'admin', '1331976434', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1363', 'admin', '1331976439', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1364', 'admin', '1331976442', '/index.php?view=account&ac=ptra&', '180.193.120.143', '/index.php?view=account&ac=ptra&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1365', 'admin', '1331976452', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1366', 'admin', '1331976461', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&s=1&type=ce&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1367', 'l76303955', '1331976463', '/index.php?view=account&ac=ptra&', '58.212.153.238', '/index.php?view=account&ac=ptra&sid=41TlM0Mk16a3pPRGd6TW&sid2=41TlM&siduid=41&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1368', 'admin', '1331976478', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1369', 'admin', '1331976488', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Link Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1370', 'admin', '1331976504', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1371', 'admin', '1331976535', '/index.php?view=account&ac=myads&action=add&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&action=add&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1372', 'admin', '1331976535', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1373', 'admin', '1331976549', '/index.php?view=account&ac=view_fad&id=12&', '180.193.120.143', '/index.php?view=account&ac=view_fad&id=12&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'View Featured Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1374', 'admin', '1331976555', '/index.php?view=account&ac=delete_fad&id=12&', '180.193.120.143', '/index.php?view=account&ac=delete_fad&id=12&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Delete Featured Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1375', 'admin', '1331976560', '/index.php?view=account&ac=delete_fad&id=12&', '180.193.120.143', '/index.php?view=account&ac=delete_fad&&step=2&id=12&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Delete Featured Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1376', 'admin', '1331976561', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1377', 'admin', '1331976642', '/index.php?view=account&ac=myads&action=add&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&action=add&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1378', 'admin', '1331976643', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1379', 'admin', '1331976671', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1380', 'admin', '1331976809', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1381', 'l76303955', '1331976990', '/index.php?view=account&ac=profile&', '58.212.153.238', '/index.php?view=account&ac=profile&sid=41T0M0M05EUTROREU0TX&sid2=41T0M&siduid=41', 'My Account Panel - Desheng Lin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1382', 'l76303955', '1331976991', '/index.php?view=account&ac=profile&', '58.212.153.238', '/index.php?view=account&ac=profile&sid=41T0M0M05EUTROREU0TX&sid2=41T0M&siduid=41&', 'My Account Panel - Desheng Lin');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1383', 'l76303955', '1331976994', '/index.php?view=account&ac=earn&', '58.212.153.238', '/index.php?view=account&ac=earn&sid=41T0M0M05EUTROREU0TX&sid2=41T0M&siduid=41&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1384', 'l76303955', '1331977002', '/index.php?view=account&ac=click&', '58.212.153.238', '/index.php?view=account&ac=click&sid=41T0M0M05EUTROREU0TX&sid2=41T0M&siduid=41&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1385', 'l76303955', '1331977006', '/index.php?view=account&ac=ptra&', '58.212.153.238', '/index.php?view=account&ac=ptra&sid=41T0M0M05EUTROREU0TX&sid2=41T0M&siduid=41&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1386', 'admin', '1331977418', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1387', 'admin', '1331977467', '/index.php?view=account&ac=myads&action=add&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&action=add&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1388', 'admin', '1331977467', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1389', 'admin', '1331977474', '/index.php?view=account&ac=add_credits_flink&id=14&', '180.193.120.143', '/index.php?view=account&ac=add_credits_flink&id=14&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Account');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1390', 'admin', '1331977475', '/index.php?view=account&ac=buywizard&', '180.193.120.143', '/index.php?view=account&ac=buywizard&step=3&pid=29TVM0eE9E&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Purchase Wizard : Featured Link Rotation : Step 3');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1391', 'admin', '1331979801', '/index.php?view=home&ac=mrpanel&', '180.193.120.143', '/index.php?sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1392', 'admin', '1331979869', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1393', 'admin', '1331979882', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Link Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1394', 'admin', '1331979935', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1395', 'admin', '1331979943', '/index.php?view=account&ac=add_credits_fad&id=13&', '180.193.120.143', '/index.php?view=account&ac=add_credits_fad&id=13&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Add Credits To Featured Ad');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1396', 'admin', '1331979949', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1397', 'admin', '1331980310', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1398', 'admin', '1331980324', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1399', 'admin', '1331980447', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=fad&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1400', 'admin', '1331980522', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1401', 'admin', '1331980603', '/index.php?view=account&ac=view_flink&id=14&', '180.193.120.143', '/index.php?view=account&ac=view_flink&id=14&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'View Featured Link');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1402', 'admin', '1331980671', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1403', 'admin', '1331980718', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1404', 'admin', '1331982260', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1405', 'admin', '1331982293', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Link Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1406', 'admin', '1331982392', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1407', 'admin', '1331984759', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1408', 'admin', '1331985323', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&adtype=flink&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Featured Links');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1409', 'admin', '1331985484', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1410', 'admin', '1331985746', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1411', 'admin', '1331985767', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1412', 'admin', '1331987158', '/index.php?view=account&ac=contest&', '180.193.120.143', '/index.php?view=account&ac=contest&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Contests');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1413', 'babyemmy22', '1331987295', '/index.php?view=account&ac=profile&', '98.14.120.212', '/index.php?view=account&ac=profile&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32', 'My Account Panel - Imelda Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1414', 'babyemmy22', '1331987307', '/index.php?view=account&ac=downline&', '98.14.120.212', '/index.php?view=account&ac=downline&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Downline');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1415', 'babyemmy22', '1331987343', '/index.php?view=account&ac=earn&', '98.14.120.212', '/index.php?view=account&ac=earn&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1416', 'babyemmy22', '1331987353', '/index.php?view=account&ac=click&', '98.14.120.212', '/index.php?view=account&ac=click&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1417', 'admin', '1331988020', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1418', 'admin', '1331988067', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1419', 'babyemmy22', '1331988336', '/index.php?view=account&ac=earn&', '98.14.120.212', '/index.php?view=account&ac=earn&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1420', 'babyemmy22', '1331988339', '/index.php?view=account&ac=click&', '98.14.120.212', '/index.php?view=account&ac=click&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1421', 'babyemmy22', '1331988343', '/index.php?view=click&ac=mrpanel&', '98.14.120.212', '/index.php?view=click&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1422', 'babyemmy22', '1331988349', '/index.php?view=account&ac=earn&', '98.14.120.212', '/index.php?view=account&ac=earn&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1423', 'babyemmy22', '1331988352', '/index.php?view=account&ac=ptra&', '98.14.120.212', '/index.php?view=account&ac=ptra&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1424', 'babyemmy22', '1331988452', '/index.php?view=account&ac=earn&', '98.14.120.212', '/index.php?view=account&ac=earn&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1425', 'babyemmy22', '1331988473', '/index.php?view=account&ac=earn&', '98.14.120.212', '/index.php?view=account&ac=earn&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&s=1&type=ce&siduid=32&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1426', 'babyemmy22', '1331988484', '/index.php?view=account&ac=earn&', '98.14.120.212', '/index.php?view=account&ac=earn&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1427', 'babyemmy22', '1331988490', '/index.php?view=account&ac=profile&', '98.14.120.212', '/index.php?view=account&ac=profile&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'My Account Panel - Imelda Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1428', 'babyemmy22', '1331988501', '/index.php?view=account&ac=downline&', '98.14.120.212', '/index.php?view=account&ac=downline&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Downline');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1429', 'babyemmy22', '1331988527', '/index.php?view=account&ac=profile&', '98.14.120.212', '/index.php?view=account&ac=profile&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'My Account Panel - Imelda Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1430', 'babyemmy22', '1331988536', '/index.php?view=account&ac=messages&', '98.14.120.212', '/index.php?view=account&ac=messages&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Message Center');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1431', 'babyemmy22', '1331988543', '/index.php?view=home&ac=mrpanel&', '98.14.120.212', '/index.php?view=home&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1432', 'admin', '1331988606', '/index.php?view=account&ac=downline&', '180.193.120.143', '/index.php?view=account&ac=downline&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Downline');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1433', 'admin', '1331988973', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1434', 'babyemmy22', '1331989690', '/index.php?view=home&ac=mrpanel&ref=admin&', '98.14.120.212', '/index.php?ref=admin', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1435', 'babyemmy22', '1331989707', '/index.php?view=home&ac=mrpanel&ref=admin&', '98.14.120.212', '/index.php?ref=admin', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1436', 'babyemmy22', '1331989763', '/index.php?view=home&ac=mrpanel&ref=admin&', '98.14.120.212', '/index.php?ref=admin', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1437', 'babyemmy22', '1331989786', '/index.php?view=home&ac=mrpanel&ref=admin&', '98.14.120.212', '/index.php?ref=admin', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1438', 'admin', '1331991375', '/index.php?view=click&ac=mrpanel&', '180.193.120.143', '/index.php?view=click&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1439', 'admin', '1331991602', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1440', 'admin', '1331991643', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1441', 'admin', '1331991749', '/index.php?view=home&ac=mrpanel&', '180.193.120.143', '/index.php?view=home&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1442', 'admin', '1331991831', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1443', 'calypso35', '1331992114', '/index.php?view=account&ac=profile&', '79.115.67.87', '/index.php?view=account&ac=profile&sid=49Tmk0d09ERXhOVFkzTV&sid2=49Tmk&siduid=49', 'My Account Panel - curtiev ioan');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1444', 'calypso35', '1331992128', '/index.php?view=click&ac=mrpanel&', '79.115.67.87', '/index.php?view=click&sid=49Tmk0d09ERXhOVFkzTV&sid2=49Tmk&siduid=49&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1445', 'admin', '1331992349', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1446', 'admin', '1331992583', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1447', 'admin', '1331992630', '/index.php?view=account&ac=downline&', '180.193.120.143', '/index.php?view=account&ac=downline&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Downline');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1448', 'babyemmy22', '1331992952', '/index.php?view=account&ac=profile&', '98.14.120.212', '/index.php?view=account&ac=profile&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'My Account Panel - Imelda Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1449', 'babyemmy22', '1331992957', '/index.php?view=account&ac=downline&', '98.14.120.212', '/index.php?view=account&ac=downline&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Downline');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1450', 'babyemmy22', '1331993003', '/index.php?view=account&ac=earn&', '98.14.120.212', '/index.php?view=account&ac=earn&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1451', 'babyemmy22', '1331993005', '/index.php?view=account&ac=click&', '98.14.120.212', '/index.php?view=account&ac=click&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1452', 'babyemmy22', '1331993194', '/index.php?view=account&ac=click&', '98.14.120.212', '/index.php?view=account&ac=click&sid=32TXk0eU56VTRNakk1TW&sid2=32TXk&siduid=32&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1453', 'admin', '1331994797', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1454', 'admin', '1331994809', '/index.php?view=account&ac=myads&', '180.193.120.143', '/index.php?view=account&ac=myads&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Manage Link Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1455', 'admin', '1331994938', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1456', 'admin', '1331994942', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1457', 'admin', '1331995057', '/index.php?view=account&ac=click&', '180.193.120.143', '/index.php?view=account&ac=click&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1458', 'admin', '1331995119', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1459', 'admin', '1331995267', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1460', 'admin', '1331995271', '/index.php?view=account&ac=click&', '180.193.120.143', '/index.php?view=account&ac=click&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1461', 'babyemmy22', '1331996944', '/index.php?view=account&ac=profile&', '98.14.120.212', '/index.php?view=account&ac=profile&sid=32TVM0d01URXpPRGt5Tn&sid2=32TVM&siduid=32', 'My Account Panel - Imelda Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1462', 'admin', '1331997033', '/?view=home&ac=mrpanel&', '180.193.120.143', '/', 'Welcome To Click Planet!');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1463', 'admin', '1331997511', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'My Account Panel - Anthony John Ramos');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1464', 'admin', '1331997535', '/index.php?view=account&ac=downline&', '180.193.120.143', '/index.php?view=account&ac=downline&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Downline');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1465', 'admin', '1331997728', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1466', 'admin', '1331997731', '/index.php?view=account&ac=ptra&', '180.193.120.143', '/index.php?view=account&ac=ptra&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1467', 'admin', '1331997794', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1468', 'admin', '1331997798', '/index.php?view=account&ac=ptra&', '180.193.120.143', '/index.php?view=account&ac=ptra&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Read Ads');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1469', 'admin', '1331997836', '/index.php?view=account&ac=earn&', '180.193.120.143', '/index.php?view=account&ac=earn&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'How To Earn');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1470', 'admin', '1331997847', '/index.php?view=account&ac=click&', '180.193.120.143', '/index.php?view=account&ac=click&sid=29TVM0ek16QTJPVEE1TU&sid2=29TVM&siduid=29&', 'Get Paid To Click');
INSERT INTO `footprints` (`id`, `username`, `dsub`, `url`, `ip`, `uri`, `title`) VALUES ('1471', 'admin', '1331998225', '/index.php?view=account&ac=profile&', '180.193.120.143', '/index.php?view=account&ac=profile&sid=29Tnk0Mk5qWTBNelUyTl&sid2=29Tnk&siduid=29', 'My Account Panel - Anthony John Ramos');


# dumping data for clickpla_mrv.forum_forums
INSERT INTO `forum_forums` (`id`, `name`, `descip`, `lastpost`) VALUES ('2', 'General Discussion ', 'Discussions must be related to Click Planet.', '2012-03-16 01:19:09');














# dumping data for clickpla_mrv.ledger
INSERT INTO `ledger` (`id`, `payment_id`, `transaction_id`, `account`, `name`, `product`, `amount`, `proc`, `dsub`, `username`, `cost`, `status`, `email_verify`) VALUES ('1', '31TVM0eU1q', '4GA73707L5555815T', 'tokpogs@yahoo.com', 'rommel ramos', 'Bronze Membership (1 Month)', '1', 'Paypal', '1331841317', 'tokpogs', '3.55', '1', '0');
INSERT INTO `ledger` (`id`, `payment_id`, `transaction_id`, `account`, `name`, `product`, `amount`, `proc`, `dsub`, `username`, `cost`, `status`, `email_verify`) VALUES ('2', '32TVM0d05U', '65H79442E7630954V', 'babyemmy22@yahoo.com', 'Imelda Ramos', 'Bronze Membership (1 Month)', '1', 'Paypal', '1331850150', 'Babyemmy22', '3.55', '1', '1');


# dumping data for clickpla_mrv.logs
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('1', 'Cron [Daily] Completed Successfully', '1331182838', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('2', 'Cron [Daily] Completed Successfully', '1331269225', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('3', 'Cron [Daily] Completed Successfully', '1331355639', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('4', 'Cron [Weekly] Completed Successfully', '1331355639', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('5', 'Cron [Daily] Completed Successfully', '1331442029', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('6', 'Cron [Daily] Completed Successfully', '1331524830', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('7', 'Cron [Daily] Completed Successfully', '1331611232', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('8', 'Cron [Daily] Completed Successfully', '1331697618', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('9', 'Cron [Daily] Completed Successfully', '1331784031', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('10', 'Admin Assigned 2 Referrals To Account', '1331823812', 'admin', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('11', 'Admin [admin] Credited [1] GRAND OPENING COMING SOON Advertising Special', '1331832238', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('12', 'Bought Bronze Membership For 3.55 (1 Month) (Paypal)', '1331846370', 'tokpogs', '31TVM0eU1q');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('13', 'Added PTC Credits; Class: D; Credits: 1000', '1331854196', 'Babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('14', 'Received $0.1065 Bonus For Referral Purchase', '1331866745', 'tokpogs', '32TVM0d05U');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('15', 'Bought Bronze Membership For 3.55 (1 Month) (Paypal)', '1331866745', 'Babyemmy22', '32TVM0d05U');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('16', 'Assigning Membership Bonus [1] [10 ptra_credits]', '1331870430', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('17', 'Assigning Membership Bonus [1] [25 link_credits]', '1331870430', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('18', 'Cron [Daily] Completed Successfully', '1331870430', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('19', 'Added PTC Credits; Class: D; Credits: 200', '1331897106', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('20', 'Added PTC Credits; Class: D; Credits: 200', '1331897130', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('21', 'Added PTC Credits; Class: D; Credits: 200', '1331897155', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('22', 'Added PTC Credits; Class: D; Credits: 200', '1331897177', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('23', 'Added PTC Credits; Class: D; Credits: 200', '1331897209', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('24', 'Added PTC Credits; Class: D; Credits: 200', '1331897239', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('25', 'Added PTC Credits; Class: D; Credits: 200', '1331897291', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('26', 'Added PTC Credits; Class: D; Credits: 200', '1331897291', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('27', 'Added PTC Credits; Class: D; Credits: 100', '1331897338', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('28', 'Added PTC Credits; Class: D; Credits: 200', '1331897379', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('29', 'Added PTC Credits; Class: D; Credits: 200', '1331897411', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('30', 'Added PTC Credits; Class: D; Credits: 0', '1331897416', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('31', 'Added PTC Credits; Class: D; Credits: 0', '1331897444', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('32', 'Added PTC Credits; Class: D; Credits: 200', '1331897554', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('33', 'Added PTC Credits; Class: D; Credits: 300', '1331897595', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('34', 'Added PTC Credits; Class: D; Credits: 0', '1331897767', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('35', 'Added PTC Credits; Class: D; Credits: 300', '1331897785', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('36', 'Added PTC Credits; Class: D; Credits: 225', '1331897801', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('37', 'Added PTC Credits; Class: D; Credits: 2025', '1331903128', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('38', 'Added PTC Credits; Class: D; Credits: 500', '1331903155', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('39', 'Added PTC Credits; Class: D; Credits: 500', '1331903236', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('40', 'Added PTC Credits; Class: D; Credits: 500', '1331929905', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('41', 'Admin [admin] Credited [1] Opening Promo Advertising Special', '1331930680', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('42', 'Added PTC Credits; Class: D; Credits: 500', '1331931911', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('43', 'Added PTC Credits; Class: D; Credits: 0', '1331932616', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('44', 'Added PTC Credits; Class: D; Credits: 500', '1331932633', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('45', 'Added PTC Credits; Class: D; Credits: 0', '1331932652', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('46', 'Added PTC Credits; Class: D; Credits: 500', '1331932664', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('47', 'Added PTC Credits; Class: D; Credits: 500', '1331932713', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('48', 'Added PTC Credits; Class: D; Credits: 500', '1331932762', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('49', 'Added PTC Credits; Class: D; Credits: 500', '1331932776', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('50', 'Added PTC Credits; Class: D; Credits: 500', '1331932792', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('51', 'Added PTC Credits; Class: D; Credits: 500', '1331932805', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('52', 'Assigning Membership Bonus [1] [10 ptra_credits]', '1331956856', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('53', 'Assigning Membership Bonus [1] [25 link_credits]', '1331956857', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('54', 'Assigning Membership Bonus [2] [35 link_credits]', '1331956857', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('55', 'Assigning Membership Bonus [2] [10 ptra_credits]', '1331956857', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('56', 'Assigning Membership Bonus [2] [50 xcredits]', '1331956857', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('57', 'Assigning Membership Bonus [3] [50 ptr_credits]', '1331956857', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('58', 'Assigning Membership Bonus [3] [50 link_credits]', '1331956857', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('59', 'Assigning Membership Bonus [3] [50 ptra_credits]', '1331956858', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('60', 'Assigning Membership Bonus [3] [50 xcredits]', '1331956858', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('61', 'Assigning Membership Bonus [3] [50 fad_credits]', '1331956858', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('62', 'Assigning Membership Bonus [3] [50 banner_credits]', '1331956858', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('63', 'Assigning Membership Bonus [3] [50 fbanner_credits]', '1331956858', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('64', 'Cron [Daily] Completed Successfully', '1331956858', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('65', 'Won the Weekly click contest', '1331956859', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('66', 'Won the Weekly ticket drawing.', '1331956860', 'shrtschkr', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('67', 'Won the Weekly ticket drawing.', '1331956864', 'fales', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('68', 'Won the Weekly ticket drawing.', '1331956865', 'yunghsin', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('69', 'Won the Weekly ticket drawing.', '1331956867', 'babyemmy22', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('70', 'Won the Weekly ticket drawing.', '1331956868', 'cptc', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('71', 'Won the Weekly ticket drawing.', '1331956868', 'tokpogs', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('72', 'Won the Weekly ticket drawing.', '1331956869', 'tanher', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('73', 'Won the Weekly ticket drawing.', '1331956869', 'l76303955', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('74', 'Won the Weekly ticket drawing.', '1331956870', 'admin', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('75', 'Cron [Weekly] Completed Successfully', '1331956872', '', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('76', 'Added PTC Credits; Class: D; Credits: 0', '1331964726', 'admin', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('77', 'Added PTC Credits; Class: D; Credits: 10', '1331964741', 'admin', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('78', 'Added PTC Credits; Class: D; Credits: 90', '1331964767', 'admin', '');
INSERT INTO `logs` (`id`, `log`, `dsub`, `username`, `order_id`) VALUES ('79', 'BOT Deleted Account ', '1331995101', '', '');






# dumping data for clickpla_mrv.mailer_sessions
INSERT INTO `mailer_sessions` (`id`, `subject`, `from`, `message`, `status`, `dsub`, `total`, `sent`, `failed`) VALUES ('1', 'GOOD LUCK WITH YOUR NEW SITE', 'no-reply@click-planet.info', 'TEST 123 \r\n\r\n\r\n\r\nAdmin@click-planet.info\r\nhttp://click-planet.info', '1', '1331753039', '2', '2', '0');








# dumping data for clickpla_mrv.membership_benefits
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('1', '1', 'PTR Credits', 'ptra_credits', '10', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('2', '1', 'Link Credits', 'link_credits', '25', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('3', '1', 'Tickets', 'tickets', '150', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('4', '1', 'X-Credits', 'xcredits', '500', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('5', '1', 'Link Credits', 'link_credits', '2000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('6', '1', 'F. Banner Credits', 'fbanner_credits', '100000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('7', '1', 'F. Ad Credits', 'fad_credits', '100000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('8', '1', 'Banner Credits', 'banner_credits', '100000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('9', '2', 'Link Credits', 'link_credits', '35', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('10', '2', 'PTR Credits', 'ptra_credits', '10', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('11', '2', 'X-Credits', 'xcredits', '50', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('12', '2', 'Tickets', 'tickets', '300', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('13', '2', 'PTR Credits', 'ptra_credits', '500', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('14', '2', 'X-Credits', 'xcredits', '1000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('15', '2', 'Email Credits', 'ptr_credits', '1000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('16', '2', 'Link Credits', 'link_credits', '3000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('17', '2', 'F. Ad Credits', 'fad_credits', '250000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('18', '2', 'Banner Credits', 'banner_credits', '250000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('19', '2', 'F. Banner Credits', 'fbanner_credits', '250000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('20', '3', 'Email Credits', 'ptr_credits', '50', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('21', '3', 'Link Credits', 'link_credits', '50', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('22', '3', 'PTR Credits', 'ptra_credits', '50', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('23', '3', 'X-Credits', 'xcredits', '50', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('24', '3', 'F. Ad Credits', 'fad_credits', '50', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('25', '3', 'Banner Credits', 'banner_credits', '50', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('26', '3', 'F. Banner Credits', 'fbanner_credits', '50', 'D', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('27', '3', 'Tickets', 'tickets', '500', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('28', '3', 'Email Credits', 'ptr_credits', '1000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('29', '3', 'X-Credits', 'xcredits', '5000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('30', '3', 'Link Credits', 'link_credits', '6000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('31', '3', 'PTR Credits', 'ptra_credits', '6000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('32', '3', 'Banner Credits', 'banner_credits', '900000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('33', '3', 'F. Banner Credits', 'fbanner_credits', '900000', 'U', '0');
INSERT INTO `membership_benefits` (`id`, `membership`, `title`, `type`, `amount`, `time_type`, `time`) VALUES ('34', '3', 'F. Ad Credits', 'fad_credits', '900000', 'U', '0');


# dumping data for clickpla_mrv.memberships
INSERT INTO `memberships` (`id`, `title`, `time_type`, `time_amount`, `downline_earns`, `price`, `active`, `packages`, `order`, `dsub`, `purchase_bonus`, `upgrade_bonus`, `ptp`) VALUES ('1', 'Bronze', 'M', '0', '0.08', '3.40', '1', '1,2', '1', '1331833473', '3', '3', '1e-05');
INSERT INTO `memberships` (`id`, `title`, `time_type`, `time_amount`, `downline_earns`, `price`, `active`, `packages`, `order`, `dsub`, `purchase_bonus`, `upgrade_bonus`, `ptp`) VALUES ('2', 'Silver', 'M', '0', '30.00', '4.30', '1', '1,2,3,4,5,6,7,8,9,10,11,12', '1', '1331926640', '3', '3', '1e-05');
INSERT INTO `memberships` (`id`, `title`, `time_type`, `time_amount`, `downline_earns`, `price`, `active`, `packages`, `order`, `dsub`, `purchase_bonus`, `upgrade_bonus`, `ptp`) VALUES ('3', 'Gold', 'M', '0', '99.99', '10.00', '1', '1,2,3,4,5,6,7,8,9,10,11,12', '1', '1331927695', '10', '10', '1e-05');




# dumping data for clickpla_mrv.news
INSERT INTO `news` (`id`, `title`, `news`, `dsub`, `subm`) VALUES ('4', 'Each Month the top referring member will receive $ 5.00 Cash.', 'Each Month the top referring member will receive $ 5.00 Cash. All you have to do is promote your Referral URL to start getting referrals today! So what are you waiting for!!! Promote NOW!!!', '1331921276', '');


# dumping data for clickpla_mrv.online
INSERT INTO `online` (`id`, `userid`, `dsub`, `ip`) VALUES ('16947', '', '1331998608', '119.30.47.125');
INSERT INTO `online` (`id`, `userid`, `dsub`, `ip`) VALUES ('16948', '', '1331998615', '95.215.119.233');


# dumping data for clickpla_mrv.orders
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('7', '31TVM0eU1q', '2', 'Bronze Membership (1 Month)', '1', '1331841174', 'tokpogs', '1', 'upgrade', '3.55', '0', '0', '', '', '', '', '1', '', '0', '1', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('8', '32TVM0d05U', '2', 'Bronze Membership (1 Month)', '1', '1331850082', 'Babyemmy22', '1', 'upgrade', '3.55', '0', '0', '', '', '', '', '1', '', '0', '1', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('9', '31TVM0ek1E', '0', '', '', '1331850187', 'tokpogs', '0', 'special', '0', '0', '0', '', '', '', '', '1', '', '0', '1', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('10', '31T1Rrek1U', '0', '', '', '1331852791', 'tokpogs', '0', 'referrals', '0', '0', '0', '', '', '', '', '0', '', '0', '0', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('11', '29Tnk0Mk1U', '2', 'Opening Promo (1)', '1', '1331923610', 'admin', '0', 'special', '1.15', '0', '0', '', '', '', '', '2', '', '0', '2', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('12', '29TlM0NE5U', '0', '', '', '1331928376', 'admin', '0', 'upgrade', '0', '0', '0', '', '', '', '', '1', '', '0', '1', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('13', '29Tnk0M05E', '0', '', '', '1331928382', 'admin', '0', 'upgrade', '0', '0', '0', '', '', '', '', '2', '', '0', '2', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('14', '29TVM0eE16', '2', 'Gold Membership (12 Month)', '12', '1331928450', 'admin', '0', 'upgrade', '120.15', '0', '0', '', '', '', '', '3', '', '0', '3', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('15', '29TVM0d01E', '2', 'Gold Membership (10 Month)', '10', '1331928908', 'admin', '0', 'upgrade', '1', '0', '0', '', '', '', '', '3', '', '0', '3', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('16', '29TlM0NE5E', '2', 'Bronze Membership (1 Month)', '1', '1331929023', 'admin', '0', 'upgrade', '54.4', '0', '0', '', '', '', '', '1', '', '0', '1', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('17', '29TkM0ME1q', '2', 'Gold Membership (10 Month)', '10', '1331929150', 'admin', '0', 'upgrade', '115', '0', '0', '', '', '', '', '3', '', '0', '3', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('18', '29TkM0ek16', '2', 'Silver Membership (1 Month)', '1', '1331929345', 'admin', '0', 'upgrade', '5.18', '0', '0', '', '', '', '', '2', '', '0', '2', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('19', '29TWk0Mk5q', '2', 'Silver Membership (1 Month)', '1', '1331929832', 'admin', '0', 'upgrade', '4.95', '0', '0', '', '', '', '', '2', '', '0', '2', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('20', '31T0M0ek5E', '0', '', '', '1331935179', 'tokpogs', '0', 'flink', '0', '5', '0', '', '', '', '', '0', '', '0', '0', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('21', '31Tnk0Mk5E', '0', '', '', '1331935182', 'tokpogs', '0', 'flink', '0', '5', '0', '', '', '', '', '0', '', '0', '0', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('22', '31TVM0NE1U', '0', '', '', '1331935185', 'tokpogs', '0', 'flink', '0', '5', '0', '', '', '', '', '0', '', '0', '0', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('23', '36TVM0eE16', '0', '', '', '1331945474', 'tanher', '0', 'upgrade', '0', '0', '0', '', '', '', '', '1', '', '0', '1', '0', '0', '0');
INSERT INTO `orders` (`id`, `order_id`, `proc`, `payment_id`, `amount`, `dsub`, `username`, `paid`, `ad_type`, `cost`, `ad_id`, `points`, `reseller`, `class`, `timed`, `pamount`, `premium_id`, `bgcolor`, `marquee`, `special_id`, `status`, `subtitle`, `icon`) VALUES ('24', '29TVM0eE9E', '0', '', '', '1331977474', 'admin', '0', 'flink', '0', '14', '0', '', '', '', '', '0', '', '0', '0', '0', '0', '0');


# dumping data for clickpla_mrv.payment_approve
INSERT INTO `payment_approve` (`id`, `account`, `blocked`) VALUES ('1', 'tokpogs@yahoo.com', '0');
INSERT INTO `payment_approve` (`id`, `account`, `blocked`) VALUES ('2', 'babyemmy22@yahoo.com', '0');






















# dumping data for clickpla_mrv.ptrads
INSERT INTO `ptrads` (`id`, `title`, `dsub`, `username`, `class`, `views`, `views_today`, `credits`, `target`, `type`, `timed`, `pamount`, `pref`, `bgcolor`, `forbid_retract`, `ad`, `active`, `new`, `daily_limit`, `upgrade`, `country`, `icon_on`, `icon`, `subtitle_on`, `subtitle`, `decline`) VALUES ('1', 'My Money Maker', '1331826594', 'admin', 'D', '16', '6', '9984', 'http://ajramos23.blogspot.com', '0', '25', '0.0003', '', '', '0', 'Make it yours too..', '1', '0', '0', '0', '', '0', '', '0', '', '');








# dumping data for clickpla_mrv.refdomains
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('', '107');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('www.facebook.com', '11');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('www.click-planet.info', '245');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('www.americanaptc.info', '74');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('americanaptc.info', '9');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('www.neobux.com', '20');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('www.clixsense.com', '2051');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('www.just-one-bux.com', '289');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('clixsense.com', '32');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('ad3.neobux.com', '2206');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('ad5.neobux.com', '2264');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('ad4.neobux.com', '2241');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('ad2.neobux.com', '2168');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('www.ptcbox.com', '4031');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('www.wishonastar.info', '115');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('ad6.neobux.com', '1');
INSERT INTO `refdomains` (`domain`, `hits`) VALUES ('wishonastar.info', '20');








# dumping data for clickpla_mrv.sessions
INSERT INTO `sessions` (`id`, `sess_id`, `sess_id2`, `user_id`, `start_time`, `remote_ip`, `ipvoid`) VALUES ('119', '32TVM0d01URXpPRGt5Tn', '32TVM', '32', '1331996944', '98.14.120.212', '');
INSERT INTO `sessions` (`id`, `sess_id`, `sess_id2`, `user_id`, `start_time`, `remote_ip`, `ipvoid`) VALUES ('120', '29Tnk0Mk5qWTBNelUyTl', '29Tnk', '29', '1331998575', '180.193.120.143', '');


# dumping data for clickpla_mrv.special_benefits
INSERT INTO `special_benefits` (`id`, `special`, `title`, `type`, `amount`) VALUES ('10', '2', 'X-Credits', 'xcredits', '1000');
INSERT INTO `special_benefits` (`id`, `special`, `title`, `type`, `amount`) VALUES ('11', '2', 'Guaranteed Signups', 'ptsu_credits', '5');
INSERT INTO `special_benefits` (`id`, `special`, `title`, `type`, `amount`) VALUES ('12', '2', 'Link Credits', 'link_credits', '1000');
INSERT INTO `special_benefits` (`id`, `special`, `title`, `type`, `amount`) VALUES ('13', '2', 'PTR Credits', 'ptra_credits', '1000');


# dumping data for clickpla_mrv.specials
INSERT INTO `specials` (`id`, `title`, `price`, `active`, `packages`, `order`, `dsub`, `buys`, `show`) VALUES ('2', 'Opening Promo', '1.00', '1', '1,2,3,4,5,6,7,8,9,10', '1', '1331921768', '0', '0');


# dumping data for clickpla_mrv.stats
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('1', '07/03/12', '1', '0', '0.00000', '0', '0.00', '0.00000', '0', '1', '0', '0', '0', '0.00000', '0', '0', '0.00000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('2', '08/03/12', '35', '0', '0.00000', '0', '0.00', '0.00000', '0', '3', '0', '0', '0', '0.00000', '0', '0', '0.00000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('3', '09/03/12', '198', '0', '0.00000', '0', '0.00', '0.00000', '0', '2', '0', '0', '0', '0.00000', '0', '0', '0.00000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('4', '10/03/12', '86', '0', '0.00000', '0', '0.00', '0.00000', '0', '1', '0', '0', '0', '0.00000', '0', '0', '0.00000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('5', '11/03/12', '44', '0', '0.00000', '0', '0.00', '0.00000', '0', '4', '0', '0', '0', '0.00000', '0', '0', '0.00000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('6', '12/03/12', '36', '0', '0.00000', '0', '0.00', '0.00000', '0', '4', '0', '0', '0', '0.00000', '0', '0', '0.00000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('7', '13/03/12', '120', '0', '0.00000', '0', '0.00', '0.00000', '0', '4', '0', '0', '0', '0.00000', '0', '0', '0.00000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('8', '14/03/12', '805', '1', '0.00000', '0', '0.00', '0.00000', '0', '13', '0', '0', '0', '0.00000', '0', '0', '0.00000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('9', '15/03/12', '1224', '3', '0.02215', '7', '7.10', '0.00000', '4', '110', '0', '0', '0', '0.00000', '3', '2', '1.60000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('10', '16/03/12', '14710', '12', '0.14003', '110', '0.00', '0.00000', '10023', '10122', '3', '0', '0', '0.00000', '7', '4', '3.20000', '0', '0.00', '0.00');
INSERT INTO `stats` (`id`, `date`, `hits`, `new_members`, `cash`, `clicked`, `income`, `points`, `ptphits`, `unhits`, `emails`, `floodguard`, `surfed`, `surf_credits`, `ptrads`, `xclicked`, `xcredits`, `signups`, `paid`, `survey`) VALUES ('11', '17/03/12', '3446', '6', '0.06079', '110', '0.00', '0.00000', '2003', '2106', '3', '0', '0', '0.00000', '6', '3', '2.40000', '0', '0.00', '0.00');






# dumping data for clickpla_mrv.target_co
INSERT INTO `target_co` (`id`, `country`) VALUES ('5', 'Australia');
INSERT INTO `target_co` (`id`, `country`) VALUES ('6', 'Bangladesh');
INSERT INTO `target_co` (`id`, `country`) VALUES ('7', 'Brazil');
INSERT INTO `target_co` (`id`, `country`) VALUES ('8', 'China');
INSERT INTO `target_co` (`id`, `country`) VALUES ('9', 'India');
INSERT INTO `target_co` (`id`, `country`) VALUES ('10', 'Indonesia');
INSERT INTO `target_co` (`id`, `country`) VALUES ('11', 'Korea, Republic of');
INSERT INTO `target_co` (`id`, `country`) VALUES ('12', 'Peru');
INSERT INTO `target_co` (`id`, `country`) VALUES ('13', 'Philippines');
INSERT INTO `target_co` (`id`, `country`) VALUES ('14', 'Poland');
INSERT INTO `target_co` (`id`, `country`) VALUES ('15', 'Singapore');
INSERT INTO `target_co` (`id`, `country`) VALUES ('16', 'Taiwan');
INSERT INTO `target_co` (`id`, `country`) VALUES ('17', 'United States');




# dumping data for clickpla_mrv.terms
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('1', 'Change Of terms', 'This agreement can change. Although we have the right to change this agreement without any prior notice to our members, we will send out a notice to all of our members the new terms and/or terms that have changed changed. If for any reason you do not accept the changes, you will need to contact us, and your account will be removed. ', '1271191033', '', '/images/icons/termsicon.png');
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('2', 'Advertising Terms', '-- The website must not contain pornographic, racist, discriminating, vulgar, illegal, or other adult materials of any kind. -- The website must not contain any frame breakers. -- The website must be english. -- The website must not contain or promote any viruses -- The website must not conatin ANY promts such as download dialogs or confirmation alerts. -- The website must not exceed the 1 popup/popunder limit -- The website\'s single popup/popunder must not open any new windows. -- The website\'s single popup/popunder must not break any of the above terms.', '1271191053', '', '/images/icons/termsicon.png');
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('3', 'Inactive Accounts', 'If your account has been inactive for more than 60 days, your earnings will be cleared. ', '1271191071', '', '/images/icons/termsicon.png');
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('4', 'Spamming', 'We do not believe in spam, and we are very strict on the handling of your information. The only emails you will receive are periodic emails with information about updates and issues with the site. ', '1271191091', '', '/images/icons/termsicon.png');
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('5', 'Cheating', 'With our tough anti-cheat system, it is extremely difficult to cheat. If someone is caught cheating or simply attempting to cheat, we have the right to forfeit all earnings and possibly even ban the user from our network. Cheating would include any of the following:  # Interfering with our system to prevent optimum security and/or reliability. # Creating any type of emulator, or a program to automate the process of clicking. # Any malicious act that may, in any way, interfere with our system. ', '1271191124', '', '/images/icons/termsicon.png');
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('6', 'False Representation', 'We do not tolerate anyone who uses false information to get referrals. ', '1271191152', '', '/images/icons/termsicon.png');
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('7', 'Multiple Accounts', 'You are not allowed to create more than 1 account per person, household or I.P. address. ', '1271191719', '', '/images/icons/termsicon.png');
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('8', 'Purchase', 'All purchased items are non-refundable. Charge back or reverse transactions made on your purchases will lead to immediate account termination.', '1331899753', '', ' http://click-planet.info/images/icons/termsicon.png');
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('9', 'YOU MUST BE ABLE TO READ/WRITE ENGLISH!', 'Please read all our terms before joining!', '1331899870', '', ' http://click-planet.info/images/icons/termsicon.png');
INSERT INTO `terms` (`id`, `title`, `terms`, `dsub`, `subm`, `imglink`) VALUES ('10', 'Payments', 'All Payments are made via PayPal.\r\nTo receive payment, you must have a VERIFIED PayPal account to be paid ONLY ONE PAYMENT REQUEST AT A TIME.\r\nYour First Name and Last Name and Email address must Match your PayPal Account. If this doesn\\\'t match we will cancel the payment and deduct the payment from your account.\r\nEnsure your payment address is correct before requesting a payment. We are not responsible in any way for user error. ', '1331907828', '', 'http://click-planet.info/images/icons/termsicon.png');






# dumping data for clickpla_mrv.user
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('28', 'greg', 'fastmint', '74d738020dca22a731e30058ac7242ee', 'amerirapt4clix@gmail.com', '0', '0', '0.00000', '', '68.195.157.163', 'admin', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '1206422581', '1331913852', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '1', 'United States', '', '0', '0', '', '', '0', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '', '0', '', '0', '0', '0', '1331337887', '', '0.00000', '0.00000', '0', '0', '0', '0', '3', '1', '1', '', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('29', 'Anthony John Ramos', 'admin', '25113965e18315595b4131e54d09cf35', 'admin@click-planet.info', '7', '', '0.01679', '1331751661', '180.193.120.143', '', '5', '11', '2', '0', '0', '0.00000', '16', '0', '0.00000', '1331975358', '1331998575', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '14', '85', '', '0', '2', '0', '109', '65', '0.00109', '0.00000', '0.00000', '1', '0', '1', '0', '0.00000', '0', '0.00000', '', '1', '', '167', '65', '0.00000', '0.00000', '0', '0', '0', '0', '18', '1', '2', '1', '0.00000', '', '0.80000', '1', '1', '3', 'Philippines', '', '0', '0', '', '1331975190', '5', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '180.193.98.54', '0', '', '0', '1', '0', '1331752386', '', '0.00084', '0.00450', '0', '0', '0', '14', '0', '1', '1', '273f5064dc00c682c73b05f36d00f2a1', '0', '0', '0', '0', '0', '1', '2');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('30', 'mike', 'roadtrainclickscom', 'ccb647e3baff9f4f4b931714da5ff0e3', 'mrjpinnock@hotmail.com', '0', '', '0.00000', '1331791396', '1.130.54.197', 'admin', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '', '1331791521', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '0', 'Australia', '', '0', '0', '', '', '0', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '1.130.54.197', '0', '', '0', '1', '0', '', '', '0.00000', '0.00000', '0', '0', '0', '0', '3', '1', '1', 'a4e858c15255e55d5e1e221bd151154f', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('31', 'rommel ramos', 'tokpogs', '2a38d9a29addf4daecc27802f3f412e7', 'tokpogs@yahoo.com ', '0', '', '0.23111', '1331824460', '208.54.87.153', 'admin', '11', '2', '0', '0', '0', '0.10984', '13', '1', '0.00000', '1331903025', '1331990126', '0.00', '', '', '1125.00000', '40000.00000', '20000.00000', '0.00000', '0', '30', '1334524770', '0', '11', '0', '11268', '1731', '0.11268', '0.00000', '0.00000', '1', '0', '1', '0', '40000.00000', '1', '0.00000', '', '1', '', '2085', '1736', '0.00000', '0.00000', '0', '0', '0', '0', '13', '1', '2', '0', '1020.00000', '', '1501.60000', '2', '0', '2', 'United States', '', '0', '0', '', '1331902853', '4', '5', '', '', 'M', '1978', '1', '0', '0', '0.00', '0', '208.54.45.195', '0', '', '0', '1', '0', '1331978569', '', '0.00038', '0.00000', '0', '0', '0', '0', '0', '1', '1', 'ef50c335cca9f340bde656363ebd02fd', '0', '0', '0', '0', '0', '1', '10');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('32', 'Imelda Ramos', 'babyemmy22', '48e729dcaae968f13f9150ff74e0d462', 'babyemmy22@yahoo.com', '0', '', '0.01745', '1331841059', '98.14.120.212', 'tokpogs', '2', '0', '0', '0', '0', '0.00034', '27', '1', '0.00000', '1331990126', '1331996944', '0.00', '', '', '125.00000', '100100.00000', '100000.00000', '0.00000', '11', '62', '1334545145', '0', '2', '0', '1', '0', '0.00001', '0.00000', '0.00000', '1', '0', '2', '1', '100000.00000', '1', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '2', '1', '3', '1', '20.00000', '', '502.40000', '3', '1', '13', 'United States', '', '0', '0', '', '1331988063', '8', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '98.14.120.212', '0', '', '0', '1', '0', '1331867165', '', '0.00118', '0.00590', '0', '0', '0', '11', '0', '1', '1', 'f3d9de86462c28781cbe5c47ef22c3e5', '0', '0', '0', '0', '0', '1', '2');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('33', 'Marcelo Abel', 'marceloabel', '44e147f2823b89802a31a4d5db2b2a9a', 'marceloabel.df@gmail.com', '0', '', '0.00000', '1331925546', '201.2.101.67', 'babyemmy22', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '', '1331925546', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '0', 'Brazil', '', '0', '0', '', '', '0', '0', '', '', '', '0', '0', '0', '0', '0.00', '0', '201.2.101.67', '0', '', '0', '1', '0', '', '', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '25d55ad283aa400af464c76d713c07ad', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('34', 'Claudio Pinheiro T. Cantes', 'cptc', 'c3581516868fb3b71746931cac66390e', 'claudiocptc@hotmail.com', '0', '', '0.00510', '1331939507', '187.85.106.176', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '14', '0', '0.00000', '1331977690', '1331940457', '0.00', '', '', '100.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '1', '1', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '0', '0.00000', '', '0.00000', '0', '0', '0', 'Brazil', '', '0', '0', '', '1331939846', '1', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '187.85.106.176', '0', '', '0', '1', '0', '', '', '0.00030', '0.00060', '0', '0', '0', '0', '0', '1', '1', 'e58aea67b01fa747687f038dfde066f6', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('35', 'Muhamad Fauzi Bin Jamaludin', 'fales', '0c27bbb7fe52e845429792698acccd06', 'mdfauzi@live.com', '0', '', '0.00900', '1331943387', '220.255.1.35', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '28', '0', '0.00000', '1331963542', '1331963792', '0.00', '', '', '100.00000', '0.00000', '0.00000', '0.00000', '14', '65', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '2', '1', '0.00000', '', '0.80000', '1', '1', '0', 'Singapore', '', '0', '0', '', '1331963132', '3', '0', '1', '0', '', '0', '0', '0', '0', '0.00', '0', '220.255.1.106', '0', '', '0', '1', '0', '', '', '0.00060', '0.00450', '0', '0', '0', '14', '0', '1', '1', '06e0cc57ec7ffdc7f8b928516fa9aa40', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('36', 'ragib noor tanher', 'tanher', 'dcca83d36ed12fa41818a413c424db17', 'tanher_2012@yahoo.com', '0', '', '0.00450', '1331945157', '58.97.182.130', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '14', '0', '0.00000', '1331946365', '1331946386', '0.00', '', '', '100.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '0', '0.00000', '', '0.80000', '1', '0', '0', 'Bangladesh', '', '0', '0', '', '1331946077', '2', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '58.97.182.130', '0', '', '0', '1', '0', '', '', '0.00030', '0.00000', '0', '0', '0', '0', '0', '1', '1', '827ccb0eea8a706c4c34a16891f84e7b', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('37', 'James Howery', 'shrtschkr', 'b1a22bb5e124e3233efba17dd22c798f', 'shrtschkr@gmail.com', '0', '', '0.00510', '1331946444', '71.137.233.254', 'babyemmy22', '0', '0', '0', '0', '0', '0.00000', '16', '0', '0.00000', '1331950881', '1331951340', '0.00', '', '', '100.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '0', '0.00000', '', '0.80000', '1', '0', '0', 'United States', '', '0', '0', '', '1331950690', '4', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '71.137.233.254', '0', '', '0', '1', '0', '', '', '0.00034', '0.00000', '0', '0', '0', '0', '0', '1', '1', '4cb811134b9d39fc3104bd06ce75abad', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('38', 'yunghsin', 'yunghsin', '9d665f841c53f21ee3c255dacaddd8f6', 'yunghsin00@gmail.com', '0', '', '0.00900', '1331948467', '116.118.161.145', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '28', '0', '0.00000', '1331965297', '1331965308', '0.00', '', '', '100.00000', '0.00000', '0.00000', '0.00000', '14', '64', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '2', '1', '0.00000', '', '0.00000', '0', '0', '0', 'Taiwan', '', '0', '0', '', '1331965176', '3', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '116.118.161.145', '0', '', '0', '1', '0', '', '', '0.00060', '0.00450', '0', '0', '0', '14', '0', '1', '1', 'e345fac6bc5c868f0222430c733fa26e', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('39', 'dede chaniago', 'dedechaniago', '80c453a5c304c97d1fe7a7a5b3285d00', 'dennis.cracker@yahoo.com', '0', '', '0.00000', '1331948919', '180.245.228.121', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '', '1331951195', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '1', 'Indonesia', '', '0', '0', '', '', '0', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '180.245.228.121', '0', '', '0', '1', '0', '', '', '0.00000', '0.00000', '0', '0', '0', '0', '0', '0', '1', 'dc513ea4fbdaa7a14786ffdebc4ef64e', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('40', 'MARIBEL VILCHEZ', 'ADELAIDA264', 'e2f50af2206916ceeddab6f8266ca486', 'ADELAIDA26_4@HOTMAIL.COM', '0', '', '0.00000', '1331949044', '207.46.204.102', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '', '1331949889', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '0', 'Peru', '', '1', '0', '', '', '0', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '190.118.84.62', '0', '', '0', '1', '0', '', '', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', 'e2f50af2206916ceeddab6f8266ca486', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('41', 'Desheng Lin', 'l76303955', '71f55003c9a36b40c4a094908f11fb77', 'shlnellb@qq.com', '0', '', '0.00930', '1331949456', '58.212.153.238', '', '0', '0', '0', '0', '0', '0.00000', '28', '0', '0.00000', '1331976518', '1331977006', '0.00', '', '', '100.00000', '0.00000', '0.00000', '0.00000', '14', '64', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '1', '1', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '1', '0.00000', '', '0.00000', '0', '0', '0', 'China', '', '0', '0', '', '1331973097', '4', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '58.212.153.238', '0', '', '0', '1', '0', '', '', '0.00052', '0.00510', '0', '0', '0', '14', '0', '1', '1', 'b3848d61bbbc6207c6668a8a9e2730ed', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('42', 'qinoliver', 'simmer', 'b1478196a9d3ad52d95ae1e86d2ef52d', 'qinoliver@gmail.com', '0', '', '0.00390', '1331950570', '60.183.30.234', '', '0', '0', '0', '0', '0', '0.00000', '12', '0', '0.00000', '1331972790', '1331972739', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '12', '62', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '1', '0.00000', '', '0.00000', '0', '0', '0', 'China', '', '0', '0', '', '1331972758', '5', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '60.183.26.75', '0', '', '0', '1', '0', '', '', '0.00026', '0.00390', '0', '0', '0', '12', '0', '1', '1', 'ea204361fe7f024b130143eb3e189a18', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('43', 'Sampangula Ravindranath tagore', 'tagore', 'f36ff1befd6fc0c65ac240cb9a88fe6a', 'tagorebangaram143@gmail.com', '0', '', '0.00420', '1331955961', '115.249.44.252', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '14', '0', '0.00000', '1331957561', '1331957682', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '14', '14', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '1', 'India', '', '0', '0', '', '1331957416', '4', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '115.249.44.252', '0', '', '0', '1', '0', '', '', '0.00028', '0.00420', '0', '0', '0', '14', '0', '1', '1', '81dc9bdb52d04dc20036dbd8313ed055', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('44', 'Bartek', 'exell', '176226b2d51002d2590f048881560569', 'exellisdead@wp.pl', '0', '', '0.00000', '1331955983', '94.251.253.212', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '', '1331958905', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '0', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '0', 'Poland', '', '0', '0', '', '', '0', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '94.251.253.212', '0', '', '0', '1', '0', '1331988441', '', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '58ae23d878a47004366189884c2f8440', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('45', 'santosh kumar g', 'geeyeskumar', 'ca28894b509f97d7b341bddb7363b2fd', 'kumargeeyes@yahoo.com', '0', '', '0.00000', '1331958753', '115.242.203.65', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '', '1331958753', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '0', 'India', '', '0', '0', '', '', '0', '0', '', '', '', '0', '0', '0', '0', '0.00', '0', '115.242.203.65', '0', '', '0', '1', '0', '', '', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '7fa06f1f9e00a560685936529c9c25da', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('46', 'mixbules', 'gxch001', 'feca653d0f00aeb8890090e103484442', 'gxch001@yahoo.cn', '0', '', '0.00120', '1331958799', '171.37.19.47', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '4', '0', '0.00000', '1331959181', '1331958997', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '4', '4', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '0', 'China', '', '0', '0', '', '1331959107', '1', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '171.37.19.47', '0', '', '0', '1', '0', '', '', '0.00008', '0.00120', '0', '0', '0', '4', '0', '1', '1', '81ca0262c82e712e50c580c032d99b60', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('47', 'Shi XiaoChen', 'luicfer', '29cd3bfc35e07d10045f5e7f3ba26a21', 'kaikan_luicfer@yahoo.com.cn', '0', '', '0.00000', '1331959924', '222.97.146.235', 'tokpogs', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '', '1331959924', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '0', '69151331959924', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '0', 'Korea, Republic of', '', '0', '0', '', '', '0', '0', '', '', '', '0', '0', '0', '0', '0.00', '0', '222.97.146.235', '0', '', '0', '1', '0', '', '', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '164cc88744837aadfd7c50cbd7fe4f92', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('48', 'MAHMOUD MOUSTAFA IMAM DESOUKY ELHABBAQ', 'berich', 'f0016bbd40c38f681c50d5c11394d24f', 'be.rich888@yahoo.com', '0', '', '0.00390', '1331961342', '58.19.23.45', '', '0', '0', '0', '0', '0', '0.00000', '13', '0', '0.00000', '1331965035', '1331965054', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '13', '13', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '0', '0', '0.00000', '', '0.00000', '0', '0', '1', 'China', '', '0', '0', '', '1331965014', '5', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '58.19.23.45', '0', '', '0', '1', '0', '', '', '0.00026', '0.00390', '0', '0', '0', '13', '0', '1', '1', '6cd15398628fd108fb53261142536b70', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('49', 'curtiev ioan', 'calypso35', '0492266a75694095ceb26ffcc7fc1bc5', 'valjean25@gmail.com', '0', '', '0.00000', '1331992041', '79.115.67.87', 'admin', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '', '1331992128', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '1', '', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '0', '0', '0', '0.00000', '', '0.00000', '0', '0', '0', 'Romania', '', '0', '0', '', '', '0', '0', '', '', '', '0', '1', '0', '0', '0.00', '0', '79.115.67.87', '0', '', '0', '1', '0', '', '', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', 'fa246d0262c3925617b0c72bb20eeb1d', '0', '0', '0', '0', '0', '1', '0');
INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `permission`, `mod_permission`, `balance`, `joined`, `last_ip`, `refered`, `referrals1`, `referrals2`, `referrals3`, `referrals4`, `referrals5`, `referral_earns`, `clicks`, `type`, `points`, `last_click`, `last_act`, `w_min`, `w_method`, `w_account`, `link_credits`, `banner_credits`, `fad_credits`, `flink_credits`, `clicked_today`, `tickets`, `pend`, `conclicks`, `week_refs`, `suspended`, `ptphits`, `ptphits_today`, `ptpearns`, `popup_credits`, `ptr_credits`, `optin`, `conemails`, `emails`, `emails_today`, `fbanner_credits`, `membership`, `game_points`, `notes`, `verified`, `verify_id`, `ref_hits_raw`, `ref_hits_unique`, `game_site_credits`, `surf_credits`, `surf_clicks`, `surf_clicks_today`, `floodguard`, `floodguard_today`, `referrals`, `updated`, `ptra_clicks`, `ptra_clicks_today`, `ptra_credits`, `last_ptra`, `xcredits`, `xclicks`, `xclicked_today`, `failed_logins`, `country`, `db`, `cheat_check`, `cheat_failed`, `lockout`, `last_cheat`, `cheat_checks`, `ptsu_credits`, `ad_alert`, `ad_tag`, `sex`, `birth`, `ad_alert_login`, `ptsu_approved`, `ptsu_denied`, `ptsu_earnings`, `group`, `join_ip`, `auto_pay`, `auto_account`, `auto_method`, `verifyCo`, `hidePopup`, `suspendTime`, `suspendMsg`, `upline_earnings`, `earned_today`, `reftotcli`, `clicksref`, `purchcon_tic`, `clickcon_clic`, `refstat`, `moptin`, `confirm`, `pin`, `coclicks`, `bonusclaims`, `tagged`, `warnings`, `surv_comp`, `ref_notifier`, `lbref`) VALUES ('50', 'nicola ranieri', 'nicranieri', 'a60a9afabfc8e02a6bdbad86f3784ac4', 'nicranieri71@libero.it', '0', '', '0.00000', '1331996272', '151.64.131.234', 'admin', '0', '0', '0', '0', '0', '0.00000', '0', '0', '0.00000', '', '1331996272', '0.00', '', '', '0.00000', '0.00000', '0.00000', '0.00000', '0', '0', '', '0', '0', '0', '0', '0', '0.00000', '0.00000', '0.00000', '1', '0', '0', '0', '0.00000', '0', '0.00000', '', '0', '75601331996272', '0', '0', '0.00000', '0.00000', '0', '0', '0', '0', '0', '0', '0', '0', '0.00000', '', '0.00000', '0', '0', '0', 'Italy', '', '0', '0', '', '', '0', '0', '', '', '', '0', '0', '0', '0', '0.00', '0', '151.64.131.234', '0', '', '0', '1', '0', '', '', '0.00000', '0.00000', '0', '0', '0', '0', '0', '1', '1', '4a7d1ed414474e4033ac29ccb8653d9b', '0', '0', '0', '0', '0', '1', '0');






# dumping data for clickpla_mrv.withdraw_options
INSERT INTO `withdraw_options` (`id`, `title`, `mps`, `delim`, `minimum`, `active`, `fee`, `verif`, `fee_premium`, `fee_min`, `minimum_premium`) VALUES ('6', 'PayPal', 'account{tab}amount{tab}USD', '{tab}', '1.25', '1', '15', 'email', '0', '0.01', '0.25');




# dumping data for clickpla_mrv.xsites
INSERT INTO `xsites` (`id`, `title`, `dsub`, `username`, `views`, `views_today`, `credits`, `target`, `pref`, `forbid_retract`, `active`, `daily_limit`, `upgrade`, `country`, `decline`) VALUES ('1', 'My Money Maker', '1331826871', '', '9', '3', '99991', 'http://ajramos23.blogspot.com', '', '1', '1', '0', '0', '', '');




